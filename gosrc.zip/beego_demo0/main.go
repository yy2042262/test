package main
import(
	"fmt"
	"github.com/astaxie/beego"
)

//Get and Post
type RestfulController struct{
	beego.Controller
}

//Regexpress
type RegExpController struct{
	beego.Controller
}

//Get
/*func (this *RestfulController) Get(){
	this.Ctx.WriteString("helloworld in get method!")
}*/

//Post
func (this *RestfulController) Post(){
	this.Ctx.WriteString("helloworld in post method!")
}

func (this *RegExpController) Get(){
	this.Ctx.WriteString(fmt.Sprintf("In Regexpress Mode:\n"))
	
	id:=this.Ctx.Input.Param(":id")
	this.Ctx.WriteString(fmt.Sprintf("id is:%s\n",id))

	splat:=this.Ctx.Input.Param(":splat")
	this.Ctx.WriteString(fmt.Sprintf("splat is:%s\n",splat))

	path:=this.Ctx.Input.Param(":path")
	this.Ctx.WriteString(fmt.Sprintf("path is:%s\n",path))
	ext:=this.Ctx.Input.Param(":ext")
	this.Ctx.WriteString(fmt.Sprintf("ext is:%s\n",ext))
}

func main(){

	beego.Router("/restful",&RestfulController{})

	//Regexpress
	beego.Router("/regex1/?:id",&RegExpController{})
	beego.Router("/regex2/:id([0-9]+)",&RegExpController{})
	beego.Router("/regex3/:id([\\w]+)",&RegExpController{})
	beego.Router("/regex4/abc:id([0-9]+)de",&RegExpController{})
	beego.Router("/regex5/*",&RegExpController{})
	beego.Router("/regex6/*.*",&RegExpController{})
	
	beego.Run("127.0.0.1:8081")
}