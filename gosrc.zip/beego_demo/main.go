package main

import (
	_ "beego_demo/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

