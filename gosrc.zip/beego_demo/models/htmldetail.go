package models
import(
	"fmt"
)
type Photo struct{
	Id string
	ImagePath string
}
func GetPhotos() []Photo{
	buffer:=[]Photo{
		Photo{
			Id:"jpg1",
			ImagePath:"img01.jpg",
		},
		Photo{
			Id:"jpg2",
			ImagePath:"img02.jpg",
		},
		Photo{
			Id:"jpg3",
			ImagePath:"img03.jpg",
		},
	}
	return buffer
}
func GetTitle() string{
	return "岳勇测试瞎编的数据"
}
func GetPrice() string{
	price:=222
	intprice:=price/100
	decprice:=price%100
	return fmt.Sprintf("%d.%02d",intprice,decprice)
}
