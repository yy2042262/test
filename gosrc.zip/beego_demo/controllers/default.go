package controllers

import (
	"fmt"
	"beego_demo/models"
	"github.com/astaxie/beego"
)

type MainController struct {
	beego.Controller
}

func (c *MainController) Get() {

	id:=c.Ctx.Input.Param(":id")
	fmt.Printf("id is:%s\n",id)

	c.TplName="index.html"

	c.Data["Photos"]=models.GetPhotos()
	c.Data["Title"]=models.GetTitle()
	c.Data["Price"]=models.GetPrice()
}
