package main
import(
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/autotls"
)
func main(){
	g:=gin.Default()
	g.GET("/test",func(c *gin.Context){
		c.String(200,"hello test")	
	})
	autotls.Run(g,"www.itpp.tk")
}