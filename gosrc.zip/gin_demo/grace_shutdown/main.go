package main
import(
	"github.com/gin-gonic/gin"
	"net/http"
	"log"
	"time"
	"context"
	"os"
	"os/signal"
	"syscall"
)
func main(){
	//gin.SetMode(gin.ReleaseMode)
	g:=gin.Default()
	g.GET("/test",func(c *gin.Context){
		time.Sleep(10*time.Second)
		c.String(200,"hello test!")
	})
	server:=&http.Server{
		Addr:":8085",
		Handler:g,
	}
	go func(){
		if err:=server.ListenAndServe();err!=nil&&err!=http.ErrServerClosed{
			log.Fatalf("listen:%s\n",err)
		}
	}()
	quit:=make(chan os.Signal)
	signal.Notify(quit,syscall.SIGINT,syscall.SIGTERM)
	<-quit
	log.Println("shutdown server...")
	ctx,cancel:=context.WithTimeout(context.Background(),10*time.Second)
	defer cancel()
	if err:=server.Shutdown(ctx);err!=nil{
		log.Fatal("shutdown timeout context fail:",err)
	}
	log.Println("server exiting")
}