package main
import(
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
)
type Photo struct{
	Id string
	ImagePath string
}
func getHtmlDetail(c *gin.Context){

	id:=c.Param("id")
	fmt.Printf("id is:%s\n",id)

	buffer:=[]Photo{
		Photo{
			Id:"jpg1",
			ImagePath:"img01.jpg",
		},
		Photo{
			Id:"jpg2",
			ImagePath:"img02.jpg",
		},
		Photo{
			Id:"jpg3",
			ImagePath:"img03.jpg",
		},
	}
	price:=52100
	intprice:=price/100
	decprice:=price%100
	pricestring:=fmt.Sprintf("%d.%02d",intprice,decprice)
	c.JSON(http.StatusOK,gin.H{
		"photos":buffer,
		"title":"陆鹿用于测试的数据:^v^",
		"price":pricestring,
	})
}
func main(){
	g:=gin.Default()
	g.Static("/html","./html")

	g.GET("/param/:id",getHtmlDetail)

	g.Run("127.0.0.1:8083")
}

/*import(
	"github.com/gin-gonic/gin"
)
func main(){
	g:=gin.Default()
	g.GET("/test",func(c *gin.Context){
		c.JSON(200,gin.H{
			"title":"yy",
			"content":"yueyong",
		})
	})
	g.Run()
}*/