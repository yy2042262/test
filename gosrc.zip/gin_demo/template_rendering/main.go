package main
import(
	"github.com/gin-gonic/gin"
)
func main(){
	g:=gin.Default()
	g.LoadHTMLGlob("template/*")
	g.GET("/index",func(c *gin.Context){
		c.HTML(200,"index.tpl",gin.H{
			"title":"又要上班了!",
		})
	})
	g.Run()
}