package main
import(
	"github.com/gin-gonic/gin"
	"time"
)
type Person struct{
	Name string `form:"name"`
	Address string `form:"address"`
	Birthday time.Time `form:"birthday" time_format:"2020-02-02"`
}
func main(){
	g:=gin.Default()
	g.GET("/testing",testing)
	g.POST("testing",testing)
	g.Run()
}

func testing(c *gin.Context){
	var p Person
	if err:=c.ShouldBind(&p);err==nil{
		c.String(200,"%v",p)
	}else{
		c.String(200,"person bind error:%v",err)
	}
}