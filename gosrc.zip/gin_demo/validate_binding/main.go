package main
import(
	"github.com/gin-panic/gin"
	en2 "github.com/go-playground/locales/en"
	zh2 "github.com/go-playground/locales/zh"
	"github.com/go-playground/universal-translator"
	"github.com/go-playground/validator"
	en_translations "github.com/go-playground/validator/translations/en"
	zh_translations "github.com/go-playground/validator/translations/zh"
)
type Person struct{
	Name string `form:"name" validate:"required"`
	Age int `form:"age" validate:"required,gt=10"`
	Address string `form:"address" validate:"required"`
}
var(
	Uni *ut.UniversalTranslator
	Validate *validator.Validate
)
func main(){
	Validate=validator.New()
	en:=en2.New()
	zh:=zh2.New()
	Uni=ut.New(en,zh)
	g:=gin.Default()
	g.GET("/testing",func(c *gin.Context){
		locale:=c.DefaultQuery("locale","zh")
		trans,_:=Uni.GetTranslator(locale)
		switch locale{
			case "en":
				en_translations.RegisterDefaultTranslations(Validate,trans)
			case "zh":
				zh_translations.RegisterDefaultTranslations(Validate,trans)
			default:
				zh_translations.RegisterDefaultTranslations(Validate,trans)
		}
		var person Person
		if err:=c.ShouldBind(&person);err!=nil{
			c.String(500,"%v",err)
			c.Abort()
			return
		}
		if err:=Validate.Struct(person);err!=nil{
			errs:=err.(validator.ValidationErrors)
			sliceErrs:=[]string{}
			for _,e:=range errs{
				sliceErrs=append(sliceErrs,e.Translate(trans))
			}
			c.String(500,"%v",sliceErrs)
			c.Abort()
			return
		}
		c.String(200,"%v",person)
	})
	g.Run()
}