package main
import(
	"github.com/gin-gonic/gin"
)
func IPAuthMiddleware() gin.HandlerFunc{
	return func(c *gin.Context){
		iplist:=[]string{
			"127.0.0.1",
		}
		flag:=false
		clientip:=c.ClientIP() 
		for _,host:=range iplist{
			if host==clientip{
				flag=true
				break
			}
		}
		if !flag{
			c.String(401,"%s,not in iplist.",clientip)
			c.Abort()
		}
	}
}
func main(){
	gin.SetMode(gin.ReleaseMode)
	g:=gin.Default()
	g.Use(IPAuthMiddleware())
	g.GET("/test",func (c *gin.Context){
		c.String(200,"hello test")
	})
	g.Run()
}