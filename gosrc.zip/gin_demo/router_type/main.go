package main
import (
	"github.com/gin-gonic/gin"
)
func main(){
	g:=gin.Default()
	g.GET("/get",func(c *gin.Context){
		c.String(200,"get")
	})
	g.POST("/post",func (c *gin.Context){
		c.String(200,"post")
	})
	g.Handle("DELETE","/delete",func(c *gin.Context){
		c.String(200,"delete")
	})
	g.Any("/any",func(c *gin.Context){
		c.String(200,"any")
	})
	g.Run()
}