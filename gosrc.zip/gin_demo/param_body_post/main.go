package main
import(
	"github.com/gin-gonic/gin"
	"net/http"
	"io/ioutil"
	"bytes"
)
func main(){
	g:=gin.Default()
	g.POST("/test",func(c *gin.Context){
		bts,err:=ioutil.ReadAll(c.Request.Body)
		if err!=nil{
			c.String(http.StatusBadRequest,err.Error())
			c.Abort()
		}
		//c.String(http.StatusOK,string(bts))

		c.Request.Body=ioutil.NopCloser(bytes.NewBuffer(bts))
		firstname:=c.PostForm("fname")
		lastname:=c.DefaultPostForm("lname","lastdefaultname")
		c.String(http.StatusOK,"%s,%s,%s",firstname,lastname,string(bts))
	})
	g.Run()
}