package main
import(
	"os"
	"io"
	"github.com/gin-gonic/gin"
)
func main(){
	f,_:=os.Create("middleware.log")
	gin.DefaultWriter=io.MultiWriter(f)
	gin.DefaultErrorWriter=io.MultiWriter(f)
	gin.SetMode(gin.ReleaseMode)
	g:=gin.New()

	//g.Use(gin.Logger())
	//2
	g.Use(gin.Logger(),gin.Recovery())
  
	g.GET("/test",func(c *gin.Context){
		name:=c.DefaultQuery("name","defaultname")

		//2
		panic("test panic")

		c.String(200,"%s",name)
	})
	g.Run()
}