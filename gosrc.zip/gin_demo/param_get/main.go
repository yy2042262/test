package main
import(
	"github.com/gin-gonic/gin"
	"net/http"
)
func main(){
	g:=gin.Default()
	g.GET("/test",func(c *gin.Context){
		firstname:=c.Query("fname")
		lastname:=c.DefaultQuery("lname","lastdefaultname")
		c.String(http.StatusOK,"%s,%s",firstname,lastname)
	})
	g.Run(":8080")
}