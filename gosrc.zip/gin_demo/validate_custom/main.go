package main
import(
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"reflect"
	"time"
	"github.com/go-playground/validator"
)
type Book struct{
	CheckIn time.Time `form:"checkin" binding:"required bookabledate" time_format:"2020-02-02"`
	CheckOut time.Time `form:"checkout" binding:"required gtfield=CheckIn" time_format:"2020-02-02"`
}
func bookableDate(v *validator.Validate,topStruct reflect.Value,currentStructOrField reflect.Value,field reflect.Value,fieldType reflect.Type,fieldKind reflect.Kind,param string) bool {
	
	/*if whatever {
		retur false
	}
	return true*/

	if date,ok:=field.Interface().(time.Time);ok{
		today:=time.Now()
		if today.Unix()<date.Unix(){
			return true
		}
	}
	return false
}
func main(){
	gin.SetMode(gin.ReleaseMode)
	g:=gin.Default()
	if v,ok:=binding.Validator.Engine().(*validator.Validate);ok{
		v.RegisterValidation("bookabledate",bookableDate)
	}
	g.GET("/book",func(c *gin.Context){
		var b Book
		if err:=c.ShouldBind(&b);err!=nil{
			c.JSON(500,gin.H{"error":err.Error()})
			return
		}
		c.JSON(200,gin.H{
			"message":"ok",
			"book":b})
	})
	g.Run()
}