package main
import(
	"github.com/gin-gonic/gin"
	"net/http"
)
func main(){
	g:=gin.Default()
	g.Static("/test1","./static")
	g.StaticFS("/test2",http.Dir("staticfs"))
	g.StaticFile("/cat.ico","./cat.ico")
	g.Run()
}