package main
import(
	"fmt"
	"net/http"
	"github.com/gin-gonic/gin"
)

func RestfulGet(c *gin.Context){
	c.String(http.StatusOK,"helloworld int get method!")
}
func RestfulPost(c *gin.Context){
	c.String(http.StatusOK,"helloworld in post method!")
}

func FetchId(c *gin.Context){
	id:=c.Param("id")
	c.String(http.StatusOK,fmt.Sprintf("id is %s:\n",id)
}

func action1(c *gin.Context){
	c.String(200,"action1")
}
func action2(c *gin.Context){
	c.String(200,"action2")
}
func action3(c *gin.Context){
	c.String(200,"action3")
}

func main(){
	g:=gin.Default()
	g.Get("/restful",RestfulGet)
	g.Post("/restful",RestfulPost)

	g.Get("/param/:id",FetchId)

	group1:=g.Group("/g1"){
		group1.Get("/action1",action1)
		group1.Get("/action2",action2)
		group1.Get("/action3",action3)
	}

	g.Run("127.0.0.1:8082")
}