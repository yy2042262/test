package com.yueyong.springboot;

import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.yueyong.springboot.entity.Order;
import com.yueyong.springboot.producer.OrderSender;
import com.yueyong.springboot.service.OrderService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ApplicationTests {

	@Test
	public void contextLoads() {
	}
	@Autowired
	private OrderSender orderSender;
	/*@Test
	public void testSend1() throws Exception{
		Order order=new Order();
		order.setId("20190211000000001");
		order.setName("测试订单1");
		order.setMessageId(System.currentTimeMillis()+"$"+UUID.randomUUID().toString());
		orderSender.send(order);
	}*/
	
	@Autowired
	private OrderService orderService;
	@Test
	public void testSend() {
		Order order=new Order();
		order.setId("20190212000000013");
		order.setName("测试创建订单");
		order.setMessageId(System.currentTimeMillis()+"$"+UUID.randomUUID().toString());
		try {
			orderService.createOrder(order);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

