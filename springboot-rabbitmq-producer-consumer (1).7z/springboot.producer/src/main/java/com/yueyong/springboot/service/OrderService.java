package com.yueyong.springboot.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yueyong.springboot.constant.Constants;
import com.yueyong.springboot.entity.BrokerMessageLog;
import com.yueyong.springboot.entity.Order;
import com.yueyong.springboot.mapper.BrokerMessageLogMapper;
import com.yueyong.springboot.mapper.OrderMapper;
import com.yueyong.springboot.producer.RabbitOrderSender;
//import com.yueyong.springboot.producer.RabbitSender;
import com.yueyong.springboot.utils.FastJsonConvertUtil;

@Service
public class OrderService {
	@Autowired
	private OrderMapper orderMapper;
	@Autowired
	private BrokerMessageLogMapper brokerMessageLogMapper;
	@Autowired
	private RabbitOrderSender rabbitOrderSender;
	
	//多余：测试
	/*@Autowired
	private RabbitSender rabbitSender;*/
	
	public void createOrder(Order order) throws Exception{
		//order current time
		Date orderTime=new Date();
		//order insert //业务数据入库
		orderMapper.insert(order);
		//log insert 构建消息日志记录对象
		BrokerMessageLog brokerMessageLog=new BrokerMessageLog();
		brokerMessageLog.setMessageId(order.getMessageId());
		//save order message as json
		brokerMessageLog.setMessage(FastJsonConvertUtil.convertObjectToJson(order));
		brokerMessageLog.setStatus("0");//设置订单的发送状态为0 表示发送中
		brokerMessageLog.setNextRetry(DateUtils.addMinutes(orderTime,Constants.ORDER_TIMEOUT));
		brokerMessageLog.setCreateTime(new Date());
		brokerMessageLog.setUpdateTime(new Date());
		brokerMessageLogMapper.insert(brokerMessageLog);
		//order message sender
		rabbitOrderSender.sendOrder(order);
		
		//多余：测试
		/*Map<String,Object> properties=new HashMap<String,Object>();
		properties.put("yy","你好");
		rabbitSender.send("岳勇",properties);*/
		
	}
}
