package com.yueyong.springboot.entity;

import java.io.Serializable;
import java.util.Date;

public class BrokerMessageLog implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4704865295949892469L;
	private String messageId;
	private String message;
	private int tryCount;
	private String status;
	private Date nextRetry;
	private Date createTime;
	private Date updateTime;
	public BrokerMessageLog() {
		super();
	}
	public BrokerMessageLog(String messageId, String message, int tryCount, String status, Date nextRetry,
			Date createTime, Date updateTime) {
		super();
		this.messageId = messageId;
		this.message = message;
		this.tryCount = tryCount;
		this.status = status;
		this.nextRetry = nextRetry;
		this.createTime = createTime;
		this.updateTime = updateTime;
	}
	
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getTryCount() {
		return tryCount;
	}
	public void setTryCount(int tryCount) {
		this.tryCount = tryCount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getNextRetry() {
		return nextRetry;
	}
	public void setNextRetry(Date nextRetry) {
		this.nextRetry = nextRetry;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
}
