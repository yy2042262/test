package com.yueyong.springboot.config.database;

public class BaseMapper {

}
