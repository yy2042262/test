package com.yueyong.springboot.consumer;

import java.io.IOException;
import java.util.Map;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.rabbitmq.client.Channel;
import com.yueyong.springboot.entity.Order;

@Component
public class OrderReceiver {
	@RabbitListener(bindings=@QueueBinding(value=@Queue(value="order-queue",durable="true"),exchange=@Exchange(name="order-exchange",durable="ture",type="topic"),key="order.#"))
	@RabbitHandler
	public void onMessage(@Payload Order order,@Headers Map<String,Object> headers,Channel channel) {
		System.out.println("--------收到消息，开始消费--------");
		System.out.println("订单ID:"+order.getId());
		Long deliveryTag=(Long)headers.get(AmqpHeaders.DELIVERY_TAG);
		try {
			channel.basicAck(deliveryTag,false);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
