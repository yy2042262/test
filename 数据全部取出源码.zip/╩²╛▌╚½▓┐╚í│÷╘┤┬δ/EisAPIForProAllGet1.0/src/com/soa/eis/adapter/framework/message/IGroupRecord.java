/**
 * 
 */
package com.soa.eis.adapter.framework.message;

import java.util.Vector;

import com.soa.eis.adapter.framework.exception.EisException;

/**
 * 批量交易中,记录集对象接口.
 * @author wangtao
 *
 */
public interface IGroupRecord {
	/**
	 * 返回记录集名称,默认"Recorders".
	 * @return
	 */
	public String getName();
	/**
	 * 设置记录集名称.
	 * @param name
	 */
	public void setName(String name);
	
	/**
	 * 返回key对应的值.
	 * @param key
	 * @return
	 */
	public String getValue(String key) throws EisException;
	/**
	 * 设置key对应的值.
	 * @param key
	 * @param value
	 * @throws EisException
	 */
	public void setValue(String key,String value) throws EisException;
	/**
	 * 返回索引对应的值.
	 * @param index
	 * @return
	 * @throws EisException
	 */
	public String getValue(int index) throws EisException;
	/**
	 * 设置索引对应的值.
	 * @param index
	 * @param value
	 * @throws EisException
	 */
	public void setValue(int index,String value) throws EisException;
	/**
	 * 返回记录集中的键.
	 * @return 
	 */
	public Vector<String> getkeys();
}
