package com.soa.eis.adapter.framework.requester.impl;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HTTP;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.message.IMsgObject;
import com.soa.eis.adapter.framework.message.impl.GroupRecord;
import com.soa.eis.adapter.framework.message.impl.MsgObject;
import com.soa.eis.adapter.framework.requester.IServiceRequester;

public class WSServiceRequester extends AbstractServiceRequester implements IServiceRequester {

	public WSServiceRequester() throws EisException {
		super();
	}

	private static IServiceRequester requester = null;

	public synchronized static IServiceRequester getInstance()
			throws EisException {
		if (null == requester) {
			requester = new WSServiceRequester();
		}
		return requester;
	}

	public static IServiceRequester getPoolInstance() throws EisException {
		if (null == requester) {
			getInstance();
		}
		return requester;
	}

	/**
	 * 把IMsgObject转换成调用WebService的报文，然后再把返回内容转换成IMsgObject对象
	 * @throws IOException 
	 */
	@Override
	public IMsgObject execute(IMsgObject reqMo) throws EisException {
		IMsgObject resMo = null;
		try{
		InputStream in = new FileInputStream("config/msgTransform.properties");
		Properties p = new Properties();
		p.load(in);
		String begin = p.getProperty("msg.begin");
		String end = p.getProperty("msg.end");
		String reqMsg = begin + reqMo.toString().split("\\?>\n")[1] + end;
//		System.out.println(reqMsg);
		
		HttpClient httpClient = HttpClients.createDefault();
//		HttpPost httppost = new HttpPost("http://10.64.13.61:7080/httpservice");
		HttpPost httppost = new HttpPost("http://localhost:7080/esql");
		HttpEntity he = new StringEntity(reqMsg.toString(), HTTP.UTF_8);
		httppost.setHeader("Content-Type","application/soap+xml;charset=UTF-8");
		httppost.setHeader("SOAPAction", "");
		httppost.setEntity(he);
		RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(10000).setConnectTimeout(10000).build();
		httppost.setConfig(requestConfig);
        HttpResponse response = httpClient.execute(httppost);
		
//        String reqMsg2 = IOUtils.toString(response.getEntity().getContent());
//        System.out.println(reqMsg2);
        
        SAXReader reader = new SAXReader();
		Document document = reader.read(response.getEntity().getContent());
		Element element = document.getRootElement();
		Element content = (Element) element.element("Body").elementIterator().next();
//		System.out.println(content.asXML());
//		System.out.println("-------------------------------");
		Element service = content.element("return").element("Service");
		resMo = new MsgObject(service.asXML().getBytes(), IMsgObject.MOType.initSR);
		System.out.println(resMo);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return resMo;
	}

	/**
	 * 该接口为不必要接口，未实现
	 */
	@Override
	@Deprecated
	public IMsgObject execute(IMsgObject reqMo, int timeout)
			throws EisException {
		
		return null;
	}

	/**
	 * 该接口为不必要接口，未实现
	 */
	@Override
	@Deprecated
	public void closeConnection() {
		
	}

	public static void main(String[] args) throws Exception {
		IMsgObject reqMo = new MsgObject();
		reqMo.setServiceID("02003000000001");
//		reqMo.setServiceID("08001000000003");
		reqMo.setSourceSysID("08001");
		reqMo.setSerialNO("2013070504004000055");
		reqMo.setServiceDateTime("20130705152426");
		
		
//		reqMo.setReqValue("a", "abc");
		
		String reqMsg = null;
		try {
			InputStream in = new BufferedInputStream(new FileInputStream("D:/报文/1MB.xml"));
			reqMsg = IOUtils.toString(in);
		} catch(Exception e){
			e.printStackTrace();
		}
		reqMo.setReqValue("a", reqMsg);
		
//		reqMo.setReqValue("i", "10000");
//		reqMo.setReqValue("qqCode", "10000");
//		reqMo.setReqValue("ZJS", "X");
//		reqMo.setReqValue("SDATUM_LOW", "2012-10-02 00:00:00");
//		reqMo.setReqValue("SDATUM_HIGH", "2012-10-05 23:59:59");
//		reqMo.setReqValue("ZEP_KUNNR/ZKUNNR", "0000531701");
//		List<GroupRecord> grList = new ArrayList<GroupRecord>();
//		GroupRecord gr = new GroupRecord();
//		gr.setName("list1");
//		gr.setFieldValue("x", "0000531701");
//		gr.setFieldValue("WS", "ABC");
//		grList.add(gr);
//		reqMo.setReqGroupRecord(grList);
		
		WSServiceRequester mt = new WSServiceRequester();
		System.out.println(reqMo);
		System.out.println("----------------------------------------------------------");
		mt.execute(reqMo);
		
		
	}
	
//	public static void main(String[] args) throws Exception {
//		WSServiceRequester ws = new WSServiceRequester();
//		InputStream in = new BufferedInputStream(new FileInputStream("config/HTTPMsg.xml"));
//		String reqMsg = IOUtils.toString(in);
//		
//		IMsgObject mo = new MsgObject(reqMsg.getBytes(), IMsgObject.MOType.initSR);
//		ws.execute(mo);
//		
//	}
	
	
	public List<Element> getAllNodes(Element root, String s){
		List<Element> list = new ArrayList<Element>();
		list.add(root);
		
		String[] names = s.split("[.]");
		for(int i=0;i<names.length;i++){
			list = getNodesByName(list, names[i]);
		}
		
		return list;
	}
	
	/**
	 * 获取父级节点List的所有该名字子级节点List
	 * @param parentList
	 * @param nodeName
	 * @return
	 */
	public List<Element> getNodesByName(List<Element> parentList, String nodeName){
		List<Element> list = new ArrayList<Element>();
		for(Element parentNode : parentList){
			List<Element> nodes = parentNode.elements(nodeName);
			list.addAll(nodes);
		}
		
		return list;
	}
	
}
