package com.soa.eis.adapter.framework.connection.mqc;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.soa.eis.adapter.framework.common.CacheManager;
import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.utils.HexString;
import com.soa.eis.adapter.framework.utils.log.LogUtil;

/**
 *
 * 针对MQ操作的工具类
 */
public class MQQueueAccesser {

	public static final int MQ_OK = 0;

	public static final int MQ_CONNECTION_BROKER = -1;
	
	public static final int MQ_CONNECTION_BROKEN_2009 = -2;

	public static final int MQ_TIME_OUT = 1;

	public static final int MQ_UNKNOW_EXCEPTION = 2;
	
	/**
	 * MQ消息接收类型
	 */
	public static final int MQ_MSGRECEIVE_TYPE = 0;
	
	/**
	 * MQ消息发送类型
	 */
	public static final int MQ_MSGSEND_TYPE = 1;
	
	/**
	 * MQ连接异常，重连次数默认值
	 */
	public static final int MQ_TRY_COUNT = 3;
	/**
	 * 接收消息异常，重试次数默认值
	 */
	public static final int MQ_CONN_GETMSG_COUNT = 1;
	/**
	 * 发送消息异常，重试次数默认值
	 */
	public static final int MQ_CONN_PUTMSG_COUNT = 1;
	
	/**
	 * 每次重连的等待时间，默认值(毫秒)
	 */
	public static final int MQ_TRY_INTERVAL = 2000;
	
	public static final int MQ_SEGMENT_LEN = 5000;
	
	/**
	 * 消息有效时间,(1/10秒)
	 */
	public static final int MQ_MSG_EXPIRY = 6000;
	
	public static final int MQ_REQ_MSG_TIMEOUT = 5 * 60;
	
	public static final int MQ_SUB_MSG_TIMEOUT = 5 * 60;

	public static final MQPutMessageOptions getPMOFromPara() {
		MQPutMessageOptions pmo = new MQPutMessageOptions();
		pmo.options |= MQC.MQPMO_FAIL_IF_QUIESCING;
		return pmo;
	}
	
	/**
	 * 设置从MQ队列中获取消息的参数
	 * @param timeout < 0:则无限等待;< 0:从MQ队列连接的超时时间，单位秒
	 * @return
	 */
	private static final MQGetMessageOptions getGMOFromPara(int timeout) {
		MQGetMessageOptions gmo = new MQGetMessageOptions();
		gmo.options = MQC.MQGMO_WAIT + MQC.MQGMO_FAIL_IF_QUIESCING;
//		gmo.options = MQC.MQGMO_SYNCPOINT  + MQC.MQGMO_WAIT + MQC.MQGMO_FAIL_IF_QUIESCING; ;
		
		//如果是-1则无限等待取值,否则设置超时时间
		if (timeout < 0){
			gmo.waitInterval = MQC.MQWI_UNLIMITED;
		}else{
			gmo.waitInterval = timeout * 1000; // 设置timeout的时间，单位毫秒
		}
		return gmo;
	}
	
	
	/**
	 * 通过匹配的msgID来从Queue中获取消息
	 * @param msgId Q队列的消息标识
	 * @param para MQ连接实例对象
	 * @param type 设置接收消息
	 * @param timeout < 0:则无限等待;< 0:从MQ队列连接的超时时间，单位秒
	 * @return
	 * @throws EisException
	 */
	public static MQMessage getMsgFromQueue(byte[] msgId, MQCParameter para, int timeout) throws Exception {
		
		try{
				MQGetMessageOptions gmo = getGMOFromPara(timeout);
				if (para.qManager == null || para.queue == null) {
					connectMQExce(para, MQQueueAccesser.MQ_MSGRECEIVE_TYPE);
				}
				MQMessage msg = new MQMessage();
				if (msgId != null){
					msg.messageId = msgId;
				}
				
				printMsgId("before get MsgId",msg.messageId);
				// 从MQ请求队列拿消息
				para.queue.get(msg, gmo);
				printMsgId("after get MsgId",msg.messageId);
				return msg;
		}catch (MQException mqe) {
			throw mqe;
		}catch(Exception e){
			throw new EisException(MQCException.MQ_MSG_RECEIVE_GETMSG_ERROR_EXCEPTION_CODE);
		}
		// return null;
	}
	
	
	/**
	 * 通过匹配的group id来从Queue中获取消息
	 *
	 * @param para
	 * @param gmo
	 * @return
	 * @throws Exception
	 */
	public static byte[] getMsgFromQueueBySegment(byte[] grpId, MQCParameter para,
			int type, int timeout) throws EisException {
		
		//timeout = 0 : 取配置文件或缺省超时时间, timeout < 0 : 无限制读取消息, timeout > 0 : 取timeout值
		int to = timeout <= 0 ? getSubTimeOut() : timeout;
		MQGetMessageOptions gmo = getGMOFromPara(to);
		
		if (para.qManager == null || para.queue == null) {
			connectMQ(para, type);
		}
		
		gmo.options = 
		    MQC.MQGMO_LOGICAL_ORDER + MQC.MQGMO_SYNCPOINT + MQC.MQGMO_ALL_SEGMENTS_AVAILABLE;
		gmo.matchOptions = MQC.MQMO_MATCH_GROUP_ID;	
		
		int interval = getInterval();
		int trycount = getCount();
		
		boolean isLastSegment = false;
		ByteArrayOutputStream baOut = new ByteArrayOutputStream();
		DataOutputStream dataOS = new DataOutputStream(baOut);
		byte[] result = null;
		try {
		    while(!isLastSegment) {
		    	
		    	boolean received = false;
				int fetchCount = 0;		
				
				while (!received) {		
					MQMessage inMsg = new MQMessage(); 
					try {
						fetchCount++;				
				    	/*创建MQMessage 类*/
						
						inMsg.groupId = grpId;
			
						/*从队列到消息缓冲区获取消息*/
						para.queue.get(inMsg, gmo);
						
				        if (inMsg.messageFlags == MQC.MQMF_SEGMENT + MQC.MQMF_LAST_SEGMENT)
				            isLastSegment = true;
				        byte[] b = new byte[inMsg.getMessageLength()];
						inMsg.readFully(b);
						if (b != null) {
							dataOS.write(b);
							dataOS.flush();
							received = true;
						}
					} catch (MQException mqe) {
						int ret = handleMQException(mqe);
						if (fetchCount >= trycount) {
							try {
								inMsg.clearMessage();
							} catch (Exception e) {
								LogUtil.getInstance().error("Exception:",e);
							}
							inMsg = null;
							LogUtil.getInstance().error(" Can't fetch message for " + EisException.getTrace(mqe));
							if(ret != MQ_TIME_OUT){
								para.release();
								LogUtil.getInstance().error("Exception:",mqe);
							} 
							return null;
						} else {
							if(ret != MQ_TIME_OUT){
								para.release();
								if(!connectMQ(para, type, 1, interval)){
									inMsg = null;
									return null;
								}
							} 
						}				
					} catch (Exception ex) {
						if (fetchCount >= trycount) {
							try {
								inMsg.clearMessage();
							} catch (Exception e) {
								LogUtil.getInstance().error("Exception",ex);
							}
							inMsg = null;							
							para.release();
							LogUtil.getInstance().error("Can't fetch message for:",ex);
							return null;
						} else {
							para.release();
							if(!connectMQ(para, type, 1, interval)){
								inMsg = null;
								return null;
							}
						}	
					} finally {
						try {
							if (inMsg != null)
								inMsg.clearMessage();
							inMsg = null;
						} catch (IOException e) {
							LogUtil.getInstance().error("Exception",e);
						}
					}
				}
		        
		    }
		    result = baOut.toByteArray();
		} catch (Exception ex) {
			LogUtil.getInstance().error(" fetch message error : ",ex);
			para.release();
		} finally {
			if (dataOS != null)
				try {
					dataOS.close();
					dataOS = null;
				} catch (Exception e) {
					LogUtil.getInstance().error("Exception",e);
				}
			if (baOut != null)
				try {
					baOut.close();
					baOut = null;
				} catch (Exception e) {
					LogUtil.getInstance().error("Exception",e);
				}
			gmo = null;
		}
		
		return result;
			
	}
	
	/**
	 * 通过匹配的group id来从Queue中获取消息，并将消息写入文件
	 *
	 * @param para
	 * @param gmo
	 * @return
	 * @throws Exception
	 */
	public static boolean getMsgFromQueueBySegment(byte[] grpId, MQCParameter para,
			int type, int timeout, String filename) throws EisException {
		
		//timeout = 0 : 取配置文件或缺省超时时间, timeout < 0 : 无限制读取消息, timeout > 0 : 取timeout值
		int to = timeout <= 0 ? getSubTimeOut() : timeout;
		MQGetMessageOptions gmo = getGMOFromPara(to);
		
		if (para.qManager == null || para.queue == null) {
			connectMQ(para, type);
		}
		
		gmo.options = 
		    MQC.MQGMO_LOGICAL_ORDER + MQC.MQGMO_SYNCPOINT + MQC.MQGMO_ALL_SEGMENTS_AVAILABLE;
		gmo.matchOptions = MQC.MQMO_MATCH_GROUP_ID;	
		
		int interval = getInterval();
		int trycount = getCount();
		
		boolean isLastSegment = false;
		FileOutputStream fout = null;
		
		try {
			fout = new FileOutputStream(filename);
		    while(!isLastSegment) {
		    	
		    	boolean received = false;
				int fetchCount = 0;		
				
				while (!received) {		
					MQMessage inMsg = new MQMessage(); 
					try {
						fetchCount++;				
				    	/*创建MQMessage 类*/
						
						inMsg.groupId = grpId;
			
						/*从队列到消息缓冲区获取消息*/
						para.queue.get(inMsg, gmo);
						
				        if (inMsg.messageFlags == MQC.MQMF_SEGMENT + MQC.MQMF_LAST_SEGMENT)
				            isLastSegment = true;
				        byte[] b = new byte[inMsg.getMessageLength()];
						inMsg.readFully(b);
						if (b != null) {
							fout.write(b);
							received = true;
						}
					} catch (MQException mqe) {
						int ret = handleMQException(mqe);
						if (fetchCount >= trycount) {
							try {
								inMsg.clearMessage();
							} catch (Exception e) {
								LogUtil.getInstance().error("Exception",e);
							}
							inMsg = null;
							LogUtil.getInstance().error("Can't fetch message for:",mqe);
							if(ret != MQ_TIME_OUT){
								para.release();
								LogUtil.getInstance().error("Exception",mqe);
							} 
							return false;
						} else {
							if(ret != MQ_TIME_OUT){
								para.release();
								if(!connectMQ(para, type, 1, interval)){
									inMsg = null;
									return false;
								}
							} 
						}				
					} catch (Exception ex) {
						if (fetchCount >= trycount) {
							try {
								inMsg.clearMessage();
							} catch (Exception e) {
								LogUtil.getInstance().error("Exception",e);
							}
							inMsg = null;							
							para.release();
							LogUtil.getInstance().error("Can't fetch message for ",ex);
							return false;
						} else {
							para.release();
							if(!connectMQ(para, type, 1, interval)){
								inMsg = null;
								return false;
							}
						}	
					} finally {
						try {
							if (inMsg != null)
								inMsg.clearMessage();
							inMsg = null;
						} catch (IOException e) {
							LogUtil.getInstance().error("Exception",e);
						}
					}
				}
		        
		    }
		} catch (Exception ex) {
			para.release();
			LogUtil.getInstance().error(" fetch message error : ", ex);
		} finally {
			if (fout != null)
				try {
					fout.close();
					fout = null;
				} catch (Exception e) {
					LogUtil.getInstance().error("Exception",e);
				}
			gmo = null;
		}
		
		return true;
			
	}
	

	/**
	 * 将响应消息放入发送队列
	 * @param para 连接实例
	 * @param message 准备发送的消息
	 * @param type 
	 * @return
	 * @throws EisException
	 */
	public static boolean putMsgToQueue(MQCParameter para, MQMessage message) throws Exception {
		MQPutMessageOptions pmo = getPMOFromPara();
		if (null == message || null == pmo || null == para) {
			throw new EisException(MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_CODE);
		}
		try {
				if (para.qManager == null || para.queue == null) {
					connectMQExce(para, MQQueueAccesser.MQ_MSGSEND_TYPE);
				}
				
				printMsgId("before put MsgId",message.messageId);
				LogUtil.getInstance().info("put message.replyToQueueManagerName:" + message.replyToQueueManagerName);
				LogUtil.getInstance().info("put message.messageType:" + message.messageType);
				LogUtil.getInstance().info("put message.report:" + message.report);
				LogUtil.getInstance().info("message.encoding:" + message.encoding);
				LogUtil.getInstance().info("message.characterSet:" + message.characterSet);
				LogUtil.getInstance().info("message.format:" + message.format);
				printMsgId("before put correlationId",message.correlationId);
				
				para.queue.put(message, pmo);
				para.qManager.commit();
				printMsgId("after put MsgId",message.messageId);
				return  true;
			
		} catch (MQException mqe) {
			throw mqe;
		} finally {
			pmo = null;
		}
	}
	
	/**
	 * 将消息按消息组方式放入响应队列
	 * 
	 * @param message
	 * @param para
	 * @param pmo
	 * @return byte[] message group id
	 * @throws EsbException
	 */
	public static byte[] putMsgToQueueBySegment(MQCParameter para, byte[] reqMsg, int type) throws EisException{
		
		if (reqMsg == null) 
			throw new EisException("Can't put null data into queue!");		
		MQPutMessageOptions pmo = getPMOFromPara();
		
		//Queue异常时做一次重新连接,如果连接失败直接返回null
		if (para.qManager == null || para.queue == null) {			
			connectMQ(para, type);
		}
		
		pmo.options = MQC.MQPMO_LOGICAL_ORDER + MQC.MQPMO_SYNCPOINT;
		byte[] grpId = null;
		int reqMsgLen = reqMsg.length;
		int tmpLen = reqMsgLen;
		MQMessage message = null;
		int segmentLen = getSegmentLength();
		int expiry = getExpiry();
		try {
			
			if (reqMsgLen == 0){
				message = new MQMessage();
				message.expiry = expiry * 10;
				message.messageFlags = MQC.MQMF_LAST_SEGMENT;
				
				try {							
					message.write(reqMsg);
					para.queue.put(message, pmo);
					grpId = message.groupId;
				} catch (MQException mqe) {
					para.release();
					if(mqe.completionCode == MQException.MQCC_FAILED){
						if(!connectMQ(para,type)){
							return null;
						}
						try {
							message.write(reqMsg);
							para.queue.put(message, pmo);
							grpId = message.groupId;
						} catch (Exception ex) {
							para.release();
							LogUtil.getInstance().error("Exception",mqe);
							throw new EisException(ex);							
						}
					} else {
						throw new EisException(mqe);			
					}										
				}
				grpId = message.groupId;
			}else{
				while (tmpLen > 0) {
					message = new MQMessage();
					message.expiry = expiry * 10;
					byte[] reqMsgSegment;
					if (tmpLen - segmentLen > 0) {				
						reqMsgSegment = new byte[segmentLen];
						System.arraycopy(reqMsg, reqMsgLen - tmpLen, reqMsgSegment, 0, segmentLen);
						tmpLen -= segmentLen;
						message.messageFlags = MQC.MQMF_SEGMENT;
					} else {
						reqMsgSegment = new byte[tmpLen];
						System.arraycopy(reqMsg, reqMsgLen - tmpLen, reqMsgSegment, 0, tmpLen);
						tmpLen = 0;
						message.messageFlags = MQC.MQMF_LAST_SEGMENT;
					}
					try {							
						message.write(reqMsgSegment);
						para.queue.put(message, pmo);
						grpId = message.groupId;
					} catch (MQException mqe) {
						para.release();
						if(mqe.completionCode == MQException.MQCC_FAILED){
							if(!connectMQ(para,type)){
								return null;
							}
							try {
								message.write(reqMsgSegment);
								para.queue.put(message, pmo);
								grpId = message.groupId;
							} catch (Exception ex) {
								para.release();
								LogUtil.getInstance().error("Exception",mqe);
								throw new EisException(ex);							
							}
						} else {
							throw new EisException(mqe);			
						}										
					}
					grpId = message.groupId;							
				}
			}
			
			para.qManager.commit();
		} catch (Exception e) {
			para.release();
			LogUtil.getInstance().error("Exception",e);
		} finally {
			try {
				if (message != null)
					message.clearMessage();
			} catch (IOException e) {
				LogUtil.getInstance().error("Exception",e);
			}
		}
		return grpId;
	}
	
	/**
	 * 将文件按消息组方式放入响应队列
	 * 
	 * @param message
	 * @param para
	 * @param pmo
	 * @return byte[] message group id
	 * @throws EsbException
	 */
	public static byte[] putMsgToQueueBySegment(MQCParameter para, String filename, int type) throws EisException{
		
		MQPutMessageOptions pmo = getPMOFromPara();
		
		//Queue异常时做一次重新连接,如果连接失败直接返回null
		if (para.qManager == null || para.queue == null) {			
			connectMQ(para, type);
		}
		InputStream fi = null;
		int reqMsgLen = 0 ;
		try {
			fi = new FileInputStream(filename);
			reqMsgLen = fi.available();
		} catch (Exception ex) {
			LogUtil.getInstance().error("Exception",ex);
			throw new EisException(ex);
		}
		
//		if (reqMsgLen <= 0) 
//			throw new EisException("Can't put null data into queue!");	
			
		pmo.options = MQC.MQPMO_LOGICAL_ORDER + MQC.MQPMO_SYNCPOINT;
		byte[] grpId = null;
		
		int tmpLen = reqMsgLen;
		MQMessage message = null;
		int segmentLen = getSegmentLength();
		int expiry = getExpiry();
		try {
			if (reqMsgLen == 0){
				byte[] reqMsgSegment;
				reqMsgSegment = new byte[reqMsgLen];
				fi.read(reqMsgSegment);
				
				message = new MQMessage();
				message.messageFlags = MQC.MQMF_LAST_SEGMENT;
				
				try {							
					message.write(reqMsgSegment);
					para.queue.put(message, pmo);
					grpId = message.groupId;
				} catch (MQException mqe) {
					para.release();
					if(mqe.completionCode == MQException.MQCC_FAILED){
						if(!connectMQ(para,type)){
							return null;
						}
						try {
							message.write(reqMsgSegment);
							para.queue.put(message, pmo);
							grpId = message.groupId;
						} catch (Exception ex) {
							para.release();
							LogUtil.getInstance().error("Exception",ex);
							throw new EisException(ex);							
						}
					} else {
						throw new EisException(mqe);			
					}										
				}
				grpId = message.groupId;	
			}else{
				while (tmpLen > 0) {
					message = new MQMessage();
					message.expiry = expiry * 10;
					byte[] reqMsgSegment;
					if (tmpLen - segmentLen > 0) {				
						reqMsgSegment = new byte[segmentLen];
						fi.read(reqMsgSegment);
						tmpLen -= segmentLen;
						message.messageFlags = MQC.MQMF_SEGMENT;
					} else {
						reqMsgSegment = new byte[tmpLen];
						fi.read(reqMsgSegment);
						tmpLen = 0;
						message.messageFlags = MQC.MQMF_LAST_SEGMENT;
					}
					try {							
						message.write(reqMsgSegment);
						para.queue.put(message, pmo);
						grpId = message.groupId;
					} catch (MQException mqe) {
						para.release();
						if(mqe.completionCode == MQException.MQCC_FAILED){
							if(!connectMQ(para,type)){
								return null;
							}
							try {
								message.write(reqMsgSegment);
								para.queue.put(message, pmo);
								grpId = message.groupId;
							} catch (Exception ex) {
								para.release();
								LogUtil.getInstance().error("Exception",mqe);
								throw new EisException(ex);							
							}
						} else {
							throw new EisException(mqe);			
						}										
					}
					grpId = message.groupId;							
				}
			}
			para.qManager.commit();
		} catch (Exception e) {
			para.release();
			LogUtil.getInstance().error("Exception",e);
		} finally {
			try {
				if (message != null)
					message.clearMessage();
				if (fi != null) {
					fi.close();
					fi = null;
				}
			} catch (IOException e) {
				LogUtil.getInstance().error("Exception",e);
			}
		}
		return grpId;
	}
	
	/**
	 * 打印msgId
	 * @param msg
	 * @param msgId
	 */
	public static void printMsgId(String msg,byte[] msgId){
		try{
			if (msgId == null){
				LogUtil.getInstance().info(msg + ":null");
			}else{
				LogUtil.getInstance().info(msg + ":" + HexString.BinaryToHexString(msgId));
			}
			
		}catch(Exception e){
			LogUtil.getInstance().error("encode err:",e);
		}
	}
	
	/**
	 * 统一处理MQException
	 *
	 * @param e
	 * @return int return 0 success; return 1 timeout; return -1 connection
	 *         broken; return 2 unknown exception.
	 */
	public static int handleMQException(MQException e) {
		int ret = MQ_UNKNOW_EXCEPTION;
		if (e.completionCode == MQException.MQCC_OK
				&& e.reasonCode == MQException.MQRC_NONE)
			ret = MQ_OK;
		else if (e.completionCode == MQException.MQCC_FAILED) {
			switch (e.reasonCode) {
			case MQException.MQRC_NO_MSG_AVAILABLE:
				ret = MQ_TIME_OUT;
				break;
			case MQException.MQRC_CONNECTION_QUIESCING:
			case MQException.MQRC_Q_MGR_NAME_ERROR:
			case MQException.MQRC_Q_MGR_NOT_AVAILABLE:
			case MQException.MQRC_SECURITY_ERROR:
			case MQException.MQRC_CONNECTION_STOPPING:
				ret = MQ_CONNECTION_BROKER;
				break;
			case MQException.MQRC_CONNECTION_BROKEN:
				ret =  MQ_CONNECTION_BROKEN_2009;
				break;
			default:
				ret = MQ_UNKNOW_EXCEPTION;
			}
		}
		return ret;
	}// end of method
	
	/**
	 * 连接到MQ队列管理器
	 * @param para 
	 * 			调用类的MQ连接配置参数
	 * @param type
	 * 			连接类型，0－接收该Queue队列的消息，1－向该Queue队列发送消息
	 * @return TRUE:连接成功；
	 * @throws EisException 连接失败则抛出异常
	 */
	public static boolean connectMQ(MQCParameter para, int type) throws EisException {
		try{
			int interval = getInterval();
			int trycount = getCount();
			return connectMQ(para, type, trycount, interval);
		}catch(Exception e){
			throw new EisException("不能连接到MQ Server :" + para.mqParameter.toString() +"]");
		}
		
	}
	
	public static boolean connectMQExce(MQCParameter para, int type) throws Exception {
		int interval = getInterval();
		int trycount = getCount();
		return connectMQ(para, type, trycount, interval);
	}
	
	/**
	 * 连接到MQ队列管理器
	 * @param para 连接对象
	 * @param type 连接类型（发送，接收）
	 * @param trycount 重试连接次数
	 * @param interval 重连等待时间
	 * @return TRUE:连接成功；FALSE:连接失败;
	 * @throws EisException 当重试连接次数都失败，则返回异常
	 */
	public static boolean connectMQ(MQCParameter para, int type, int trycount, int interval)
			throws Exception {
		
		LogUtil.getInstance().info("try to connect mq :" + para.mqParameter.toString());
		boolean ret = false;
		MQParameter mqParameter = para.mqParameter;
		Hashtable<String, Object> props = new Hashtable<String, Object>();
		if (mqParameter.getHostName() != null)
			props.put(MQC.HOST_NAME_PROPERTY, mqParameter.getHostName());
		if (mqParameter.getPort() != 0)
			props.put(MQC.PORT_PROPERTY, new Integer(mqParameter.getPort()));
		if (mqParameter.getChannel() != null)
			props.put(MQC.CHANNEL_PROPERTY, mqParameter.getChannel());
		if (mqParameter.getCcsid() != 0)
			props.put(MQC.CCSID_PROPERTY, new Integer(mqParameter.getCcsid()));
		// MQPoolToken token=MQEnvironment.addConnectionPoolToken();
		
		int i = 0;

		MQQueue queue = null;
		MQQueueManager qManager = null;
		while (trycount <= 0 || (trycount > 0 && i < trycount)) {
			i++;
			try {
				para.release();
				
				//连接到指定的队列管理器
				qManager = new MQQueueManager(mqParameter.getQManagerName(),props);
				
				//根据参数不同连接到Q队列上
				if (MQ_MSGRECEIVE_TYPE == type){
//					queue = qManager.accessQueue(mqParameter.getQueueName(),MQC.MQOO_INPUT_AS_Q_DEF);
					queue = qManager.accessQueue(mqParameter.getQueueName(),MQC.MQOO_INQUIRE | MQC.MQOO_FAIL_IF_QUIESCING | MQC.MQOO_INPUT_SHARED);
				}else if (MQ_MSGSEND_TYPE == type){
					queue = qManager.accessQueue(mqParameter.getQueueName(),MQC.MQOO_OUTPUT );
				}
				
				para.qManager = qManager;
				para.queue = queue;
				
				ret = true;
				break;
			} catch (MQException mqe) {
				LogUtil.getInstance().error(mqe);
				if (i == trycount) {
					LogUtil.getInstance().error(
								"不能连接到MQ Server :" + para.mqParameter.toString() +"]，" +
								"已经做了[" + i  + "]次尝试！");
					throw mqe;
				} else {
					try {
						// 在下一次重试之前等待一定时间
						Thread.sleep(interval);
					} catch (Exception e) {
						LogUtil.getInstance().error("Exception",e);
						throw new EisException("interrupted when connect sleeping");
					}
				}
			}
		}// end of while loop
		props.clear();
		return ret;
	}
	
	/**
	 * 将MQ消费转换成byte流返回
	 * @param msg
	 * @return
	 * @throws EisException
	 */
	@SuppressWarnings("unused")
	public static byte[] getBytesFromMQMessage(MQMessage msg)
			throws EisException {
		if (null == msg)
			return null;

		try {
			byte[] msgContent = new byte[msg.getMessageLength()];
			msg.readFully(msgContent);
			return msgContent;
		} catch (Exception t) {
			LogUtil.getInstance().error("Exception",t);
			if (msg != null)
				throw new EisException("|msgId=" + msg.messageId);
		}
		return null;
	}

	/**
	 * 将byte[]转换为MQMessage
	 *
	 * @param msg
	 * @return
	 */
	public static MQMessage getMQMessageFromBytes(byte[] msg)
			throws EisException {
		if (null == msg || msg.length <= 0)
			return null;

		MQMessage message = null;
		int expiry = getExpiry();
		try {
			// prepare the mq message
			message = new MQMessage();
			message.expiry = expiry;
			message.write(msg);
			return message;
		} catch (Exception t) {
			if (message != null) {
				LogUtil.getInstance().error("Exception",t);
				throw new EisException(
						"Fail to get message body from MQMessage|msgId="
								+ message.messageId);
			}
		}
		return null;
	}
	
	/**
	 * 尝试从队列中获取消息次数
	 * @return，默认值3次
	 */
	public static int getConnGetMsgCount(){
		String trycount ;
		try {
			trycount = CacheManager.getInstance().getConfig().getProperty(ConfigConstants.MQ_CONN_GETMSG_COUNT);			
		} catch (EisException e) {
			LogUtil.getInstance().error("Exception",e);
			return MQ_CONN_GETMSG_COUNT;
		}
		if (null == trycount)
			return MQ_CONN_GETMSG_COUNT;
		return Integer.parseInt(trycount);
	}
	
	/**
	 * 尝试从将消息放入到队列次数
	 * @return 默认值3
	 */
	public static int getConnPutMsgCount(){
		String trycount ;
		try {
			trycount = CacheManager.getInstance().getConfig().getProperty(ConfigConstants.MQ_CONN_PUTMSG_COUNT);			
		} catch (EisException e) {
			LogUtil.getInstance().error("Exception",e);
			return MQ_CONN_PUTMSG_COUNT;
		}
		if (null == trycount)
			return MQ_CONN_PUTMSG_COUNT;
		return Integer.parseInt(trycount);
	}
	
	/**
	 * 出现异常后重新连接次数,根据Config配置文件获取，默认值是3
	 * @return
	 */
	private static int getCount() {
		String trycount ;
		try {
			trycount = CacheManager.getInstance().getConfig().getProperty(ConfigConstants.MQ_CONN_TRY_COUNT);			
		} catch (EisException e) {
			LogUtil.getInstance().error("Exception",e);
			return MQ_TRY_COUNT;
		}
		if (null == trycount)
			return MQ_TRY_COUNT;
		return Integer.parseInt(trycount);
	}
	
	/**
	 * 连接出现异常后，等待时间，单位毫秒 ，默认值：2000
	 * @return
	 */
	private static int getInterval() {
		String tryInterval ;
		try {
			tryInterval = CacheManager.getInstance().getConfig().getProperty(ConfigConstants.MQ_CONN_TRY_WITETIME);			
		} catch (EisException e) {
			LogUtil.getInstance().error("Exception",e);
			return MQ_TRY_INTERVAL;
		}
		if (null == tryInterval)
			return MQ_TRY_INTERVAL;
		return Integer.parseInt(tryInterval);
	}
	
	private static int getSegmentLength() {
		String len ;
		try {
			len = CacheManager.getInstance().getConfig().getProperty(ConfigConstants.MQ_SEGMENT_LEN);			
		} catch (EisException e) {
			LogUtil.getInstance().error("Exception",e);
			return MQ_SEGMENT_LEN;
		}
		if (null == len)
			return MQ_SEGMENT_LEN;
		return Integer.parseInt(len);
	}
	
	/**
	 * 返回消息的有效时间
	 * @return
	 */
	private static int getExpiry() {
		String expiry ;
		try {
			expiry = CacheManager.getInstance().getConfig().getProperty(ConfigConstants.MQ_MSG_EXPIRY);			
		} catch (EisException e) {
			LogUtil.getInstance().error("Exception",e);
			return MQ_MSG_EXPIRY;
		}
		if (null == expiry)
			return MQ_MSG_EXPIRY;
		return Integer.parseInt(expiry);
	}
	
	
	
	
	private static int getSubTimeOut() {
//		String timeout ;
//		try {
//			timeout = CacheManager.getInstance().getConfig().getProperty(ConfigConstants.MQ_SUB_MSG_TIMEOUT);			
//		} catch (EisException e) {
//			LogUtil.getInstance().error(e);
//			return MQ_SUB_MSG_TIMEOUT;
//		}
//		if (null == timeout)
//			return MQ_SUB_MSG_TIMEOUT;
//		return Integer.parseInt(timeout);
		return 0;
	}
	
}// end of class
