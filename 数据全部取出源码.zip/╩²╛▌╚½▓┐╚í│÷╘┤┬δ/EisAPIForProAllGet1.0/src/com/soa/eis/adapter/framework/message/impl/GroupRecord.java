/*
 * Copyright (C) The IBM China BCS. All rights reserved.
 *
 */

package com.soa.eis.adapter.framework.message.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import com.soa.eis.adapter.framework.exception.EisException;


public class GroupRecord {
	//类型常量，代表普通String类型
	public final static String TYPE_STRING = "S";
	//类型常量，代表普通子GroupRecord类型，因为多半为GroupRecord的数组，所以命名为GA
	public final static String TYPE_GROUP_ARRAY = "G";
	
	//普通节点
	private Vector<String> fieldKeys = new Vector<String>(); //the name of every value
	private Vector<String> fieldValues = new Vector<String>(); //values
	
	//子节点
	private Vector<String> subKeys = new Vector<String>();
	private Vector<List<GroupRecord>> subValues = new Vector<List<GroupRecord>>();
	
	//group节点上的属性
	private Properties attributes = new Properties(); //record attributes 
	private String name; //the name of record
	private String type = TYPE_GROUP_ARRAY;
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	/**
	 * 设置本GroupRecord的名字
	 * @param nn
	 */
	public void setName(String nn) {
		name = nn;
	}

	/**
	 * 获取本GroupRecord的名字
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * 设置普通子域的值
	 * @param key
	 * @param value
	 */
	public void setFieldValue(String key, String value) {
		int i = fieldKeys.indexOf(key);
		if(i<0){
			fieldKeys.add(key);
			fieldValues.add((fieldKeys.size() - 1), value);
		}else{
			fieldValues.set(i, value);
		}
	}
	
	
	/**
	 * 设置Group子域的值，输入参数ArrayList中的每个成员都是一个名字与key相同的GroupRecord
	 * @param key
	 * @param groups
	 */
	public void setSubGroups(String key, List<GroupRecord> groups) {
		int i = subKeys.indexOf(key);
		if(i<0){
			subKeys.add(key);
			subValues.add((subKeys.size() - 1), groups);
		}else{
			subValues.set(i, groups);
		}
	}
	
	/**
	 * 统一返回一个索引顺序指定的域值，越界返回null
	 * @param i
	 * @return fieldvalue
	 */
	public String getFieldValue(int i){
		//越界则返回null
		if(i>=fieldKeys.size()||i<0) return null;
		return fieldValues.elementAt(i);
	}
	
	/**
	 * 统一返回一个域名指定的域值，越界返回null
	 * @param key
	 * @return fieldvalue
	 */
	public String getFieldValue(String key){
		int i = fieldKeys.indexOf(key);
		return getFieldValue(i);
	}
	
	/**
	 * 统一返回一个域名指定的域key，越界返回null
	 * @param i
	 * @return
	 */
	public String getFieldKey(int i){
		//越界则返回null
		if(i>=fieldKeys.size()||i<0) return null;
		return fieldKeys.elementAt(i);
	}
	
	/**
	 * 子节点的总数
	 * @return
	 */
	public int getSubGroupsSize(){
		return subKeys.size();
	}
	
	/**
	 * 通过通过顺序号域的值,用于子Group类型
	 * @param i
	 * @return subgroup(ArrayList)
	 * @throws EsbException
	 */
	public List<GroupRecord> getSubGroups(int i) {
		//越界则返回null
		if(i>=subKeys.size()||i<0) return null;
		return subValues.elementAt(i);
	}
	
	/**
	 * 通过域名获取域的值，用于子Group类型
	 * @param key
	 * @return subgroup(ArrayList)
	 * @throws EsbException
	 */
	public List<GroupRecord> getSubGroups(String key) throws EisException{
		return getSubGroups(subKeys.indexOf(key));
	}
	
	
	/**
	 * 根据索引得到一个key值
	 * @param i
	 * @return subkey
	 * @throws EsbException
	 */
	public String getSubKey(int i){
		//越界则返回null
		if(i>=subKeys.size()||i<0) return null;
		
		Object obj = subKeys.elementAt(i);
		if(null==obj) return null;
		return (String)obj;
	}
	
	
	/**
	 * 返回Group的大小，即包含多少子域，这里将所有同名的子Group算作一个域
	 * @return valuesize
	 */
	public int getFieldSize() {
		return fieldKeys.size();
	}
	
	/**
	 * 设置域属性
	 * @param key
	 * @param attr
	 */
	public void setAttribute(String key, String attr) {
		attributes.setProperty(key, attr);
	}
	
	/**
	 * 获取域属性
	 * @param key
	 * @return attribute
	 */
	public String getAttribute(String key) {
		return attributes.getProperty(key);
	}

	public void setAttributes(Properties attr) {
		attributes = attr;
	}
	public Properties getAttributes() {
		return attributes;
	}
	
	
	@SuppressWarnings("unchecked")
	private String toString(int level) {
		StringBuffer sb = new StringBuffer();
		for(int j=0; j<level; j++)
			sb.append("\t");
		sb.append("GroupRecord\t" + name );
		
		sb.append("[");
		// 填充原有的属性值
		Iterator<Map.Entry<Object, Object>> it = getAttributes().entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<Object, Object> pairs = (Map.Entry<Object, Object>) it.next();
			sb.append(pairs.getKey().toString() + "=" + pairs.getValue().toString());
			sb.append(";");
		}
		sb.append("]");
		sb.append("\n");
		for(int i=0; i<this.getFieldSize(); i++){
			String key = this.getFieldKey(i);
			String value = this.getFieldValue(i);
			
			for(int j=0; j<=level; j++)
				sb.append("\t");
			
			sb.append(key + "=" + value + "\n");
		}
		
		for (int i = 0; i < this.getSubGroupsSize(); i ++){
			List<GroupRecord> al = this.getSubGroups(i);
			for (int j = 0;j < al.size(); j ++){
				GroupRecord gr = (GroupRecord)al.get(j);
				sb.append(gr.toString(level+1));
			}
		}
		
		return sb.toString();
	}
	
	
	public String toString() {
			return toString(0);
		}
	
	public static void main(String[] args) {
		GroupRecord gr = new GroupRecord();
		gr.setName("i_1");
//	gr.setAttribute("loop_num", "3");
		gr.setFieldValue("i_a1", "av");
		gr.setFieldValue("i_a2", "av");
		
		List<GroupRecord> grList2 = new ArrayList<GroupRecord>();
		for (int j = 0; j < 4; j++) {
			GroupRecord gr1 = new GroupRecord();
			gr1.setName("j_2");
			gr1.setFieldValue("j_b1", "bv");
			gr1.setFieldValue("j_b2", "bv");
			
			List<GroupRecord> grList3 = new ArrayList<GroupRecord>();
			for (int k = 0; k < 4; k++) {
				GroupRecord gr2 = new GroupRecord();
				gr2.setName("k_3");
				gr2.setFieldValue("k_c1", "bv");
				gr2.setFieldValue("k_c2", "bv");
				grList3.add(gr2);
			}
			gr1.setSubGroups("gr2", grList3);
			
			grList2.add(gr1);
		}
		gr.setSubGroups("gr1", grList2);
		
		System.out.println(gr);
	}
	
}//end of class