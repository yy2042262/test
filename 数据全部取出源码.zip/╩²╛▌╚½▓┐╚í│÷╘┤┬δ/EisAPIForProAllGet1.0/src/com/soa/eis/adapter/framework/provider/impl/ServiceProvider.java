package com.soa.eis.adapter.framework.provider.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.soa.eis.adapter.framework.common.CacheManager;
import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.handler.IServiceHandler;
import com.soa.eis.adapter.framework.provider.IServiceProvider;

public class ServiceProvider {
	
	private static ServiceProvider sp = null;
	private List<IServiceProvider> ProviderList = new ArrayList<IServiceProvider>();
	
	private ServiceProvider() throws EisException{
		init();
	}
	
//	public synchronized static ServiceProvider getInstance() throws EisException{
//		if (sp == null){
//			sp = new ServiceProvider();
//		}
//		return sp;
//	}
	
	private ServiceProvider(IServiceHandler serviceHandler) throws EisException{
		//加入主MQ队列管理器监控
		ProviderList.add(new BaseServiceProvider(serviceHandler));
		
		//加入备份MQ队列管理器监控
		Properties config = CacheManager.getInstance().getConfig();
		String AltConfig = config.getProperty(ConfigConstants.ALTERNATIVE_PROVIDER_CONFIG);
		if(AltConfig != null && !"".equals(AltConfig.trim())){
			String[] alts = AltConfig.split(ConfigConstants.ALTERNATIVE_CONFIG_SPLIT);
			for(String alt : alts){
				ProviderList.add(new BaseServiceProvider(serviceHandler, alt));
			}
		}
		
		init();
	}
	
	public synchronized static ServiceProvider getInstance(IServiceHandler serviceHandler) throws EisException{
		if (sp == null){
			sp = new ServiceProvider(serviceHandler);
		}
		return sp;
	}
	
	private void init() throws EisException{
		for(IServiceProvider Provider : ProviderList){
			//获取提供方处理线程数
			int providerThreadNum = Integer.parseInt(CacheManager.getInstance()
					.getConfig().getProperty(ConfigConstants.MQ_PROVIDER_POOL_MAXNUM));

			//生成处理线程
			for (int i = 0; i < providerThreadNum; i++) {
				new Thread(Provider).start();
			}
		}
	}
	
	public void start() throws EisException{
		for(IServiceProvider Provider : ProviderList){
			//启动处理线程
			Provider.start();
		}
	}
	
	public void stop(){
		for(IServiceProvider Provider : ProviderList){
			Provider.closeConnection();
			Provider.stop();
		}
	}
	
}
