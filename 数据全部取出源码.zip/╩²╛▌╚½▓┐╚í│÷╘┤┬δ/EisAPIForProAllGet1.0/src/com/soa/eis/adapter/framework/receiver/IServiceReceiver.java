/**
 * 
 */
package com.soa.eis.adapter.framework.receiver;

import com.soa.eis.adapter.framework.exception.EisException;

/**
 * @author wangtao
 *
 */
public interface IServiceReceiver {
	/**
	 * @param group id or message id
	 * @return received message
	 * @throws AdapterException
	 */
	public byte[] execute(byte[] id) throws EisException;
	
	/**
	 * @param group id or message id
	 * @param file name which will be writed
	 * @return write file successfully or failed (true/false)
	 * @throws EisException
	 */
	public boolean execute(byte[] id, String filename) throws EisException;
}
