package com.soa.eis.adapter.framework.connection.mqcm;

import java.util.ArrayList;
import java.util.List;

import com.soa.eis.adapter.framework.connection.IConnection;
import com.soa.eis.adapter.framework.connection.IConnectionPoolManager;
import com.soa.eis.adapter.framework.connection.mqc.MQParameter;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.utils.log.LogUtil;


/**
 * Poolable implementation of mq service connection manager.
 * <p>
 *
 * This implementation will hold connections in pool for reuse.
 *
 */
public class PoolableMQConnectionManager implements IConnectionPoolManager {

	private MQConnectionPool pool;
	
	private List<MQParameter> sendQueueList = new ArrayList<MQParameter>();
	private List<MQParameter> receiveQueueList = new ArrayList<MQParameter>();
	
	/**
	 * @param sendQueue
	 * @param receiveQueue
	 * @param maxActive
	 *            max connection in pool
	 * @param maxWait
	 *            max time to wait for a connection (second)
	 */
	public PoolableMQConnectionManager(MQParameter sendQueue,
			MQParameter receiveQueue, int maxActive, int maxWait) {
		this.sendQueueList.add(sendQueue);
		this.receiveQueueList.add(receiveQueue);
		this.pool = new MQConnectionPool(this, maxActive, maxWait);
	}
	
	public PoolableMQConnectionManager(List<MQParameter> sendQueueList,
			List<MQParameter> receiveQueueList, int maxActive, int maxWait) {
		this.sendQueueList = sendQueueList;
		this.receiveQueueList = receiveQueueList;
		this.pool = new MQConnectionPool(this, maxActive, maxWait);
	}
	
	/**
	 * 从对象池中获取一个对象
	 */
	public IConnection getConnection() throws EisException {
		IConnection connection = null;
		try {
			synchronized (pool) {
				connection = (IConnection) pool.borrowObject();
			}
		} catch (Exception e) {
			LogUtil.getInstance().error("Fail to get connection.",e);
			throw new EisException(e);
		}
		return connection;
	}
	
	/**
	 * 将连接返回到对象池
	 */
	public void releaseConnection(IConnection connection) throws EisException {
		try {
			synchronized (pool) {
				if (null != connection)
					pool.returnObject(connection);
				connection = null;
			}
		} catch (Exception e) {
			LogUtil.getInstance().error("Fail to release connection.",e);
			throw new EisException(e);
		}
	}
	
	/**
	 * 关闭对象池中所有连接
	 */
	public void close() throws EisException {
		try {
			synchronized (pool) {
				if (null != pool)
					pool.close();
			}
		} catch (Exception e) {
			LogUtil.getInstance().error("Fail to close connection pool.",e);
			throw new EisException(e);
		}
	}
	
	
	public List<MQParameter> getSendQueue() {
		return sendQueueList;
	}

	public List<MQParameter> getReceiveQueue() {
		return receiveQueueList;
	}

}
