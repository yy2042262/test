package com.soa.eis.adapter.framework.connection.mqcm;

import org.apache.commons.pool.impl.GenericObjectPool;

public class MQConnectionPool extends GenericObjectPool {

	public static int MAX_MAX_ACTIVE = 100;

	public MQConnectionPool(PoolableMQConnectionManager manager, int maxActive,
			int maxWait) {
		super(new MQConnectionPoolFactory(manager),
				maxActive > MAX_MAX_ACTIVE ? MAX_MAX_ACTIVE : maxActive,
				WHEN_EXHAUSTED_BLOCK, maxWait * 1000);
	}
}
