
package com.soa.eis.adapter.framework.connection;

import com.soa.eis.adapter.framework.exception.EisException;


/**
 * 连接管理服务接口
 *  
 */
public interface IConnectionManager {

	/**
	 * For service requester, get connection to service provider.
	 *
	 * @return connection instance
	 * @throws EisException
	 */
	public IConnection getConnection() throws EisException;

	/**
	 * 
	 * @param connection
	 * @throws EisException
	 */
	public void releaseConnection(IConnection connection) throws EisException;
	
}
