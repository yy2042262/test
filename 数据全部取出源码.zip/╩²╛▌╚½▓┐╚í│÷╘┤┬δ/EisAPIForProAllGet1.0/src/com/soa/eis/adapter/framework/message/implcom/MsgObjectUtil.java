package com.soa.eis.adapter.framework.message.implcom;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import com.soa.eis.adapter.framework.message.IMsgObject;

public class MsgObjectUtil {
	
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat(
	"yyyyMMddHHmmss");
	
	
	public static final String generateServiceDateTime(long milliseconds) {
		Date date = new Date(milliseconds);
		String dateString = dateFormat.format(date);
		return dateString;
	}
	
	public static final String generateServiceDateTime() {
		return generateServiceDateTime(System.currentTimeMillis());
	}
	
	public static HashMap<String, String> mergeHashMap(
			HashMap<String, String> hashmap1, HashMap<String, String> hashmap2) {
		if (hashmap1 == null && hashmap2 != null)
			return hashmap2;
		else if (hashmap1 != null && hashmap2 == null)
			return hashmap1;
		else if (hashmap1 != null && hashmap2 != null) {
			hashmap1.putAll(hashmap2);
			return hashmap1;
		} else
			return null;
	}
	
	/**
	 * 业务异常
	 * @param mo
	 * @param msg
	 */
	public static void doProHandelError(IMsgObject mo,String msg){
		mo.setServResStatus(MsgConstants.STATUS_FAIL);
		mo.setServResCode(MsgConstants.API_ERROR_CODE);
		mo.setServResDesc(msg);
	}
}
