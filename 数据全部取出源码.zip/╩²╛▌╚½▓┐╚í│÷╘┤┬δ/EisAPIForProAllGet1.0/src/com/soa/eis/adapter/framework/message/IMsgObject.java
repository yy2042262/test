/**
 * 
 */
package com.soa.eis.adapter.framework.message;

import java.util.List;

import org.dom4j.Element;

import com.soa.eis.adapter.framework.message.impl.GroupRecord;

/**
 * 标准报文对象类接口.
 * @author wangtao
 *
 */
public interface IMsgObject {
	
	public enum MOType{
		/**
		 * 请求方mo类型标志
		 */
		initSR,
		/**
		 * 提供方mo类型标志
		 */
		initSP
	};
	
	/**
	 * 拷贝一个mo对象
	 * @return
	 */
	public IMsgObject clone();
	/**
	 * 返回字节组.
	 * @return
	 */
	public byte[] getBytes();
	/**
	 * 返回字符串.
	 * @return
	 */
	public String toString();
	
	//public void cloneMo(IMsgObject);
	
	/**
	 * 返回业务编号
	 */
	public String getBusinessCode();
	
	/**
	 * 设置业务编号
	 * @param code
	 */
	public void setBusinessCode(String code);
	
	/**
	 * 返回源系统代码.
	 * @return
	 */
	public String getSourceSysID();
	/**
	 * 设置源系统代码.
	 * @param value
	 */
	public void setSourceSysID(String value);
	/**
	 * 返回服务码.
	 * @return
	 */
	public String getServiceID();
	/**
	 * 设置服务码.
	 * @param value
	 */
	public void setServiceID(String value);
	/**
	 * 返回服务流水号
	 * @return
	 */
	public String getSerialNO();
	/**
	 * 设置服务流水号
	 * @param value
	 */
	public void setSerialNO(String value);
	/**
	 * 返回服务时间
	 * <p>
	 * 服务时间格式为 YYYYMMDDHHMMSS,由源系统/数据转换机负责填充.
	 * @return
	 */
	public String getServiceDateTime();
	/**
	 * 设置服务时间
	 * <p>
	 * 服务时间格式为 YYYYMMDDHHMMSS,由源系统/数据转换机负责填充.
	 * @param value
	 */
	public void setServiceDateTime(String value);
	/**
	 * 返回ESB服务响应状态.
	 * @return
	 */
	public String getServResStatus();
	
	
	/**
	 * 
	 * 设置ESB服务响应状态.
	 * @param value
	 */
	public void setServResStatus(String value);
	/**
	 * 返回服务返回编码.
	 * @return
	 */
	public String getServResCode();
	/**
	 * 设置服务返回编码.
	 * @param value
	 */
	public void setServResCode(String value);
	/**
	 * 返回ESB返回描述.
	 * @return
	 */
	public String getServResDesc();
	/**
	 * 设置ESB返回描述.
	 * @param value
	 */
	public void setServResDesc(String value);
	/**
	 * 返回服务方系统编号.
	 * @return
	 */
	public String getServResSourceSysCode();
	/**
	 * 设置服务方系统编号.
	 * @param value
	 */
	public void setServResSourceSysCode(String value);
	/**
	 * 返回服务方系统返回描述.
	 * @return
	 */
	public String getServResSourceSysDesc();
	/**
	 * 设置服务方系统返回描述.
	 * @param value
	 */
	public void setServResSourceSysDesc(String value);
	
	/**
	 * 返回Control元素字节点值.
	 * @param key
	 * @return
	 */
	public String getControlValue(String key);
	/**
	 * 设置Control元素字节点值.
	 * @param key
	 * @param value
	 */
	public void setControlValue(String key,String value);
	/**
	 * 返回请求元素中,key对应的值.
	 * @param key
	 * @return
	 */
	public String getReqValue(String key);
	/**
	 * 设置请求元素中,key对应的值.
	 * @param key
	 * @param value
	 */
	public void setReqValue(String key,String value);
	/**
	 * 返回请求元素中的记录集.
	 * @return
	 */
	public List<GroupRecord> getReqGroupRecord(String key);
	/**
	 * 设置请求元素中的记录集.
	 * @param gr
	 */
	public void setReqGroupRecord(List<GroupRecord> gr);
	/**
	 * 设置响应元素中,key键对应的值.
	 * @param key
	 * @param value
	 */
	public void setResValue(String key,String value);
	/**
	 * 返回响应元素中,key键对应的值.
	 * @param key
	 * @return
	 */
	public String getResValue(String key);
	/**
	 * 返回响应元素中的记录集.
	 * @return
	 */
	public List<GroupRecord> getResGroupRecord(String key);
	/**
	 * 设置响应元素中的记录集.
	 * @param gr
	 */
	public void setResGroupRecord(List<GroupRecord> gr);
	/**
	 * 删除 Response 元素
	 */
	public void removeResponseElement();
	/**
	 * 删除 Request 元素
	 */
	public void removeRequestElement();
	
	/**
	 * 返回提供方适配器队列管理器
	 * @return
	 */
	public String getProReplyQmgr();
	
	/**
	 * 返回报文版本号
	 * @return
	 */
	public String getVersionID();
	
	/**
	 * 设置报文版本号
	 * @param versionID
	 */
	public void setVersionID(String versionID);
	
	/**
	 * 获取Route节点
	 * @return
	 */
	public Element getRoute();
	
}
