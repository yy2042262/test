package com.soa.eis.adapter.framework.handler;

import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.message.IMsgObject;
/**
 * 服务响应处理接口
 * @author wangtao
 *
 */
public interface IServiceHandler {
	/**
	 * 服务方处理方法,处理请求方的请求报文,并返回报文
	 * @param reqMo request message object
	 * @return response message object
	 * @throws EisException
	 */
	public IMsgObject execute(IMsgObject reqMo) throws EisException;

	/**
	 * @param exception EisException
	 */
	public void handleException(EisException exception);
}
