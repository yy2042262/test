/**
 * 
 */
package com.soa.eis.adapter.framework.sender;

import com.soa.eis.adapter.framework.exception.EisException;

/**
 * @author wangtao
 *
 */
public interface IServiceSender {
	/**
	 * @param request message
	 * @return group id or message id
	 * @throws AdapterException
	 */
	public byte[] execute(byte[] msg) throws EisException;
	
	/**
	 * @param request message which is read from file
	 * @return group id or message id
	 * @throws AdapterException
	 */
	public byte[] execute(String filename) throws EisException;

}
