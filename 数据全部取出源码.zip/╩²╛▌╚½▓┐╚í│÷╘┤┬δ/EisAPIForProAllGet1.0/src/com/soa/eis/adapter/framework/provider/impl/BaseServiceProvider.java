package com.soa.eis.adapter.framework.provider.impl;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.connection.IConnection;
import com.soa.eis.adapter.framework.connection.mqc.MQCException;
import com.soa.eis.adapter.framework.connection.mqc.MQMsgRef;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.handler.IServiceHandler;
import com.soa.eis.adapter.framework.message.IMsgObject;
import com.soa.eis.adapter.framework.message.impl.MsgObject;
import com.soa.eis.adapter.framework.message.implcom.MsgConstants;
import com.soa.eis.adapter.framework.provider.IServiceProvider;
import com.soa.eis.adapter.framework.utils.log.LogUtil;

public class BaseServiceProvider extends AbstractServiceProvider implements
		Runnable, IServiceProvider {
	
	public static IServiceProvider provider =null;
	
//	private static volatile List<MQMsgRef> getMsgList = Collections.synchronizedList(new LinkedList<MQMsgRef>());
//	private static volatile List<MQMsgRef> putMsgList = Collections.synchronizedList(new LinkedList<MQMsgRef>());
	private ExecutorService connFixedThreadPool = Executors
			.newFixedThreadPool(Integer.valueOf(config
					.getProperty(ConfigConstants.MQ_PROVIDER_POOL_MAXNUM)));
	private ExecutorService handleFixedThreadPool = Executors
			.newFixedThreadPool(Integer.valueOf(config
					.getProperty(ConfigConstants.PROVIDER_HANDLER_MAXNUM)));
	

	//构造方法1，使用配置文件的ServiceHandler
	public BaseServiceProvider() throws EisException {
		super();
	}
	public synchronized static IServiceProvider getInstance() throws EisException {
		if (null == provider) {
			provider = new BaseServiceProvider();
		}
		return provider;
	}
	
	//构造方法2，接收参数的ServiceHandler
	public BaseServiceProvider(IServiceHandler serviceHandler) throws EisException {
		super();
		setServiceHandler(serviceHandler);
	}
	public synchronized static IServiceProvider getInstance(IServiceHandler serviceHandler) throws EisException {
		if (null == provider) {
			provider = new BaseServiceProvider(serviceHandler);
		}
		return provider;
	}
	
	//构造方法3，接收参数的ServiceHandler，启动备用ESB_OUT监听
	public BaseServiceProvider(IServiceHandler serviceHandler, String alt) throws EisException {
		super(alt);
		setServiceHandler(serviceHandler);
	}
	public synchronized static IServiceProvider getInstance(IServiceHandler serviceHandler, String alt) throws EisException {
		if (null == provider) {
			provider = new BaseServiceProvider(serviceHandler, alt);
		}
		return provider;
	}
	

	/**
	 * 以前的处理方法
	 * @throws EisException
	 */
	protected void process2() throws EisException {
		IConnection connection = null;
		MQMsgRef reqMsgRef = null;
		try {
			MQMsgRef sendMsg = new MQMsgRef();
			
			connection = getConnectionPoolManager().getConnection();
			reqMsgRef = connection.receive(getProviderRecvTimeOut());
			sendMsg.MQMsgId = reqMsgRef.MQMsgId;
			
			IMsgObject reqMo = new MsgObject(reqMsgRef.MQMsgBody,IMsgObject.MOType.initSP);
			sendMsg.ReplyToQMgr = reqMo.getProReplyQmgr();
			try{
				IMsgObject resMo = (IMsgObject) handler.execute(reqMo);
				
				String status = resMo.getServResStatus();
				if (status != null && status.equals(MsgConstants.STATUS_INPROCESS)){
					resMo.setServResStatus(MsgConstants.STATUS_COMPLETE);
				}
				
				String code = resMo.getServResCode();
				if (code == null){
					resMo.setServResCode(MsgConstants.SUCCEED_CODE);
				}
				
				sendMsg.MQMsgBody = resMo.getBytes();
				connection.send(sendMsg);
			}catch(Exception e){
				reqMo.setServResStatus(MsgConstants.STATUS_FAIL);
				reqMo.setServResCode(MsgConstants.API_ERROR_CODE);
				reqMo.setServResDesc(e.getMessage());
				
				sendMsg.MQMsgBody = reqMo.getBytes();
				connection.send(sendMsg);
				throw new EisException(e);
			}
		} catch (EisException e) {
			if (!MQCException.MQ_MSG_RECEIVE_GETMSG_TIMEOUT_EXCEPTION_CODE.equals(e.getCode())){
				if (reqMsgRef != null) {
					throw e;
				}
				logUtil.error("Error in Basescribe Service Requester:",e);
				throw e;
			}
		}catch (Exception e) {
			logUtil.error("Error in Basescribe Service Requester:",e);
//			if (reqMsgRef != null) {
//				throw new EisException(e);
//			}
			throw new EisException(e);
		}finally {
			if (connection != null){
				connection.release();
				getConnectionPoolManager().releaseConnection(connection);
				connection = null;
			}
		}

	}
	
	@Override
	protected void process() throws EisException {
		IConnection connection = null;
		try {
			connection = getConnectionPoolManager().getConnection();
			final MQMsgRef reqMsgRef = connection.receive(getProviderRecvTimeOut());
			final IMsgObject reqMo = new MsgObject(reqMsgRef.MQMsgBody,IMsgObject.MOType.initSP);
			
			//用线程池处理业务
			handleFixedThreadPool.execute(new Runnable(){
				@Override
				public void run() {
					try {
						IMsgObject resMo = (IMsgObject) handler.execute(reqMo);
						
						String status = resMo.getServResStatus();
						if (status != null && status.equals(MsgConstants.STATUS_INPROCESS)){
							resMo.setServResStatus(MsgConstants.STATUS_COMPLETE);
						}
						
						String code = resMo.getServResCode();
						if (code == null){
							resMo.setServResCode(MsgConstants.SUCCEED_CODE);
						}
						
						//组装返回消息
						MQMsgRef sendMsg = new MQMsgRef();
						sendMsg.MQMsgId = reqMsgRef.MQMsgId;
						sendMsg.ReplyToQMgr = reqMo.getProReplyQmgr();
						sendMsg.MQMsgBody = resMo.getBytes();
						final MQMsgRef finalSendMsg = sendMsg;
						
						//用线程池返回消息到ESB
						connFixedThreadPool.execute(new Runnable(){
							@Override
							public void run() {
								IConnection sendConnection = null;
								try {
									sendConnection = getConnectionPoolManager().getConnection();
									sendConnection.send(finalSendMsg);
								} catch (EisException e) {
									e.printStackTrace();
								} finally {
									if(sendConnection != null){
										try {
//											sendConnection.release();
											getConnectionPoolManager().releaseConnection(sendConnection);
											sendConnection = null;
										} catch (EisException e) {
											e.printStackTrace();
										}
									}
								}
							}
						});
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		} catch (EisException e) {
			if (!MQCException.MQ_MSG_RECEIVE_GETMSG_TIMEOUT_EXCEPTION_CODE.equals(e.getCode())){
				logUtil.error("Error in Basescribe Service Requester:",e);
				throw e;
			}
		} catch (Exception e) {
			logUtil.error("Error in Basescribe Service Requester:",e);
			throw new EisException(e);
		} finally {
			if (connection != null){
//				connection.release();
				getConnectionPoolManager().releaseConnection(connection);
				connection = null;
			}
		}
	}
	
	@Override
	public void closeConnection() {
		try{
			this.getConnectionPoolManager().close();
			provider = null;
		}catch(Exception e){
			logUtil.error("closePool:", e);
		}
	}
}
