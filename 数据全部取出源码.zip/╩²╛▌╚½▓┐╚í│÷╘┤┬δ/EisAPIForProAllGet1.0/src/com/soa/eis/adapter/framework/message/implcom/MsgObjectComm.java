package com.soa.eis.adapter.framework.message.implcom;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Text;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.message.IMsgObject.MOType;
import com.soa.eis.adapter.framework.message.impl.GroupRecord;

public class MsgObjectComm {
	
	
//
//	/** 请求方mo类型标志 */
//	public static final int initSR = 0;
//	/** 提供方mo类型标志 */
//	public static final int initSP = 1;

	protected String xpath = "/";
	/**
	 * Xpath关键字
	 */
	protected String child = "child::";
	
	/**
	 * XML对象
	 */
	protected Document document;
	/**
	 * 根节点
	 */
	protected Element Service;
	protected String servicePath = xpath + MsgConstants.Service + xpath;

	/**
	 * 路由节点
	 */
	protected Element Route = null;
	protected String routePath = servicePath + MsgConstants.ROUTE;
	
	/**
	 * 服务响应节点
	 */
	protected Element servResponse = null;
	protected String servResponsePath = routePath + xpath	+ MsgConstants.SERVICE_RESPONSE;
	
	/**
	 * 交易路由信息
	 */
	protected Element processes = null;
	protected String processesPath = routePath + xpath + MsgConstants.PROCESSES;
	

	/**
	 * 当前交易路由信息
	 */
	protected String curProcessKey = null;
	protected Element curProcess = null;
	protected String curProcessPath = processesPath + xpath + MsgConstants.PROCESS;

	// body
	protected Element Data = null;
	protected String dataPath = servicePath + MsgConstants.DATA;
	
	protected Element control = null;
	protected String controlPath = dataPath + xpath + MsgConstants.DATA_CONTROL;
	
	protected Element request = null;
	protected String requestPath = dataPath + xpath + MsgConstants.DATA_REQUEST;
	
	protected Element response = null;
	protected String responsePath = dataPath + xpath + MsgConstants.DATA_RESPONSE;
	
	protected Element curResponse = null;
	protected String curResponsePath = dataPath + xpath	+ MsgConstants.DATA_RESPONSE;
	
	
	
	public Document getDocument() {
		return document;
	}

	public Element getService() {
		return Service;
	}

	public Element getRoute() {
		return Route;
	}

	public Element getServResponse() {
		return servResponse;
	}

	public Element getProcesses() {
		return processes;
	}

	public Element getCurProcess() {
		return curProcess;
	}

	public Element getData() {
		return Data;
	}

	public Element getControl() {
		return control;
	}

	public Element getRequest() {
		return request;
	}

	public Element getResponse() {
		return response;
	}

	public Element getCurResponse() {
		return curResponse;
	}

	
	/**
	 * 根据mo类型构造mo。
	 * 
	 * @param initPara
	 *            mo类型，取值为{@link #initSR}或{@link #initSP}。
	 * @throws Exception
	 */
	public MsgObjectComm(MOType mt) throws Exception {
		switch (mt) {
		case initSR:
			initSR();
			break;
		case initSP:
			initSP();
			break;
		default:
			throw new EisException(MsgConstants.MSG_STRUCTURE_ERRCODE,
					MsgConstants.MSG_STRUCTURE_ERRDESC + "- initPara参数非法");
		}
	}

	/**
	 * 请求报文对象构造方法
	 */
	protected void initSP() {
		document = DomOperation.getDocument();

		Service = document.addElement(MsgConstants.Service);

		Route = DomOperation.addChildValueByName(Service, MsgConstants.ROUTE,
				null);
		servResponse = DomOperation.addChildValueByName(Route,
				MsgConstants.SERVICE_RESPONSE, null);
		processes = DomOperation.addChildValueByName(Route,
				MsgConstants.PROCESSES, null);
		curProcessKey = "1";
		DomOperation.addAttribute(processes, MsgConstants.MSG_SERV_CURRENT,
				curProcessKey);
		DomOperation.addAttribute(processes, MsgConstants.MSG_SERV_TOTAL,
				curProcessKey);

		curProcess = DomOperation.addChildValueByName(processes,
				MsgConstants.PROCESS, null);
		DomOperation.addAttribute(curProcess, MsgConstants.MSG_SERV_PROCESS_ID,
				curProcessKey);

		Data = DomOperation.addChildValueByName(Service, MsgConstants.DATA, null);
		control = DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_CONTROL, null);
		request = DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_REQUEST, null);
		curResponse = DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_RESPONSE, null);

	}

	/**
	 * 响应报文对象构造方法
	 */
	protected void initSR() {
		document = DomOperation.getDocument();

		Service = document.addElement(MsgConstants.Service);

		Route = DomOperation.addChildValueByName(Service, MsgConstants.ROUTE,
				null);
		servResponse = DomOperation.addChildValueByName(Route,
				MsgConstants.SERVICE_RESPONSE, null);

		Data = DomOperation.addChildValueByName(Service, MsgConstants.DATA, null);
		control = DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_CONTROL, null);
		request = DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_REQUEST, null);
		response = DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_RESPONSE, null);
	}

	/**
	 * 根据xml字节流，解析并生成mo。
	 * 
	 * @param bytesinput
	 *            xml字节流
	 * @param endType
	 *            mo类型，取值为{@link #initSR}或{@link #initSP}。
	 * @throws Exception
	 */
	public MsgObjectComm(byte[] bytesinput, MOType mt) throws Exception {
		document = DomOperation.getDocument(bytesinput);
		switch (mt) {
		case initSR:
			paserSR();
			break;
		case initSP:
			paserSP();
			break;
		default:
			throw new EisException(MsgConstants.MSG_STRUCTURE_ERRCODE,
			"- initPara参数非法");
		}
	}

	/**
	 * 请求报文读取方法
	 */
	protected void paserSR() {
		Service = document.getRootElement();
		if (null != Service) {
			Route = DomOperation.getElementByXpath(document, routePath);
			Data = DomOperation.getElementByXpath(document, dataPath);
			if (null != Route) {
				processes = DomOperation.getElementByXpath(document,
						processesPath);
				servResponse = DomOperation.getElementByXpath(document,
						servResponsePath);
				if (processes != null) {
					Route.remove(servResponse);
					servResponse = null;
				}
				if (servResponse!=null
						&& servResponse.elements().size() > 0) {
				} else {
					Route.remove(servResponse);
					servResponse = null;
				}
				
			}
//			else{
//				header = DomOperation.addChildValueByName(root, MsgConstants.ROUTE,
//						null);
//			}
			if(null != Data){
				control = DomOperation.getElementByXpath(document, controlPath);
//				if(null != control)control = DomOperation.addChildValueByName(body,MsgConstants.DATA_CONTROL, null);
				request = DomOperation.getElementByXpath(document, requestPath);
//				if(null != request) request = DomOperation.addChildValueByName(body,
//						MsgConstants.DATA_REQUEST, null);
				response = DomOperation.getElementByXpath(document, responsePath);
				if(response.attributeCount() > 0){
					Data.remove(response);
					response = null;
				}
			}
//			else{
//				body = DomOperation.addChildValueByName(root, MsgConstants.DATA, null);
//			}
		}else{
			document = DomOperation.getDocument();
			Service = document.addElement(MsgConstants.Service);
		}
			Route =(null == Route)? DomOperation.addChildValueByName(Service, MsgConstants.ROUTE,
					null):Route;
			servResponse =(null == servResponse)? DomOperation.addChildValueByName(Route,
					MsgConstants.SERVICE_RESPONSE, null):servResponse;

			Data =(null == Data)? DomOperation.addChildValueByName(Service, MsgConstants.DATA, null):Data;
			control =(null == control)? DomOperation.addChildValueByName(Data,
					MsgConstants.DATA_CONTROL, null):control;
			request =(null == request)? DomOperation.addChildValueByName(Data,
					MsgConstants.DATA_REQUEST, null):request;
			response =(null == response)? DomOperation.addChildValueByName(Data,
					MsgConstants.DATA_RESPONSE, null):response;

	}

	/**
	 * 响应报文
	 */
	protected void paserSP() {
		Service = document.getRootElement();
		if(null != Service){
			Route = DomOperation.getElementByXpath(document, routePath);
			Data = DomOperation.getElementByXpath(document, dataPath);
			if (null != Route) {
				processes = DomOperation.getElementByXpath(document,
						processesPath);
				servResponse = DomOperation.getElementByXpath(document,
						servResponsePath);
			}
			if(null != Data){
				control = DomOperation.getElementByXpath(document, controlPath);
				request = DomOperation.getElementByXpath(document, requestPath);
				response = DomOperation.getElementByXpath(document, responsePath);
				if(response != null && response.attributeCount() > 0){
					Data.remove(response);
					response = null;
				}
			}
		}else{
			document = DomOperation.getDocument();
			Service = document.addElement(MsgConstants.Service);
		}
		Route =(null == Route)? DomOperation.addChildValueByName(Service, MsgConstants.ROUTE,
				null):Route;

		Data =(null == Data)? DomOperation.addChildValueByName(Service, MsgConstants.DATA, null):Data;
		control =(null == control)? DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_CONTROL, null):control;
		request =(null == request)? DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_REQUEST, null):request;
		response =(null == response)? DomOperation.addChildValueByName(Data,
				MsgConstants.DATA_RESPONSE, null):response;
		
		if(null == processes){
			curProcessKey = "1";
			processes = DomOperation.addChildValueByName(Route,
					MsgConstants.PROCESSES, null);
			DomOperation.addAttribute(processes, MsgConstants.MSG_SERV_CURRENT,
					curProcessKey);
			DomOperation.addAttribute(processes, MsgConstants.MSG_SERV_TOTAL,
					curProcessKey);
			curProcess = DomOperation.addChildValueByName(processes,
					MsgConstants.PROCESS, null);
			DomOperation.addAttribute(curProcess, MsgConstants.MSG_SERV_PROCESS_ID,
					curProcessKey);
		}else{
			curProcessKey = DomOperation.getAttriByName(processes, MsgConstants.MSG_SERV_CURRENT);
			if (curProcessKey == null  || "".equalsIgnoreCase(curProcessKey.trim())) 
				curProcessKey = "1";
			
			 for ( Iterator i = processes.elementIterator(); i.hasNext(); ) {
				 Element element = (Element) i.next();
				 if(curProcessKey.equals(DomOperation.getAttriByName(element, MsgConstants.MSG_SERV_PROCESS_ID))){
					 curProcess = element;
					 break;
				 }
			 }
			 if (curProcess == null) {
				curProcess = DomOperation.addChildValueByName(processes,MsgConstants.PROCESS, null);
				DomOperation.addAttribute(curProcess, MsgConstants.MSG_SERV_PROCESS_ID,	curProcessKey);
			 }
		}
		// get current response
		String totalSteps = DomOperation.getAttriByName(processes, MsgConstants.MSG_SERV_TOTAL);
		if (totalSteps != null && !"1".equals(totalSteps)) {
			for ( Iterator i = Data.elementIterator(); i.hasNext(); ) {
				Element element = (Element) i.next();
				if (curProcessKey.equals(DomOperation.getAttriByName(element, MsgConstants.PROCESS))){
					curResponse = element;
					break;
				}
			}
			if (curResponse == null) {
				curResponse = DomOperation.addChildValueByName(Data,MsgConstants.DATA_RESPONSE, null);
				DomOperation.addAttribute(curResponse, MsgConstants.PROCESS, curProcessKey);
			}
		}else{
			if (response != null)
				curResponse = response;
			else 
				curResponse = DomOperation.addChildValueByName(Data,MsgConstants.DATA_RESPONSE, null);
		}
	}

	/**
	 * 根据xml文件路径，解析并生成mo。
	 * 
	 * @param fileurl
	 *            xml文件路径
	 * @param endType
	 *            mo类型，取值为{@link #initSR}或{@link #initSP}。
	 * @throws Exception
	 */
	public MsgObjectComm(String fileurl, MOType endType) throws Exception {
		document = DomOperation.getDocument(fileurl);
		switch (endType) {
		case initSR:
			paserSR();
			break;
		case initSP:
			paserSP();
			break;
		default:
			throw new EisException(MsgConstants.MSG_STRUCTURE_ERRCODE,
			"- initPara参数非法");
		}
	}
	
	/**
	 * 获取service_response中的节点值，优先获取当前步骤。
	 * <p>
	 * 
	 * get key-value from service response node
	 * 
	 * @param key
	 *            节点名.支持Xpath路径,如 a/b/c,返回当前节点下的a节点下的b节点的c节点的值
	 *            
	 *            路径必须从当前节点的子节点开始.
	 * @return 节点值
	 */
	public String getServiceResponse(String key) {
		if (curProcessKey == null)
			return DomOperation.getChildValueByName(servResponse, child+key);
		else{
			return DomOperation.getChildValueByName(curProcess, child+key);
		}
	}
	
	/**
	 * 获取ServiceResponse中的节点值。
	 * <p>
	 * 
	 * @param key
	 *            节点名.支持Xpath路径,如 a/b/c,返回当前节点下的a节点下的b节点的c节点的值
	 *            
	 *            路径必须从当前节点的子节点开始.
	 * @return 节点值
	 */
	public String getFinalServiceResponse(String key) {
		return DomOperation.getChildValueByName(servResponse, child+key);
	}
	
	/**
	 * 设置ServiceResponse中的节点值。
	 * <p>
	 * 
	 * @param key
	 *            节点名.支持Xpath路径,如 a/b/c,返回当前节点下的a节点下的b节点的c节点的值
	 *            
	 *            路径必须从当前节点的子节点开始.
	 * @param value
	 *            节点值
	 */
	public void setServiceResponse(String key, String value) {
		if (curProcessKey == null)
			DomOperation.setChildValueByName(servResponse, key,value);
		else
			DomOperation.setChildValueByName(curProcess, key,value);
	}
	
	/**
	 * 设置Route中的节点值。
	 * <p>
	 * 
	 * @param key
	 *            节点名.支持Xpath路径,如 a/b/c,返回当前节点下的a节点下的b节点的c节点的值
	 *            
	 *            路径必须从当前节点的子节点开始.
	 * @param value
	 *            节点值
	 */
	public void setHeaderAttribute(String key, String value) {
		DomOperation.setChildValueByName( Route, key, value);
	}
	
	/**
	 * 设置Control中的节点值
	 * @param key 
	 * @param value
	 * @param process
	 * @return
	 */
	protected Element setControl(String key, String value, String process) {
		if (key == null || value == null)
			return null;
		Properties attrs = new Properties();
		if (process != null && !"".equals(process.trim()))
			attrs.put(MsgConstants.PROCESS, process);
		return DomOperation.setChildValueByName(control, key,
				value, attrs);
	}
	
	/**
	 * 设置Control中的节点值。
	 * <p>
	 * 
	 * @param key
	 *            节点名..支持Xpath路径,如 a/b/c,返回当前节点下的a节点下的b节点的c节点的值
	 *            
	 *            路径必须从当前节点的子节点开始.
	 * @param value
	 *            节点值
	 */
	public void setReqControl(String key, String value) {
		setControl(key, value, "");
	}
	
	/**
	 * 设置Control中的二级子节点值。
	 * <p>
	 * 
	 * @param key
	 *            一级子节点名
	 * @param childKey
	 *            二级子节点名
	 * @param value
	 *            二级子节点值
	 */
	public void setReqControl(String key, String childKey, String value) {
		Element node = setControl(key, value, "");
		if (node != null)
			DomOperation.setChildValueByName(node, childKey,value);
	}
	
	/**
	 * 设置当前步骤Control中的节点值。
	 * 
	 * @param key
	 *            节点名
	 * @param value
	 *            节点值
	 */
	public void setCurrentControl(String key, String value) {
		setControl(key, value, curProcessKey);
	}
	
	/**
	 * 用于缓存翻页操作时的控制数据清空 清空当前ext_attribute节点数据中的currentprocess数据
	 * 
	 */
	public void clearCurrentControl() {
		if(curProcessKey != null){
			List list = DomOperation.getByXPath(control, "child::*[@"+MsgConstants.PROCESS+"='"+curProcessKey+"']");
			for(Object o : list){
				control.remove((Element)o);
			}
		}else{
			List list = DomOperation.getByXPath(control, "child::*");
			for(Object o : list){
				control.remove((Element)o);
			}
		}
	}
	
	
	
	/**
	 * 设置request中的节点值。
	 * 
	 * @param key
	 *            节点名
	 * @param value
	 *            节点值
	 */
	public void setRequestParameter(String key, String value) {
		DomOperation.setChildValueByName( request, key, value);
	}
	
	/**
	 * 设置request中的节点值。
	 * 
	 * @param key
	 *            节点名
	 * @param value
	 *            节点值
	 * @param attrs
	 *            节点属性
	 */
	public void setRequestParameter(String key, String value, Properties attrs) {
		DomOperation.setChildValueByName( request, key, value,
				attrs);
	}
	
	/**
	 * 设置response中的节点值。
	 * <p>
	 * 设置curResponse的值，后端适配器使用此函数将返回值写入到 <response process="n"> 标签内
	 * 
	 * @param key
	 *            节点名
	 * @param value
	 *            节点值
	 */
	public void setResponseParameter(String key, String value) {
		if (curProcessKey == null)
			DomOperation.setChildValueByName( response,key, value );
		else
			DomOperation.setChildValueByName( curResponse, key, value);
	}
	
	/**
	 * 设置response中的节点值。
	 * <p>
	 * 设置curResponse的值，后端适配器使用此函数将返回值写入到 <response process="n"> 标签内
	 * 
	 * @param key
	 *            节点名
	 * @param value
	 *            节点值
	 * @param attrs
	 *            节点属性
	 */
	public void setResponseParameter(String key, String value, Properties attrs) {
		if (curProcessKey == null)
			DomOperation.setChildValueByName( response,key,value, attrs);
		else
			DomOperation.setChildValueByName( curResponse,key, value, attrs);
	}
	
	/**
	 * 设置交易代码
	 * 
	 * @param id
	 *            交易代码
	 */
	public void setServiceID(String id) {
		DomOperation.setChildValueByName( Route, MsgConstants.SERVICE_ID,id);
	}
	
	/**
	 * 获取交易代码
	 * 
	 * @return 交易代码
	 */
	public String getServiceID() {
		return DomOperation.getChildValueByName(Route,child+MsgConstants.SERVICE_ID);
	}
	
	/**
	 * 设置报文版本
	 * @param versionID
	 */
	public void setVersionID(String versionID){
		DomOperation.setChildValueByName( Route, MsgConstants.VERSION_ID,versionID);
	}
	
	/**
	 * 读取版本
	 * @return
	 */
	public String getVersionID(){
		return DomOperation.getChildValueByName(Route,child+MsgConstants.VERSION_ID);
	}
	
	
	/**
	 * 获取Route中的节点值。
	 * <p>
	 * 
	 * 
	 * @param key
	 *            节点名
	 * @return 节点值
	 */
	public String getHeaderAttribute(String key) {
		return DomOperation.getChildValueByName(Route, child+key);
	}
	
	
	/**
	 * 取得Control中指定的节点值
	 * @param key
	 * @param process
	 * @return
	 */
	protected String getControl(String key, String process) {
		String temp = null;
		if (null == control || null == key)
			return null;

		if (process != null && !"".equals(process)) {
			Element e = DomOperation.getElementByXpath(control, child+key+"[@"+MsgConstants.PROCESS+"='"+process+"']");
			if(null != e && e.hasContent())
				return e.getText();
			}
		List list = DomOperation.getByXPath(control, child+key);
		for(Object o : list){
			Element e = (Element) o;
			if(null == e.attribute(MsgConstants.PROCESS) || "".equals(e.attribute(MsgConstants.PROCESS).getValue())){
				temp = e.getText();
				return temp;
			}
		}
		return temp;
	}
	
	/**
	 * 获取请求报文头(Control)中的节点值。
	 * <p>
	 * 
	 * @param key
	 *            节点名
	 * @return 节点值
	 */
	public String getReqExtAttribute(String key) {
		return getControl(key, "");
	}
	
	/**
	 * 取得Control中指定的节点值
	 * @param key
	 * @return
	 */
	protected String overAllControl(String key) {
		String temp = null;
		if (null == control || null == key)
			return null;
		List list = DomOperation.getByXPath(control, child+key);
		for(Object o : list ){
			Element e = (Element) o;
			if(e.hasContent()){
				temp = e.getText();
				return temp;
			}
		}
		return temp;
	}
	
	/**
	 * 获取Control中的节点值，当前步骤的节点优先。
	 * 
	 * @param key
	 *            节点名
	 * @return 节点值
	 */
	public String getCurrentControl(String key) {
		String result = null;
		if (curProcessKey != null)
			result = getControl(key, curProcessKey);
		if (result == null)
			result = overAllControl(key);
		return result;
	}
	
	/**
	 * 获取Control中指定名称的GroupRecord列表。
	 * 
	 * @param key
	 *            GroupRecord节点名
	 * @return GroupRecord列表
	 */
	public List<GroupRecord> getControlGroupArray(String key) {
		return DomOperation.getGroupArray(control, key);
	}
	
	/**
	 * 获取request中的节点值，当前步骤的节点优先。
	 * 
	 * @param key
	 *            节点名
	 * @return 节点值
	 */
	public String getRequestParameter(String key) {
		return DomOperation.getChildValueByName(request, child+key);
	}
	
	/**
	 * 获取response中的节点值，当前步骤的节点优先。
	 * 
	 * @param key
	 *            节点名
	 * @return 节点值
	 */
	public String getResponseParameter(String key) {
		if (curProcessKey == null)
			return DomOperation.getChildValueByName(response, child+key);
		else
			return DomOperation.getChildValueByName(curResponse, child+key);
	}
	
	/**
	 * 由mo生成xml二进制流
	 * 
	 * @return xml二进制流
	 * @throws Exception
	 */
	public byte[] write2Bytes() throws Exception {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		 OutputFormat format = OutputFormat.createCompactFormat();
		 format.setEncoding("UTF-8");
		 //format.setSuppressDeclaration(true);
//         format.setIndent(true);      // 设置是否缩进 
//         format.setIndentSize(2);    // 以空格方式实现缩进 
//         format.setNewlines(true);    // 设置是否换行 
         XMLWriter writer = new XMLWriter(os,format);
         writer.write(document);
         byte[] outbytes = os.toByteArray();
		return outbytes;
	}
	
	public byte[] write2FormateBytes() throws Exception {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		 OutputFormat format = OutputFormat.createCompactFormat();
		 format.setEncoding("UTF-8");
//		 format.setSuppressDeclaration(true);
        format.setIndent(true);      // 设置是否缩进 
        format.setIndentSize(2);    // 以空格方式实现缩进 
        format.setNewlines(true);    // 设置是否换行 
        format.setTrimText(false);	//允许中间多个空格
        XMLWriter writer = new XMLWriter(os,format);
        writer.write(document);
        byte[] outbytes = os.toByteArray();
		return outbytes;
	}
	
	/**
	 * 获取当前步骤的处理信息（Route/processes/process）。
	 * 
	 * @param key
	 *            节点名
	 * @return 节点值
	 */
	public String getCurrentProcessProperty(String key) {
		return DomOperation.getChildValueByName(curProcess, child+key);
	}
	
	/**
	 * 设置当前步骤的处理信息（Route/processes/process）。
	 * 
	 * @param key
	 *            节点名
	 * @param value
	 *            节点值
	 */
	public void setCurrentProcessProperty(String key, String value) {
		DomOperation.setChildValueByName(curProcess,key,value);
	}
	
	
	/**
	 * 设置交易流水号。
	 * <p>
	 * 
	 * @param sn
	 *            交易流水号
	 */
	public void setSerialNO(String sn) {
		DomOperation.setChildValueByName(Route,MsgConstants.SERIAL_NO, sn);
	}
	
	/**
	 * 设置请求方系统ID。
	 * <p>
	 * 
	 * @param id
	 *            请求方系统id
	 */
	public void setSourceSysID(String id) {
		DomOperation.setChildValueByName(Route,MsgConstants.SOURCE_SYSTEM_ID, id);
	}
	
	/**
	 * 设置目标系统编号。
	 * <p>
	 * 
	 * @param targerid
	 */
	public void setTargetID(String targerid) {
		DomOperation.setChildValueByName( Route,MsgConstants.MSG_SERV_TARGET, targerid);
	}
	
	/**
	 * 设置交易日期。
	 * <p>
	 * 
	 * @param datetime
	 */
	public void setServiceDateTime(String datetime) {
		DomOperation.setChildValueByName( Route,MsgConstants.SERVICE_TIME, datetime);
	}
	
	/**
	 * 获取交易流水号。
	 * <p>
	 * 
	 * @return 交易流水号
	 */
	public String getSerialNO() {
		return DomOperation.getChildValueByName(Route,child+MsgConstants.SERIAL_NO);
	}
	
	/**
	 * 获取请求方系统ID。
	 * <p>
	 * 
	 * 
	 * @return 请求方系统ID
	 */
	public String getSourceSysID() {
		return DomOperation.getChildValueByName(Route,child+MsgConstants.SOURCE_SYSTEM_ID);
	}
	
	/**
	 * 获取目标系统编号。
	 * <p>
	 * 
	 * 
	 * @return targetid
	 */
	public String getTargetID() {
		return DomOperation.getChildValueByName(Route,child+MsgConstants.MSG_SERV_TARGET);
	}
	
	/**
	 * 获取交易日期。
	 * <p>
	 * 
	 * 
	 * @return 交易日期
	 */
	public String getServiceDateTime() {
		return DomOperation.getChildValueByName(Route,child+MsgConstants.SERVICE_TIME);
	}
	
	/**
	 * 设置Data下的节点值。
	 * <p>
	 * 
	 * 
	 * @param key
	 *            节点名
	 * @param value
	 *            节点值
	 */
	public void setBodyAttribute(String key, String value) {
		DomOperation.setChildValueByName(Data, key,value);
	}
	
	/**
	 * 获取Data下的节点值。
	 * <p>
	 * 
	 * @param key
	 *            节点名
	 * @return 节点值
	 */
	public String getBodyAttribute(String key) {
		return DomOperation.getChildValueByName(Data, child+key);
	}
	
	/**
	 * 获取request中所有节点及其属性的key-value表。
	 * <p>
	 * 
	 * 对于节点属性，key = 节点名 + “#” + 属性名。
	 * 
	 * 
	 * @return request对应表
	 */
	public HashMap<String, String> getRequestHashMap() {
		if (null == request)
			return null;
		return getNodeToHashMap(request);
	}

	/**
	 * 获取response中所有节点及其属性的key-value表。
	 * <p>
	 * 
	 * 对于节点属性，key = 节点名 + “#” + 属性名。
	 * 
	 * 
	 * @return response对应表
	 * 
	 */
	public HashMap<String, String> getResponseHashMap() {
		HashMap<String, String> hashmapR = null;
		HashMap<String, String> hashmapCR = null;
		if (null != response)
			hashmapR = getNodeToHashMap(response);
		if (null != curResponse)
			hashmapCR = getNodeToHashMap(curResponse);
		return MsgObjectUtil.mergeHashMap(hashmapR, hashmapCR);
	}
	
	/**
	 * 获取Control中所有节点及其属性的key-value表。
	 * <p>
	 * 对于节点属性，key = 节点名 + “#” + 属性名。
	 * 
	 * 
	 * @return 生成的对应表
	 * @see #getExtAttributeHashMap1()
	 */
	public HashMap<String, String> getControlHashMap() {
		if (null == control)
			return null;
		return getNodeToHashMap(control);
	}
	
	/**
	 * 根据节点名，从response中删除指定节点。
	 * <p>
	 * 
	 * 
	 * @param key
	 *            所要删除的节点名称
	 */
	public void delResponseChildNode(String key) {
		if(curResponse != null){
			List<Element> list = DomOperation.getByXPath(curResponse, child + key);
			for(Element e : list){
				curResponse.remove(e);
			}
		}else{
			List<Element> list = DomOperation.getByXPath(response, child + key);
			for(Element e : list){
				curResponse.remove(e);
			}
		}
	}
	
	/**
	 * 获取request中指定名称的GroupRecord列表。
	 * 
	 * @param key
	 *            GroupRecord节点名
	 * @return GroupRecord列表
	 */
	public List<GroupRecord> getRequestGroupArray(String key) {
		return DomOperation.getGroupArray(request, key);
	}
	
	/**
	 * 获取response中指定名称的GroupRecord列表。
	 * <p>
	 * 
	 * 
	 * @param key
	 *            GroupRecord节点名
	 * @return GroupRecord列表
	 */
	public List<GroupRecord> getResponseGroupArray(String key) {
		List<GroupRecord> al = null;
		if (curResponse != null)
			al = DomOperation.getGroupArray(curResponse, key);
		if (al != null && al.size() > 0)
			return al;
		else
			return DomOperation.getGroupArray(response, key);
	}
	
		
	/**
	 * 设置request中指定名称的GroupRecord列表。
	 * <p>
	 * 列表中的GroupRecord依次作为request的子节点加入，并拥有相同的节点名。 to support multi-level group
	 * 
	 * @param key
	 *            GroupRecord节点名
	 * @param values
	 *            GroupRecord列表
	 */
	public void setRequestGroupArray(List<GroupRecord> values) {
		DomOperation.setGroupArray( request, values, null);// 请求节点不需要设置process值
	}
	
	/**
	 * 设置response中指定名称的GroupRecord列表。
	 * <p>
	 * 列表中的GroupRecord依次作为response的子节点加入，并拥有相同的节点名。
	 * 
	 * @param key
	 *            GroupRecord节点名
	 * @param values
	 *            GroupRecord列表
	 */
	public void setResponseGroupArray(List<GroupRecord> values) {
		if (curResponse != null)
			DomOperation.setGroupArray(curResponse, values,null);// 响应节点不需要设置process值
		else
			DomOperation.setGroupArray(response,  values,null);// 响应节点不需要设置process值
	}
	
	/**
	 * 设置Control中指定名称的GroupRecord列表。 列表中的GroupRecord依次作为Control的子节点加入，并拥有相同的节点名。
	 * 
	 * @param key
	 *            GroupRecord节点名
	 * @param values
	 *            GroupRecord列表
	 */
	public void setControlGroupArray(List<GroupRecord> values) {
		DomOperation.setGroupArray( control,  values, curProcessKey);// 请求节点不需要设置process值
	}
	
	/**
	 * 替换Control中指定名称的GroupRecord列表。
	 * 
	 * @param key
	 * @param values
	 */
	public void updateControlGroupArray(String key,List<GroupRecord> values) {
		DomOperation.removeGroupArray(control, key);
		DomOperation.setGroupArray(control,  values, curProcessKey);
	}
	
	/**
	 * 替换request中指定名称的GroupRecord列表。
	 * <p>
	 * 
	 * @param key
	 * @param values
	 */
	public void updateRequestGroupArray(String key,List<GroupRecord> values) {
		DomOperation.removeGroupArray(request, key);
		DomOperation.setGroupArray(request, values, null);
	}
	
	/**
	 * 将mo转换为xml
	 */
	public String toString() {
		try {
			byte[] bs = this.write2FormateBytes();
			String s = new String(bs, "UTF-8");
			return s;
		} catch (Exception e) {
		}
		return super.toString();
	}
	
	/**
	 * 将源mo中的请求信息copy至本mo。
	 * <p>
	 * 
	 * 所copy的节点包括：<br>
	 * <ol>
	 * <li>Route</li>
	 * <li>Data/Control</li>
	 * <li>Data/request</li>
	 * </ol>
	 * 
	 * @param mo
	 *            源mo
	 */
	public void createNewStdReqMO(MsgObjectComm mo) {
		DomOperation.copySimpleNode(document, getRoute(), mo.getRoute());
		// DomNodeOperation.copySimpleNode(document, getHeaderNode(),
		// mo.getCurrentProcessNode());
		DomOperation.copyNode(document, getControl(), mo.getControl());
		DomOperation.copyNode(document, getRequest(), mo.getRequest());
	}
	
	/**
	 * 将源mo中的响应信息copy至本mo。
	 * <p>
	 * 
	 * 所copy的节点包括：<br>
	 * <ol>
	 * <li>Route/ServiceResponse</li>
	 * <li>Data/Control</li>
	 * <li>Data/response</li>
	 * </ol>
	 * 
	 * @param mo
	 *            源mo
	 */
	public void copyFromStdRespMO(MsgObjectComm mo) {
		DomOperation.copyNode(document, getControl(), mo.getControl());
		DomOperation.copyNode(document, getCurProcess(), mo.getResponse());
		setServiceResponse(MsgConstants.STATUS, mo.getServiceResponse(MsgConstants.STATUS));
		setServiceResponse(MsgConstants.CODE, mo.getServiceResponse(MsgConstants.CODE));
		setServiceResponse(MsgConstants.DESC, mo.getServiceResponse(MsgConstants.DESC));
		setServiceResponse(MsgConstants.SOURCE_SYSTEM_CODE, mo.getServiceResponse(MsgConstants.SOURCE_SYSTEM_CODE));
		setServiceResponse(MsgConstants.SOURCE_SYSTEM_DESC, mo.getServiceResponse(MsgConstants.SOURCE_SYSTEM_DESC));
	}
	
	/**
	 * 复制response节点
	 * @param mo
	 */
	public void copyRespMo(MsgObjectComm mo){
		DomOperation.copyNode(document,getResponse(),mo.getResponse());
	}
	
	/**
	 * 删除Header中的结点
	 * 
	 * @param AtttributeName
	 */
	public void removeHeaderNode(String nodeName) {

		Element node = (Element) DomOperation.getChildByName(Route,nodeName);
		if (node != null) {
			Route.remove(node);
		}
	}
	/**
	 * 从request元素中拷贝信息到response
	 */
	public void retrieveRespNodeFromReqNode() {
		if(response != null){
		List<Element> list =DomOperation.getByXPath(response, child+"*");
		for(Element e : list){
			response.remove(e);
			Element e1 = DomOperation.getChildByName(request, e.getName());
			if(e1 == null)
				request.appendContent(e);
			else{
				request.remove(e1);
				request.add(e);
			}				
		}
		}
		if(null != curProcess){
			List<Element> list = DomOperation.getByXPath(curProcess, child+"*");
			for(Element e : list){
				curProcess.remove(e);
				Element e1 = DomOperation.getChildByName(request, e.getName());
				if(e1 == null)
					request.appendContent(e);
				else{
					request.remove(e1);
					request.add(e);
				}	
			}
		}
	}
	
	/**
	 * 获取Route中指定节点的属性值。
	 * <p>
	 * 
	 * 
	 * @param key
	 *            节点名
	 * @param attributeName
	 *            属性名
	 * @return 属性值
	 */
	public String getHeaderAttribute(String key, String attributeName) {
		Element node = DomOperation.getChildByName(Route, key);
		return DomOperation.getAttriByName(node, attributeName);
	}
	
	/**
	 * 设置request中指定名称的节点列表。
	 * <p>
	 * 列表中的节点值依次作为request的子节点值加入，并拥有相同的节点名。
	 * 
	 * @param key
	 *            节点名
	 * @param values
	 *            节点值列表
	 */
	public void setRequestArrayParameters(String key, ArrayList<String> values)
			throws Exception {
		for (int i = 0; i < values.size(); i++) {
			Element me = DocumentHelper.createElement(key);
			Text text = DocumentHelper.createText(values.get(i));
			me.add(text);
			request.appendContent(me);
		}
	}
	
	/**
	 * 替换response中指定名称的GroupRecord列表。
	 * <p>
	 * 
	 * @param key
	 * @param values
	 */
	public void updateResponseGroupArray(String key,List<GroupRecord> values) {
		DomOperation.removeGroupArray(curResponse, key);
		DomOperation.setGroupArray( curResponse, values,null);// 响应节点不需要设置process值
	}
	
	/**
	 * 
	 * @param element
	 * @return
	 */
	protected HashMap<String, String> getNodeToHashMap(Element element) {
		if (null == element)
			return null;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		// 判断该节点是否有子节点
		List<Element> list = DomOperation.getByXPath(element, child+"*");
		for(Element e : list){
			// 获取当前节点的名字
			String name = e.getName();
			// 获取当前节点的所有属性
			List<Attribute> alist = DomOperation.getByXPath(e, "attribute::*");
			for(Attribute a : alist){
				hashmap.put(name +"#"+a.getName(), a.getValue());
			}
			// 获取当前节点的内容
			String sNodeValue = e.getText();
			hashmap.put(name, sNodeValue);
			}
		return hashmap;
	}
	
	
	/**
	 * 将源mo中的Control复制至本mo。
	 * <p>
	 * 
	 * @param mo
	 *            源mo
	 */
	public void setControl(MsgObjectComm mo) {
		Element temp = mo.getControl();
		if (temp == null)
			return;
		Element nd = DomOperation.getChildByName(Data,
				MsgConstants.DATA_CONTROL);
		HashMap<String, String> hs = getNodeToHashMap(temp);
		getHashMapToNode(hs, nd);
	}
	
	protected void getHashMapToNode(HashMap<String, String> hm, Element element) {
		Iterator<Map.Entry<String, String>> it = hm.entrySet().iterator();
		String key, value;
		while (it.hasNext()) {
			Map.Entry<String, String> map = it.next();
			key = map.getKey();
			if (key.indexOf("#") < 0) {
				value = map.getValue();
				Element e = DocumentHelper.createElement(key);
				Text text = DocumentHelper.createText(value);
				e.add(text);
				element.add(e);
			}
			it.remove();
		}
	}
	
	
	/**
	 * 获取Control中所有节点的key-value表（不含属性）。
	 * <p>
	 * 
	 * 
	 * @return 生成的对应表
	 * @see #getExtAttributeHashMap()
	 */
	public HashMap<String, String> getControlHashMap1() {
		if (null == control)
			return null;
		return getNodeToHashMap1(control);
	}
	/**
	 * 获取request中所有节点的key-value表（不含属性）。
	 * <p>
	 * 
	 * @return 对应表
	 */
	public HashMap<String, String> getRequestHashMap1() {
		if (null == request)
			return null;
		return getNodeToHashMap1(request);
	}

	/**
	 * 获取response中所有节点的key-value表（不含属性）。
	 * <p>
	 * 
	 * @return 对应表
	 */
	public HashMap<String, String> getResponseHashMap1() {
		HashMap<String, String> hashmapR = null;
		HashMap<String, String> hashmapCR = null;
		if (null != response)
			hashmapR = getNodeToHashMap1(response);
		if (null != curResponse)
			hashmapCR = getNodeToHashMap1(curResponse);
		return MsgObjectUtil.mergeHashMap(hashmapR, hashmapCR);
	}

	/**
	 * 获取Route中所有节点的key-value表（不含属性）。
	 * <p>
	 * 
	 * @return 对应表
	 */
	public HashMap<String, String> getServiceHeaderHashMap1() {
		if (null == Route)
			return null;
		return getNodeToHashMap1(Route);
	}
	
	/**
	 * @param node
	 * @return
	 */
	protected HashMap<String, String> getNodeToHashMap1(Element node) {
		if (null == node)
			return null;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		// 判断该节点是否有子节点
		List<Element> list = node.elements();
		
		for(Element e :list){
			String sNodeName = e.getName();
			String sNodeValue = e.getText();
			hashmap.put(sNodeName, sNodeValue);
		}
		return hashmap;
	}
	
	/**
	 * 根据节点名和节点属性，获取response中的节点值，当前步骤的节点优先。
	 * <p>
	 * 
	 * 
	 * @param key
	 *            节点名
	 * @param attrs
	 *            属性
	 * @return 节点值
	 */
	public String getResponseParameterByAttrs(String key, Properties attrs) {
		Element node;
		if (curProcessKey == null)
			node = DomOperation.getChildByNameAndAttr(response, key, attrs);
		else
			node = DomOperation.getChildByNameAndAttr(curResponse, key,	attrs);
		if (null == node)
			return null;
		return DomOperation.getValue(node);
	}
	
	/**
	 * 根据节点名和节点属性，从response中删除指定节点。
	 * <p>
	 * 
	 * 
	 * @param key
	 *            所要删除的节点名称
	 * @param attrs
	 *            所要删除的节点属性
	 */
	public void delResponseChildNodeByAttrs(String key, Properties attrs) {
		Element nd = null;
		if (curResponse != null) {
			nd = DomOperation.getChildByNameAndAttr(curResponse, key, attrs);
			curResponse.remove(nd);
		} else {
			nd = DomOperation.getChildByNameAndAttr(response, key, attrs);
			response.remove(nd);
		}
	}
	
	
	/**
	 * 将response节点的内容移动到request节点下。
	 * <p>
	 * 
	 * ECIF TIMEER使用
	 * 
	 */
	public void moveResponseToRequest() {
		
		List<Element> list = DomOperation.getByXPath(response, child+"*");
		
		for(Element e : list){
			request.appendContent(e);
		}
		Data.remove(response);
		response = null;
	}
	
	/**
	 * 
	 * @param AtttributeName
	 */
	public void removeRouteAttribute(String AtttributeName) {
		if(Route==null){
			Route =DomOperation.getChildByName(Service,
					MsgConstants.ROUTE);
		}
		if(AtttributeName!= null && Route != null){
			Route.addAttribute(AtttributeName, null);
		}
	}
	
	/**
	 * 
	 * @param nodeName
	 *            节点名
	 */
	public void removeControl(String nodeName) {
		Element node = DomOperation.getChildByName(control,nodeName);
		if (node != null) {
			control.remove(node);
		}
	}
	
	/**
	 * @param nodeName
	 */
	public void removeRequestSingleNode(String nodeName) {
		Element node = DomOperation.getChildByName(this.request,nodeName);
		if (node != null)
			this.request.remove(node);
	}
	
	/**
	 * 删除response中的属性
	 * 
	 * @param AtttributeName
	 */
	public void removeResponseAttribute(String AtttributeName) {
		Element temp = null;
		if (curProcessKey == null)
			temp =  response;
		else
			temp = curResponse;
		if (temp != null && AtttributeName != null)
			temp.addAttribute(AtttributeName, null);
			
	}
	
	/**
	 * 删除response中的属性
	 * 
	 * @param AtttributeName
	 */
	public void removeResponseParameterAttribute(String key,
			String AtttributeName) {
		Element temp = null;
		if (curProcessKey == null)
			temp = DomOperation.getChildByName(response, key);
		else
			temp = DomOperation.getChildByName(curResponse, key);
		if (temp != null)
			temp.addAttribute(AtttributeName, null);
	}
	
	/**
	 * 删除response中的属性
	 * 
	 * @param AtttributeName
	 */
	public void removeResponseParameter(String key) {
		Element temp = null;
		if (curProcessKey == null) {
			temp = DomOperation.getChildByName(response, key);
			if (temp != null)
				response.remove(temp);
		} else {
			temp = DomOperation.getChildByName(curResponse, key);
			if (temp != null)
				curResponse.remove(temp);
		}
	}

	protected MsgObjectComm() {
	}
	
	/**
	 * 根据当前mo，克隆出新的mo。
	 * 
	 * @param endType
	 *            mo类型，取值为{@link #initSR}或{@link #initSP}。
	 * @return 新mo
	 * @throws Exception
	 */
	public MsgObjectComm clone(MOType endType) throws Exception {
		MsgObjectComm copy = new MsgObjectComm();
		copy.document = (Document) this.document.clone();
		switch (endType) {
		case initSP:
			copy.paserSP();
			break;
		case initSR:
			copy.paserSR();
			break;
		default:
			throw new EisException(MsgConstants.MSG_STRUCTURE_ERRCODE,"- initPara参数非法");
		}
		return copy;
	}
	
	/**
	 * 删除Response中符合条件的GroupRecord。
	 * <p>
	 * 
	 * @param groupName
	 *            GroupRecord节点名
	 * @param attrs
	 *            GroupRecord属性
	 * @throws EsbException
	 */
	public void removeResponseGroupRecord(String groupName, Properties attrs)
			throws EisException {
		if (attrs == null || attrs.size() <= 0)
			return;
		DomOperation.removeGroupArray(response, groupName, attrs);
	}
	
	/**
	 * 删除ext_attributes中符合条件的GroupRecord。
	 * <p>
	 * 
	 * @param groupName
	 *            GroupRecord节点名
	 * @throws EsbException
	 */
	public void removeControlGroupRecord(String groupName) throws EisException {
		DomOperation.removeGroupArray(control, groupName);
	}
	
	/**
	 * 删除response 节点中符合条件的GroupRecord
	 * 
	 * 
	 * @param groupName
	 *            GroupRecord节点名
	 * @throws EsbException
	 */
	public void removeResponseGroupRecord(String groupName) throws EisException {
		if (curResponse != null)
			DomOperation.removeGroupArray(curResponse, groupName);
		else
			DomOperation.removeGroupArray(response, groupName);
	}
	
	/**
	 * 删除request节点中符合条件的GroupRecord
	 * 
	 * 
	 * @param groupName
	 *            GroupRecord节点名
	 * @throws EsbException
	 */
	public void removeRequestGroupRecord(String groupName) throws EisException {
		DomOperation.removeGroupArray(request, groupName);
	}
	
	/**
	 * 返回request节点中符合条件的GroupRecord
	 * 
	 * @param groupName
	 * @return ArrayList 返回request节点下的所有组
	 * @throws EsbException
	 */
	public List<GroupRecord> getRequestGroupRecord(String groupName) {
		return DomOperation.getGroupArray(request, groupName);
	}
	
	/**
	 * 
	 * 将response(非currentResponse)
	 * 
	 * @return
	 */
	public List<GroupRecord> getResponseAsGroupRecord() {
		return DomOperation.getGroupArray(Data, MsgConstants.DATA_RESPONSE);
	}

	public List<GroupRecord> getRequestAsGroupRecord() {
		return DomOperation.getGroupArray(Data, MsgConstants.DATA_REQUEST);
	}

	public void removeResponseNode() {
		if (curProcessKey == null) {
			if ((response != null) && (Data != null)) {
				Data.remove(response);
			}
		} else {
			if ((curProcess != null) && (Data != null)) {
				Data.remove(curProcess);
			}
		}
	}
	
	public void removeRequestNode(){
		if (this.request != null)
			Data.remove(request);
	}
	
	/**
	 * 删除response中满足传入参数的空值结点
	 * 
	 * @param key
	 *            节点名
	 */
	public void removeNullResponseParameter(String key) {
		ArrayList<Element> list = null;
		if (curProcessKey == null) {
			list = DomOperation.getChildListByName(response, key);
			if (list == null)
				return;
			for (int i = 0; i < list.size(); i++) {
				Element node = list.get(i);
				if (DomOperation.getValue(node) == null)
					response.remove(node);
			}
		} else {
			list = DomOperation.getChildListByName(curResponse, key);
			if (list == null)
				return;
			for (int i = 0; i < list.size(); i++) {
				Element node = list.get(i);
				if (DomOperation.getValue(node) == null)
					curResponse.remove(node);
			}
		}
	}
	
	/**
	 * Filter 遍历Response，进行金额字段的映射
	 */
//	public void filterCBODAmount(Node fbeginNode, ArrayList<String> list) {
//	}
	
	public void copyReqFromMultiReq(MsgObjectComm mo) {
		Element multi_request = DomOperation.getChildByName(Data,
				MsgConstants.MSG_MULTI_REQUEST);
		DomOperation.copyNode(document, request, multi_request);
	}
	
	// 修改不按名字复制子节点（增加node下重名节点）
	public void copyFromStdRespMONotOverride(MsgObjectComm mo) {
		DomOperation.copyNode(document, getControl(), mo
				.getControl());
		DomOperation.copyNodeNotOverride(document, getResponse(), mo
				.getResponse());
		setServiceResponse(MsgConstants.STATUS, mo
				.getServiceResponse(MsgConstants.STATUS));
		setServiceResponse(MsgConstants.CODE, mo
				.getServiceResponse(MsgConstants.CODE));
		setServiceResponse(MsgConstants.DESC, mo
				.getServiceResponse(MsgConstants.DESC));
		setServiceResponse(MsgConstants.SOURCE_SYSTEM_CODE, mo
				.getServiceResponse(MsgConstants.SOURCE_SYSTEM_CODE));
		setServiceResponse(MsgConstants.SOURCE_SYSTEM_DESC, mo
				.getServiceResponse(MsgConstants.SOURCE_SYSTEM_DESC));
	}
	
	
	/**
	 * 根据节点名和节点属性，获取request中的节点值，当前步骤的节点优先 将源mo中的请求信息copy至本mo
	 * 
	 * @param mo
	 *            源mo
	 * @param key
	 *            节点名
	 * @param attrs
	 *            属性
	 */

	public void createSReqMO(MsgObjectComm mo, String key, Properties attrs) {
		DomOperation
				.copyNode(document, getRoute(), mo.getRoute());
		DomOperation.copyNode(document, getControl(), mo
				.getControl());
		Element node = null;
		if (mo.getRequest() != null)
			node = DomOperation.getChildByNameAndAttr(mo.getRequest(),
					key, attrs);
		if (node != null)
			DomOperation.copyNode(document, getRequest(), node);
	}
	
	
	/**
	 * 将mo中的名为nodeName的节点都添加到response节点下
	 * 
	 * @param mo
	 * @param nodeName
	 * @return
	 */
	public boolean appendFromStdRespMO(MsgObjectComm mo, String nodeName) {
		List<Element> lst = DomOperation.getChildListByName(mo
				.getRequest(), nodeName);
		Iterator<Element> it = lst.iterator();
		while (it.hasNext()) {
			Element sonNode = it.next();
			if (!DomOperation.addChildNode(document,curResponse, sonNode)) {
				return false;
			}
		}
		return true;
	}
	
	
	public MsgObjectComm cloneMo() {
		MsgObjectComm clone = null;
		try {
			clone = (MsgObjectComm) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return clone;
	}

}
