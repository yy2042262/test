
package com.soa.eis.adapter.framework.connection.mqc;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.ibm.mq.MQC;
import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.soa.eis.adapter.framework.common.CacheManager;
import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.connection.IConnection;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.utils.PublicPrint;
import com.soa.eis.adapter.framework.utils.log.ILog;
import com.soa.eis.adapter.framework.utils.log.LogUtil;

/**
 * MQ implentation of service connection.
 */
public class MQConnection implements IConnection {

	private static ILog logUtil = LogUtil.getInstance();

	private MQCParameter cfgSendData = null;
	private MQCParameter cfgReceiveData = null;
	
	private int currentIndex = 0;
	private List<MQParameter> sendQList = new ArrayList<MQParameter>();
	private List<MQParameter> receiveQList = new ArrayList<MQParameter>();
	 
	private Properties config;
	protected String encoding;
	
	/**
	 * 将currentIndex值进行累加，如果超出范围则返回false否则返回true
	 * @return 
	 */
	private boolean doNextCurrIndex(){
		if ((currentIndex + 1) >= receiveQList.size()){
			currentIndex = 0; 
			return false;
		}else{
			currentIndex ++;
			return true;
		}
	}
	
	private boolean doNextCurrMQC(){
		boolean isT = doNextCurrIndex();
		setMQCpara();
		return isT;
	}
	
	/**
	 * 返回当前发送队列的配置
	 * @return
	 */
	private MQParameter getSendQueuePara(){
		return sendQList.get(currentIndex);
	}
	
	/**
	 * 返回当前接收队列配置
	 * @return
	 */
	private MQParameter getReceiveQueuePara(){
		return receiveQList.get(currentIndex);
	}
	
	/**
	 * MQ连接配置初始化
	 * @param sendQueue
	 *            MQ config for send queue
	 * @param receiveQueue
	 *            MQ config for receive queue
	 */
	public MQConnection(List<MQParameter> sendQList,List<MQParameter> receiveQList) throws EisException {
		if (logUtil.isDebugEnabled()) {
			StringBuffer sb = new StringBuffer();
			sb.append("Open MQConnection : ").append(this);
			logUtil.debug(sb.toString());
			sb = null;
		}
		this.sendQList = sendQList;
		this.receiveQList = receiveQList;
//		this.config = CacheManager.getInstance().getConfig();
//		this.encoding = config.getProperty(ConfigConstants.ENCODING);
		this.encoding = "UTF-8";
		
		MQConnectionShutDownHook.register(this);
	}
	
	private void setMQCpara(){
		if(cfgSendData != null){
			cfgSendData.release();
		}
		if(cfgReceiveData != null){
			cfgReceiveData.release();
		}
		cfgSendData = new MQCParameter(getSendQueuePara());
		cfgReceiveData = new MQCParameter(getReceiveQueuePara());
	}
	
	/**
	 * 进行MQ连接初始化
	 * @return TRUE:连接成功；FALSE:连接失败
	 */
	public boolean initMQConnection() {
		boolean ret = false;
		currentIndex = -1;
		while(doNextCurrMQC()){
			try {
				if (cfgSendData != null) {
					// 接收队列连接参数
					ret = MQQueueAccesser.connectMQ(cfgSendData,MQQueueAccesser.MQ_MSGSEND_TYPE);
				}

				if (cfgReceiveData != null) {
					// 发送队列连接参数
					ret = MQQueueAccesser.connectMQ(cfgReceiveData,MQQueueAccesser.MQ_MSGRECEIVE_TYPE);
				}
				
				return ret;
			} catch (Exception e) {
				logUtil.error("MQ Client 初始化 Exception:", e);
				if (cfgSendData != null){
					cfgSendData.release();
					cfgSendData = null;
				}
				
				if (cfgReceiveData != null){
					cfgReceiveData.release();
					cfgReceiveData = null;
				}
				
				ret = false;
			}
		}
		return ret;
	}
	
	public MQMsgRef receive(int timeout) throws EisException {
		return receive(timeout, null);
	}
	
	public MQMsgRef receive() throws EisException {
		return receive(0, null);
	}
	
	private MQMessage getMQMsg(MQMsgRef mqMsgRef,  int timeout) throws EisException{
		MQMessage receiveMsg = null;
		try{
			int i = 0;
			
			while(true){
				try{
					if (cfgReceiveData.qManager == null || cfgReceiveData.queue == null) {
						initMQConnection();
					}
					
					if (mqMsgRef == null || mqMsgRef.MQMsgId == null ||  mqMsgRef.MQMsgId.length <= 0)
						receiveMsg = MQQueueAccesser.getMsgFromQueue(null, cfgReceiveData, timeout);
					else
						receiveMsg = MQQueueAccesser.getMsgFromQueue(mqMsgRef.MQMsgId, cfgReceiveData, timeout);
					
					return receiveMsg;
				}catch(MQException mqe){
					i ++;
					int ret = MQQueueAccesser.handleMQException(mqe);
					if (ret == -1){
						boolean isT = initMQConnection();
						if (!isT)
							throw new EisException(MQCException.MQ_CONNECT_ERROR_EXCEPTION_CODE);
			
					}else if (ret == 1){
						throw mqe;
					}
					
					if (i > MQQueueAccesser.getConnGetMsgCount()){
						throw mqe;
					}
				}
			}
		}catch(MQException mqe){
			int ret = MQQueueAccesser.handleMQException(mqe);
			
			if (ret == 1) {
				throw new EisException(MQCException.MQ_MSG_RECEIVE_GETMSG_TIMEOUT_EXCEPTION_CODE,
										MQCException.MQ_MSG_RECEIVE_GETMSG_TIMEOUT_EXCEPTION_DESC);
			} else if (ret == -1) {
				throw new EisException(	MQCException.MQ_CONNECT_ERROR_EXCEPTION_CODE);
			} else{
				throw new EisException(	MQCException.MQ_MSG_RECEIVE_GETMSG_ERROR_EXCEPTION_CODE	+ mqe);
			}
		} catch (Exception e) {
			throw new EisException(MQCException.MQ_MSG_RECEIVE_GETMSG_ERROR_EXCEPTION_CODE,MQCException.MQ_MSG_RECEIVE_GETMSG_ERROR_EXCEPTION_DESC);
		}
		

	}
	
	public MQMsgRef receive(int timeout, MQMsgRef mqMsgRef) throws EisException {
		if (cfgReceiveData == null)
			throw new EisException("Fail to init receive queue.");

		MQMessage receiveMsg = getMQMsg(mqMsgRef,timeout);

		if (receiveMsg == null)
			throw new EisException("Fail to get mq msg.");
		
		byte[] response = MQQueueAccesser.getBytesFromMQMessage(receiveMsg);
		
//		logUtil.info("replyToQueueManagerName::" + receiveMsg.replyToQueueManagerName);
//		if (logUtil.isInfoEnabled()) {
//			StringBuffer sb;
//			try {
//				sb = new StringBuffer().append("receive message:\n").append(new String(response, encoding));
//				logUtil.info(sb.toString());
//			} catch (UnsupportedEncodingException e) {
//				logUtil.error("Exception:", e);
//			}	
//			sb = null;
//		}
		
		MQMsgRef mQMsgRef = new MQMsgRef(receiveMsg.messageId, response);
		return mQMsgRef;
	}
	

	public MQMsgRef send(MQMsgRef msg) throws EisException {
		if (cfgSendData == null)
			throw new EisException("Fail to init send queue.");
		
		if (msg == null || msg.MQMsgBody == null)
			throw new EisException("Error in MQConnection : send message is null.");

//		if (logUtil.isInfoEnabled()) {
//			StringBuffer sb;
//			try {
//				sb = new StringBuffer().append("send message:\n").append(new String(msg.MQMsgBody, encoding));
//				logUtil.info(sb.toString());
//			} catch (UnsupportedEncodingException e) {
//				logUtil.error("Exception:", e);
//			}
//			sb = null;
//		}
		
		MQMessage sendMsg = MQQueueAccesser.getMQMessageFromBytes(msg.MQMsgBody);
		
		//设置消息id
		if (msg != null && msg.MQMsgId != null && msg.MQMsgId.length > 0){
			sendMsg.messageId = msg.MQMsgId;
			sendMsg.correlationId = msg.MQMsgId;
		}
		
		//设置消息队列管理器
		if (msg != null && msg.ReplyToQMgr != null){
			sendMsg.replyToQueueManagerName = msg.ReplyToQMgr;
			sendMsg.messageType = MQC.MQMT_REPLY;
		}
		
//		sendMsg.encoding = cfgSendData.mqParameter.getCcsid();
		sendMsg.characterSet = cfgSendData.mqParameter.getCcsid();
//		sendMsg.format = MQC.MQFMT_STRING;
		
		boolean ret = putMQMsg(sendMsg);
		if (!ret)
			throw new EisException("Fail to put mq msg.");
		
		MQMsgRef mQMsgRef = new MQMsgRef();
		mQMsgRef.MQMsgId = sendMsg.messageId;
		
		return mQMsgRef;
	}
	
	private boolean putMQMsg(MQMessage sendMsg) throws EisException{
		try{
			int i = 0;
			
//			while(true){
//				try{
//					if (cfgSendData.qManager == null || cfgSendData.queue == null) {
//						initMQConnection();
//					}
//					return MQQueueAccesser.putMsgToQueue(cfgSendData, sendMsg);
//				}catch(MQException mqe){
//					i ++;
//					int retInt = MQQueueAccesser.handleMQException(mqe);
//					if (retInt == -1){
//						boolean isT = initMQConnection();
//						if (!isT)
//							throw new EisException(MQCException.MQ_CONNECT_ERROR_EXCEPTION_CODE);
//	
//					}
//					
//					if (i > MQQueueAccesser.getConnPutMsgCount()){
//						throw mqe;
//					}
//				}
//			}
			
			while(true){
				try{
					if (cfgSendData.qManager == null || cfgSendData.queue == null) {
						initMQConnection();
					}
					return MQQueueAccesser.putMsgToQueue(cfgSendData, sendMsg);
				}catch(MQException mqe){
					logUtil.error("putMQMsg error",mqe);
					int retInt = MQQueueAccesser.handleMQException(mqe);
					if (retInt == MQQueueAccesser.MQ_CONNECTION_BROKER || retInt == MQQueueAccesser.MQ_UNKNOW_EXCEPTION || retInt ==MQQueueAccesser.MQ_CONNECTION_BROKEN_2009){
						boolean isT = initMQConnection();
						if (!isT)
							throw new EisException(MQCException.MQ_CONNECT_ERROR_EXCEPTION_CODE);
					}else{
						throw mqe;
					}
					//对于2009类型的错误因为消息已经发出，所以如果接收到此错误则只是初始化连接，但不重发消息
					if(retInt ==MQQueueAccesser.MQ_CONNECTION_BROKEN_2009){
						throw mqe;
					}
					i ++;
					if (i > MQQueueAccesser.getConnPutMsgCount()){
						throw mqe;
					}
				}
				}
		}catch(MQException mqe){
			int retInt = MQQueueAccesser.handleMQException(mqe);
			
			if (retInt == 1) {
				throw new EisException(MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_CODE,MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_DESC);
			} else if (retInt == -1) {
				throw new EisException(MQCException.MQ_CONNECT_ERROR_EXCEPTION_CODE,MQCException.MQ_CONNECT_ERROR_EXCEPTION_DESC);
			} else if(retInt == -2){
				throw new EisException(MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_CODE,MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_DESC+mqe);
			}			
			else
			{
				throw new EisException(MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_CODE,
						MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_DESC
								+ mqe);
			}
		}catch (Exception e) {
			throw new EisException(MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_CODE,MQCException.MQ_MSG_SEND_PUTMSG_ERROR_EXCEPTION_DESC);
		}
	}
	
	/**
	 * 释放当前对象的MQ连接
	 */
	public void release() {		
		if (cfgSendData != null)
			cfgSendData.release();
		if (cfgReceiveData != null)
			cfgReceiveData.release();
		if (logUtil.isInfoEnabled()) {
			StringBuffer sb = new StringBuffer();
			sb.append("Close MQConnection : ").append(this);
			logUtil.info(sb.toString());
			sb = null;
		}
	}

	public void reset() {
		
	}
	
	/**
	 * 验证当前连接是否有效
	 * @return TRUE:正常连接；FALSE:连接失败
	 */
	public boolean valid() {
		try {
			//得到当前发送队列的深度
			cfgSendData.queue.getCurrentDepth();
			//得到当前接收队列的深度
			cfgReceiveData.queue.getCurrentDepth();
			return true;
		} catch (Exception e) {
			logUtil.error("Exception:", e);
			return false;
		}
	}

	public byte[] request(byte[] msg, int timeout) throws EisException {
		return receive(timeout, send(new MQMsgRef(null, msg))).MQMsgBody;
	}
	
	public byte[] request(byte[] msg) throws EisException {
		return receive(0, send(new MQMsgRef(null, msg))).MQMsgBody;
	}

	
	public byte[] receiveBySegment(int timeout, byte[] grpid)
			throws EisException {
		if (cfgReceiveData == null)
			throw new EisException("Fail to init receive queue.");
		if (grpid == null)
			throw new EisException("Error in MQConnection : group id is null.");

		byte[] msg = MQQueueAccesser.getMsgFromQueueBySegment(grpid, cfgReceiveData, MQQueueAccesser.MQ_MSGRECEIVE_TYPE, timeout);

		if (logUtil.isInfoEnabled()) {
			StringBuffer sb = new StringBuffer().append("message group id is :\n");	
			logUtil.info(sb.toString());
			sb = null;
			PublicPrint.printBuffer(grpid, grpid.length, PublicPrint.PrintType.DEBUG);				
			try {
				sb = new StringBuffer().append("receive message:\n").append(new String(msg, encoding));
				logUtil.info(sb.toString());
			} catch (UnsupportedEncodingException e) {
				logUtil.error("Exception:", e);
			}				
			sb = null;				
		}
		
		return msg;
	}
	
	public boolean receiveBySegment(int timeout, byte[] grpid, String filename) throws EisException {
		if (cfgReceiveData == null)
			throw new EisException("Fail to init receive queue.");
		if (grpid == null)
			throw new EisException("Error in MQConnection : group id is null.");
		
		if (MQQueueAccesser.getMsgFromQueueBySegment(grpid, cfgReceiveData, 
				MQQueueAccesser.MQ_MSGRECEIVE_TYPE, timeout, filename)) {			
			StringBuffer sb = new StringBuffer();
			logUtil.info(sb.append("Write file (").append(filename).append(") successfully."));
			sb = null;
			return true;
		} else {
			StringBuffer sb = new StringBuffer();
			logUtil.info(sb.append("Fail to write file (").append(filename).append(")."));
			sb = null;
			return false;
		}
	}

	
	public byte[] sendBySegment(byte[] msg) throws EisException {
		if (cfgSendData == null)
			throw new EisException("Fail to init send queue.");
		
		if (msg == null)
			throw new EisException("Error in MQConnection : send message is null.");
		
		if (logUtil.isInfoEnabled()) {
			StringBuffer sb;
			try {
				sb = new StringBuffer().append("send message:\n").append(new String(msg, encoding));
				logUtil.info(sb.toString());
			} catch (UnsupportedEncodingException e) {
				logUtil.error("Exception:", e);
			}				
			sb = null;
		}
		
		byte[] grpid = MQQueueAccesser.putMsgToQueueBySegment(cfgSendData, msg,
				MQQueueAccesser.MQ_MSGSEND_TYPE);
		if (grpid == null)
			throw new EisException("Fail to put mq msg.");
		return grpid;
	}
	
	public byte[] sendBySegment(String filename) throws EisException {
		if (cfgSendData == null)
			throw new EisException("Fail to init send queue.");
		
		if (filename == null)
			throw new EisException("Error in MQConnection : file name is null.");
		
		if (logUtil.isInfoEnabled()) {
			StringBuffer sb = new StringBuffer().append("send message:\n").append(filename);
			logUtil.info(sb.toString());
			sb = null;
		}
		
		byte[] grpid = MQQueueAccesser.putMsgToQueueBySegment(cfgSendData, filename,
				MQQueueAccesser.MQ_MSGSEND_TYPE);
		if (grpid == null)
			throw new EisException("Fail to put mq msg.");
		return grpid;
	}
	
	
}
