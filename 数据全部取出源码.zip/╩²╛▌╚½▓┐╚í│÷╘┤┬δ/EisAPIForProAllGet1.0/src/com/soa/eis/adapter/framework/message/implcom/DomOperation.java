package com.soa.eis.adapter.framework.message.implcom;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.dom4j.Attribute;
import org.dom4j.Branch;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.Text;
import org.dom4j.io.SAXReader;
import org.xml.sax.InputSource;

import com.soa.eis.adapter.framework.message.impl.GroupRecord;


/**
 * 新的XML操作类，基于dom4j
 * @author KAIHU
 *
 */
public class DomOperation {

	protected final String xpath = "/";
	protected final static String Dxpath = "//";
	protected final static String child = "child::";

	/**
	 * 构建Dom对象
	 * @return Document 
	 */
	protected static Document getDocument() {
		Document doc =DocumentHelper.createDocument();
		doc.setXMLEncoding("UTF-8");
		return doc;
	}

	/**
	 * 从文件中构建Dom对象
	 * @param filepath
	 * @return Document
	 * @throws Exception
	 */
	protected static Document getDocument(String filepath) throws Exception {
		SAXReader reader = new SAXReader();
		return reader.read(new File(filepath));
	}

	/**
	 * 从字节流中构建Dom对象
	 * @param bytesinput
	 * @return Document
	 * @throws Exception
	 */
	protected static Document getDocument(byte[] bytesinput) throws Exception {
		ByteArrayInputStream bais = new ByteArrayInputStream(bytesinput);
		InputSource is = new InputSource(bais);
		is.setEncoding("UTF-8");
		SAXReader reader = new SAXReader();
		bais.close();
		return reader.read(is);
	}

	/**
	 * 在当前节点下添加新节点
	 * @param branch
	 * @param name
	 * @param value
	 * @return Element
	 */
	protected static Element addChildValueByName(Branch branch, String name,
			String value) {
		//branch.addElement(name);
		Element e = null;
		e = DocumentHelper.makeElement(branch, name);
		if(null != value)
			e.addText(value);
		return e;
	}

	/**
	 * 取得当前节点下的指定节点值
	 * @param branch
	 * @param path
	 * @return String
	 */
	protected static String getChildValueByName(Branch branch, String path) {
		Element element = getElementByXpath(branch, path);
		if (null == element)
			return null;
		return element.getText();
	}

	/**
	 * 添加属性
	 * @param element
	 * @param name
	 * @param value
	 */
	protected static void addAttribute(Element element, String name,
			String value) {
		if (null != name && !"".equals(name.trim())) {
			element.addAttribute(name, value);
		}
	}

	/**
	 * 取得属性值
	 * @param element
	 * @param name
	 * @return String
	 */
	protected static String getAttriByName(Element element, String name) {
		String value = null;
		List<Attribute> list = getByXPath(element, "attribute::"+name);
		if(list!=null && list.size()>0){
			Attribute attribute = list.get(0);
			value = attribute.getValue();
		}
		return value;
	}

	/**
	 * 根据Xpath语法取得节点集合
	 * @param branch
	 * @param path
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	protected static List getByXPath(Branch branch, String path) {
		return branch.selectNodes(path);
	}
	/**
	 * 根据Xpath语法取得节点对象.
	 * @param branch
	 * @param path
	 * @return Node
	 */
	protected static Node getObjectByPath(Branch branch, String path){
		return branch.selectSingleNode(path);
	}

	/**
	 * 根据Xpath语法取得元素(Element)对象.
	 * @param branch
	 * @param path
	 * @return Element
	 */
	protected static Element getElementByXpath(Branch branch, String path) {
		Element element = (Element) branch.selectSingleNode(path);
		return element;
	}

	/**
	 * 设置子节点的值，如果该子节点不存在，则创建一个.返回该子节点
	 * @param branch
	 * @param name
	 * @param value
	 * @return Element
	 */
	protected static Element setChildValueByName(Branch branch, String name,
			String value) {
		if (null == branch || null == name || "".equals(name)) {
			return null;
		}
		Element e = getElementByXpath(branch, child + name);
		if (null != e) {
			if (null != value) {
				e.setText(value);
			}
		} else {
			e = addChildValueByName(branch, name, value);
		}
		return e;
	}

	/**
	 * 设置当前节点的字节的的值和属性.
	 * @param branch
	 * @param name
	 * @param value
	 * @param attrs
	 * @return Element
	 */
	protected static Element setChildValueByName(Branch branch, String name,
			String value, Properties attrs) {
		Element e = setChildValueByName(branch, name, value);
		if (attrs != null) {
			String ktmp = null;
			Enumeration<Object> keys = attrs.keys();
			while (keys.hasMoreElements()) {
				ktmp = keys.nextElement().toString();
				Attribute a = DocumentHelper.createAttribute(e, ktmp, attrs
						.getProperty(ktmp));
				e.add(a);
			}
		}
		return e;
	}

	/**
	 * 取得当前元素下的<code>GroupRecord</code>对象集合.
	 * @param element
	 * @param key
	 * @return List<GroupRecord>
	 */
	public static List<GroupRecord> getGroupArray(Element element,
			String key) {
		if (key == null)
			return null;
		List<GroupRecord> al = new ArrayList<GroupRecord>();
		List list = getByXPath(element, child + key);
		for (Object o : list) {
			Element e = (Element) o;
			if (isGroupRecord(e)) {
				GroupRecord gr = node2Group(e);
				al.add(gr);
			}
		}
		return al;
	}

	/**
	 * 将元素转换为<code>GroupRecord</code>对象
	 * @param e
	 * @return GroupRecord
	 */
	protected static GroupRecord node2Group(Element e) {
		GroupRecord gr = new GroupRecord();
		// 结点名
		String name = e.getName();

		// 设置Group的名字
		gr.setName(name);

		String value = null;
		// 设置此Group节点的属性
		Properties attris = processCommonAttribute(e);
		gr.setAttributes(attris);

		// 获取此Group结点的所有子结点
		List list = getByXPath(e, "child::*");
		Element etmp = null;
		HashMap<String, ArrayList<GroupRecord>> ap = new HashMap<String, ArrayList<GroupRecord>>();
		for (Object o : list) {
			etmp = (Element) o;
			if (etmp != null) {
				// 如果子结点还是Group
				if (isGroupRecord(etmp)) {
					// 处理子Group
					String subGRName = etmp.getName();
					ArrayList<GroupRecord> subGroupArray = new ArrayList<GroupRecord>();
					if (ap.containsKey(subGRName)) {
						subGroupArray = ap.get(subGRName);
					}
					// 递归调用，处理当前的子Group，并加入到结果的ArrayList
					subGroupArray.add(node2Group(etmp));
					ap.put(subGRName, subGroupArray);

				} else {
					if (Node.ELEMENT_NODE == etmp.getNodeType()) {
						if (etmp.hasContent()) {
							gr.setFieldValue(etmp.getName(), etmp.getText());
						} else {
							gr.setFieldValue(etmp.getName(), "");
						}
					}
				}
			}
		}
		if (ap.size() > 0) {
			for (String nameTmp : ap.keySet()) {
				gr.setSubGroups(nameTmp, ap.get(nameTmp));
			}
		}
		return gr;
	}

	/**
	 * 返回当前元素的属性集合
	 * @param e
	 * @return Properties
	 */
	protected static Properties processCommonAttribute(Element e) {
		Properties result = new Properties();
		String key = null, value;

		List<Attribute> list = getByXPath(e, "attribute::*");
		if (null != list && list.size() > 0) {
			for (Attribute a : list) {
				result.setProperty(a.getName(), a.getValue());
			}
		}
		return result;
	}

	/**
	 * 判断参数给定的XML结点是否为<code>GroupRecord</code>类型
	 * 
	 * @param ndtmp
	 * @return boolean
	 * @throws Exception
	 */
	protected static boolean isGroupRecord(Element e) {
		boolean result = false;
		Attribute a = (Attribute) getObjectByPath(e, "attribute::" + MsgConstants.MSG_GROUP_PROPERTY);
		if (null != a && MsgConstants.MSG_FIELD_TYPE_G.equals(a.getValue()))
			return true;
		else {
			// 获得所有的子结点
			List list = getByXPath(e, "child::*");
			if(list !=null && list.size()>0) return true;
		}
		return result;
	}


	/**
	 * 将<code>GroupRecord</code>对象添加到当前节点下
	 * @param branch
	 * @param gr
	 */
	protected static void addGroup2Node(Branch branch, GroupRecord gr) {
		
		//增加普通节点
		for (int i = 0;i < gr.getFieldSize(); i ++){
			String key = gr.getFieldKey(i);
			String value = gr.getFieldValue(i);
			if (null != key && null != value)
				addChildValueByName(branch,key,value);
		}
		
		//增加子节点
		for (int i = 0; i < gr.getSubGroupsSize(); i ++){
			List<GroupRecord> al = gr.getSubGroups(i);
			setGroupArray(branch,al,null);
		}
	}
	/**
	 * 将<code>GroupRecord</code>对象集合添加到当前节点下
	 * @param branch
	 * @param values
	 * @param curProcessKey
	 */
	protected static void setGroupArray(Branch branch, List<GroupRecord> values, String curProcessKey) {
		Element gelement = null;
		
		for (int i = 0, s = values.size(); i < s; i++) {
			GroupRecord gr = (GroupRecord) values.get(i);
			List<Element> list = getByXPath(branch, child+gr.getName());
			
			gelement = DocumentHelper.createElement(gr.getName());
			addAttribute(gelement, MsgConstants.MSG_GROUP_PROPERTY, gr.getType());
			addAttribute(gelement, MsgConstants.LOOP_NUM, String.valueOf(list.size() + 1));
			
			if (curProcessKey != null)
				addAttribute(gelement,MsgConstants.PROCESS, curProcessKey);
			
			// 填充原有的属性值
			Iterator<Map.Entry<Object, Object>> it = gr.getAttributes().entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<Object, Object> pairs = (Map.Entry<Object, Object>) it.next();
				addAttribute(gelement, pairs.getKey().toString(), pairs.getValue().toString());
			}
			
			
			// 填充原有的节点
			addGroup2Node(gelement, gr);
			branch.add(gelement);
			gelement = null;
		}
	}
	
	/**
	 * 删除指定的<code>GroupRecord</code>对象
	 * @param branch
	 * @param key
	 */
	protected static void removeGroupArray(Branch branch, String key) {
		List<Element> list = getByXPath(branch, child+key);
		for(Element e : list){
			if(isGroupRecord(e)){
				branch.remove(e);
			}
		}
	}
	/**
	 * 拷贝节点
	 * @param document
	 * @param target
	 * @param origin
	 */
	protected static void copySimpleNode(Document document, Element target, Element origin) {
		if(target==null||origin==null)
			return;
		// 复制子结点
		List<Element> sub_messageItems = getByXPath(origin, child+"*");
		if(sub_messageItems != null && sub_messageItems.size()>0){
			for(Element sub_messageItem : sub_messageItems){
				if(sub_messageItem.getName().equalsIgnoreCase(MsgConstants.PROCESSES)){
					
				}else{
					setSimpleChildNode(document, target, sub_messageItem);
				}
			}
		}
	}
	
	/**
	 * 拷贝一个简单外部子节点，并覆盖简单原子节点
	 * 简单节点指不包含字节点的节点
	 * @param document
	 * @param father
	 * @param son
	 * @return boolean
	 */
	protected static boolean setSimpleChildNode(Document document, Element father, Element son) {
		boolean isDone = false;
		if(father==null||son==null)
			return isDone;
		//获取节点名称
		String son_name = son.getName();
		// 获取节点的属性
		Properties props = null;
		if(son.attributes().size()>0){
			Iterator<Attribute> it = son.attributeIterator();
			while(it.hasNext()){
				Attribute a =it.next();
				props.put(a.getName(), a.getValue());
			}
		}
		// 获取节点的值
		String son_value = null;
		if(son.getText()!=null && !son.getTextTrim().equals("")){
			son_value = son.getTextTrim();
		}
		setChildValueByName(father, son_name,son_value, props);
		return isDone;
	}

	protected static void copyNode(Document document, Element target,
			Element origin) {
		if(target==null||origin==null)
			return;
		// 复制子结点
		
		List<Element> list = getByXPath(origin, child+"*");
		
		target.setContent(list);
		
		
//		for(Element e : list){
//			setChildNode(target, e);
//		}
		
	}

	/**
	 * 将子节点添加到父节点下.
	 * @param father
	 * @param son
	 * @return boolean
	 */
	protected static boolean setChildNode(Element father, Element son) {
		boolean isDone = false;
		
		if(father==null||son==null)
			return isDone;
		
		//获取节点名称
		String son_name = son.getName();
		
		// 获取节点的属性
		Properties props = null;
		Iterator<Attribute> it =son.attributeIterator();
		while(it.hasNext()){
			Attribute a = it.next();
			props.put(a.getName(), a.getValue());
		}

		
		// 获取节点的值
		String son_value = null;
		if(son.getText()!=null && !son.getTextTrim().equals("")){
			son_value = son.getTextTrim();
		}
		
		Element sonNode = setChildValueByName(father, son_value, son_name, props);

		// 复制子结点
		List<Element> list =getByXPath(son, child + "*");
		if(list.size()<1){
			// 如果没有子节点,则返回
			isDone = true;
		}else{
			for(Element e : list){
				isDone = setChildNode( sonNode, e);
			}
		}
		return isDone;
		
	}

	/**
	 * 返回当前节点下指定的字节元素.
	 * @param branch
	 * @param key
	 * @return Element
	 */
	protected static Element getChildByName(Branch branch, String key) {
		Element element =getElementByXpath(branch, child+key);
		return element;
	}

	/**
	 * 根据元素名称和属性,取得当前节点下的元素对象.
	 * @param element
	 * @param key
	 * @param attrs
	 * @return Element
	 */
	protected static Element getChildByNameAndAttr(Element element,
			String key, Properties attrs) {
		boolean judge = false;
		if (null == element || null == key || "".equals(key.trim()))
			return null;
		List<Element> list = getByXPath(element, child+key);
		if(list == null || list.size()<1)
			return null;
		// attrs中的属性只要在该节点下都有即可
		for(Element e : list ){
			if(attrs == null)
				return e;
			else if(attrs.size()==0){
				if(!e.attributeIterator().hasNext()){
					return e;
				}
			}else{
				judge= true;
				Iterator<Map.Entry<Object,Object>> it = attrs.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry<Object,Object> pairs = (Map.Entry<Object,Object>) it.next();
					Attribute a = (Attribute) getObjectByPath(e, "attribute::"+pairs.getKey());
					if(a == null || !a.getValue().equals(pairs.getValue()))
						judge = false;
						break;
				}
				if (judge)
					return e;
			}
		}
		return null;
	}

	/**
	 * 取得元素值.
	 * @param node
	 * @return String
	 */
	protected static String getValue(Element node) {
		if (null == node)
			return null;
		return node.getText();
	}

	/**
	 * 根据元素名称和属性,删除指定元素.
	 * @param element
	 * @param groupName
	 * @param attrs
	 */
	protected static void removeGroupArray(Element element, String groupName,
			Properties attrs) {
		List<Element> list = getByXPath(element, child+groupName);
		for(Element e : list){
			if(isGroupRecord(e)){
				List<Element> list2 = getByXPath(e, child+"*");
				for(Element e2 : list2){
					if(e.getText().equals(attrs.get(e.getName()))){
						element.remove(e);
						break;
					}
				}
			}
		}
	}

	/**
	 * 返回指定的元素集合
	 * @param element
	 * @param key
	 * @return ArrayList<Element>
	 */
	protected static ArrayList<Element> getChildListByName(Element element,
			String key) {
		ArrayList<Element> list = new ArrayList<Element>();
		if (null == element || null == key || "".equals(key.trim()))
			return null;
		List<Element> elist =null;
		if (null != element)
			elist = getByXPath(element, child+"key");
		if(elist!=null)
			list = new ArrayList<Element>(elist);
		if(list.size()>0)
			return list;
		else
			return null;
	}

	/**
	 * 将原节点下的子元素复制给目标节点.
	 * @param document
	 * @param target
	 * @param origin
	 */
	protected static void copyNodeNotOverride(Document document, Element target,
			Element origin) {
		if(target==null||origin==null)
			return;
		
		Element tmp = origin.createCopy();
		target.add(tmp);		
		// 复制子结点
		List<Element> list = getByXPath(origin, child+"*");
		for(Element e : list){
			addChildNode(document, target, e);
		}
	}

	/**
	 * 将字节的的拷贝添加到父节点下
	 * @param document
	 * @param father
	 * @param son
	 * @return boolean
	 */
	protected static boolean addChildNode(Document document, Element father,
			Element son) {
		boolean isDone = false;
		
		if(father==null||son==null)
			return isDone;
		Element tmp = son.createCopy();
		father.add(tmp);
		
		return true;
	}

	/**
	 * 在父节点下添加子节点.
	 * @param father
	 * @param son_name
	 * @param son_value
	 * @param props
	 * @return Element
	 */
	protected static Element addChildValueByName(Element father, String son_name,
			String son_value, Properties props) {
		Element element = null;
		
		if (null == father || null == son_name || "".equals(son_name.trim()))
			return null;
		element = DocumentHelper.createElement(son_name);
		if (son_value != null) {
			Text text = DocumentHelper.createText(son_value);
			element.add(text);
		}
		if (props != null) {
			String ktmp = null;
			Enumeration<Object> keys = props.keys();
			while (keys.hasMoreElements()) {
				ktmp = keys.nextElement().toString();
				element.addAttribute(ktmp, (String) props.get(ktmp));
			}
		}
		father.add(element);
		return element;
	}

	protected static String valuePattern = "^[A-Za-z1-9.,()/='+-?!”&*;@#\n\r ]+$";
	protected static String keyPattern = "^[A-Za-z1-9]+$";
	/**
	 * 验证元素名称字符是否合法.
	 * @param key
	 * @return boolean
	 */
	public static boolean validKey(String key){
		if(key==null)
			return true;
		Pattern p = Pattern.compile(keyPattern);
		Matcher m = p.matcher(key);
		boolean result = m.find();
		return result;
	}
	/**
	 * 验证元素内容是否合法.
	 * @param value
	 * @return boolean
	 */
	public static boolean validValue(String value){
		if(value==null)
			return true;
		Pattern p = Pattern.compile(valuePattern);
		Matcher m = p.matcher(value);
		boolean result = m.find();
		return result;
	}
	 
	
	

}
