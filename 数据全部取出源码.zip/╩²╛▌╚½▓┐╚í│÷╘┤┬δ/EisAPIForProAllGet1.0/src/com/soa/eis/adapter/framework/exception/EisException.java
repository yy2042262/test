/**
 * 
 */
package com.soa.eis.adapter.framework.exception;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;

import com.soa.eis.adapter.framework.utils.log.LogUtil;


/**
 * EIS 自定义异常
 * @author wangtao
 *
 */
public class EisException extends Exception {
	private String code;
	
	public String getCode(){
		return code;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 2613005614399603444L;
	private Throwable cause = null;
	
	public EisException(){
		super();
	}
	
	public EisException(String message){
		super(message);
	}
	
	public EisException(String code,String message){
		super(code + ":" + message);
		this.code = code;
	}
	
	public EisException(Throwable cause){
		super(cause.getMessage());
		this.cause=cause;
	}
	
	public void printStackTrace() {
		if (cause != null)
			cause.printStackTrace();
		else
			super.printStackTrace();
	}

	public void printStackTrace(PrintStream s) {
		if (cause != null)
			cause.printStackTrace(s);
		else
			super.printStackTrace(s);
	}

	public void printStackTrace(PrintWriter s) {
		if (cause != null)
			cause.printStackTrace(s);
		else
			super.printStackTrace(s);
	}
	
	/**
	 * 打印Trace信息
	 * @param e
	 * @return
	 */	
	public static String getTrace(Exception e){
		if(null==e) return null;
		ByteArrayOutputStream out = null;
		PrintStream print = null;
		try {
			out = new ByteArrayOutputStream();
			print = new PrintStream(out);
			e.printStackTrace(print);
			print.flush();
			out.flush();
			return out.toString();
		}catch(Exception e1){
			LogUtil.getInstance().error("In Eis exception get trace error",e1);
			return null;
		}
	}

}
