package com.soa.eis.adapter.framework.requester;

import java.util.List;

import com.soa.eis.adapter.framework.connection.IConnectionPoolManager;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.message.IMsgObject;


public interface IServiceRequester {
	/**
	 * @param reqMo
	 *            request message object
	 * @return response message object
	 * @throws Exception 
	 * @throws AdapterException
	 */
	public IMsgObject execute(IMsgObject reqMo) throws EisException;

	/**
	 * @param reqMo
	 *            request message object
	 * @param timeout
	 *            time to wait for the response (seconds)
	 * @return response message object
	 * @throws AdapterException
	 */
	public IMsgObject execute(IMsgObject reqMo, int timeout)
			throws EisException;
	
	/**
	 * 关闭连接
	 */
	public void closeConnection();
	
	/**
	 * 获取连接池管理器List[用于Requester转换MQ队列管理器重发]
	 * @return
	 */
	public List<IConnectionPoolManager> getConnectionPoolManagerList();
}
