package com.soa.eis.adapter.framework.common; 

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.utils.log.ILog;
import com.soa.eis.adapter.framework.utils.log.LogUtil;
/**
 * 配置缓存管理类
 * @author wangtao
 *
 */
public class CacheManager {
	private static CacheManager cm = null;
	protected ILog logUtil = null;
	private Properties config = new Properties();
	
	private CacheManager() {
		this.logUtil = LogUtil.getInstance();
		InputStream istream = null;
		try {
			try{
				URL in = getClass().getResource("/");
				System.out.println(in + ConfigConstants.CONFIG_FILE);
			}catch(Exception e){
				e.printStackTrace();
			}
			
			if (ConfigConstants.CONFIG_FILE != null && !ConfigConstants.CONFIG_FILE.startsWith("/")){
				istream = getClass().getResourceAsStream("/" + ConfigConstants.CONFIG_FILE);
			}else{
				istream = getClass().getResourceAsStream(ConfigConstants.CONFIG_FILE);
			}
			
			if (istream == null){
				istream = new FileInputStream(ConfigConstants.CONFIG_FILE);
			}
			config.load(istream);
			istream.close();
			
			
			
		} catch (Exception e) {
			try{
				File file = new File(ConfigConstants.CONFIG_FILE);
				logUtil.error(file.getAbsolutePath());
				System.out.println(file.getAbsolutePath());
			}catch(Exception ex){
				ex.printStackTrace();
			}
			
			logUtil.error("loadConfigurations fail : "+ConfigConstants.CONFIG_FILE);
			logUtil.error("Exception:", e);
		} finally {
			try {
				istream.close();
			} catch (Exception ex) {
			}
		}
	}
	
	public static synchronized CacheManager getInstance() throws EisException {
		if (cm == null) {
			cm = new CacheManager();
		}
		return cm;
	}

	public ILog getLogUtil() {
		return logUtil;
	}

	public Properties getConfig() {
		return config;
	}
	
}
