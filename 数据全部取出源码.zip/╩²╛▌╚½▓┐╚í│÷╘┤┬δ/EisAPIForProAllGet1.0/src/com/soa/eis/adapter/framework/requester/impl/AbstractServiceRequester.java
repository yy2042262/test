package com.soa.eis.adapter.framework.requester.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.soa.eis.adapter.framework.common.CacheManager;
import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.connection.IConnection;
import com.soa.eis.adapter.framework.connection.IConnectionPoolManager;
import com.soa.eis.adapter.framework.connection.mqc.MQParameter;
import com.soa.eis.adapter.framework.connection.mqcm.PoolableMQConnectionManager;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.message.IMsgObject;
import com.soa.eis.adapter.framework.requester.IServiceRequester;
import com.soa.eis.adapter.framework.utils.log.ILog;

abstract class AbstractServiceRequester implements IServiceRequester {
	private IConnectionPoolManager connectionPoolManager;
	private List<IConnectionPoolManager> connectionPoolManagerList = new ArrayList<IConnectionPoolManager>();
	protected ILog logUtil;
	protected Properties config;
	protected List<MQParameter> reqList = new ArrayList<MQParameter>();
	protected List<MQParameter> resList = new ArrayList<MQParameter>();

	public AbstractServiceRequester() throws EisException {

		this.logUtil = CacheManager.getInstance().getLogUtil();
		logUtil.info("AbstractServiceRequester init Start()");
		
		this.config = CacheManager.getInstance().getConfig();
		
		//加载主MQ队列管理器
		MQParameter req = new MQParameter(config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_IP), 
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_PORT)),
				config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_CHANNEL),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_CCSID)),
				config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_QMANAGER),
				config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_QUEUE));
		reqList.add(req);
		
		MQParameter res = new MQParameter(config.getProperty(ConfigConstants.MQ_REQUESTER_RES_IP), 
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_RES_PORT)),
				config.getProperty(ConfigConstants.MQ_REQUESTER_RES_CHANNEL),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_RES_CCSID)),
				config.getProperty(ConfigConstants.MQ_REQUESTER_RES_QMANAGER),
				config.getProperty(ConfigConstants.MQ_REQUESTER_RES_QUEUE));
		resList.add(res);
		
		connectionPoolManager = new PoolableMQConnectionManager(
				reqList,
				resList,
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_POOL_MAXNUM)),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_GETCONN_TIMEOUT)));
		
		connectionPoolManagerList.add(connectionPoolManager);
		
		
		//加载备用MQ队列管理器
		String AltConfig = config.getProperty(ConfigConstants.ALTERNATIVE_REQUESTER_CONFIG);
		if(AltConfig != null && !"".equals(AltConfig.trim())){
			String[] AltConfigArr = AltConfig.split(ConfigConstants.ALTERNATIVE_CONFIG_SPLIT);
			
			for (int i = 0; i < AltConfigArr.length; i++) {
				String alt = AltConfigArr[i] + ".";
				
				MQParameter req_t = new MQParameter(config.getProperty(alt + ConfigConstants.MQ_REQUESTER_REQ_IP), 
						Integer.parseInt(config.getProperty(alt + ConfigConstants.MQ_REQUESTER_REQ_PORT)),
						config.getProperty(alt + ConfigConstants.MQ_REQUESTER_REQ_CHANNEL),
						Integer.parseInt(config.getProperty(alt + ConfigConstants.MQ_REQUESTER_REQ_CCSID)),
						config.getProperty(alt + ConfigConstants.MQ_REQUESTER_REQ_QMANAGER),
						config.getProperty(alt + ConfigConstants.MQ_REQUESTER_REQ_QUEUE));
				
				List<MQParameter> reqList_t = new ArrayList<MQParameter>();
				reqList_t.add(req_t);
				
				MQParameter res_t = new MQParameter(config.getProperty(alt + ConfigConstants.MQ_REQUESTER_RES_IP), 
						Integer.parseInt(config.getProperty(alt + ConfigConstants.MQ_REQUESTER_RES_PORT)),
						config.getProperty(alt + ConfigConstants.MQ_REQUESTER_RES_CHANNEL),
						Integer.parseInt(config.getProperty(alt + ConfigConstants.MQ_REQUESTER_RES_CCSID)),
						config.getProperty(alt + ConfigConstants.MQ_REQUESTER_RES_QMANAGER),
						config.getProperty(alt + ConfigConstants.MQ_REQUESTER_RES_QUEUE));
				
				List<MQParameter> resList_t = new ArrayList<MQParameter>();
				resList_t.add(res_t);
				
				IConnectionPoolManager connectionPoolManager_t = new PoolableMQConnectionManager(
						reqList_t,
						resList_t,
						Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_POOL_MAXNUM)),
						Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_GETCONN_TIMEOUT)));
				
				connectionPoolManagerList.add(connectionPoolManager_t);
			}
		}
		
		logUtil.info("AbstractServiceRequester init End()");
	}

	public IMsgObject execute(IMsgObject reqMo) throws EisException {
		
		String sysId = reqMo.getSourceSysID();
		if (sysId == null || sysId.trim().equals("")){
			reqMo.setSourceSysID(config.getProperty(ConfigConstants.SYSID));
		}
		
		String MQ_REQUESTER_REQ_TIMEOUT = config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_TIMEOUT);
		if (MQ_REQUESTER_REQ_TIMEOUT == null){
			return execute(reqMo, IConnection.DEFAULT_TIMEOUT);
		}else{
			return execute(reqMo, Integer.parseInt(MQ_REQUESTER_REQ_TIMEOUT));
		}
		
	}
	
	/**
	 * 重置连接池
	 */
	protected void resetConnectionPoolManager(){
		try {
			connectionPoolManagerList.get(0).close();
			connectionPoolManagerList.set(0, new PoolableMQConnectionManager(reqList, resList,
					Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_POOL_MAXNUM)),
					Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_GETCONN_TIMEOUT))));
			logUtil.info("已重置主MQ连接！");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public abstract IMsgObject execute(IMsgObject reqMo, int timeout)throws EisException;

	public IConnectionPoolManager getConnectionPoolManager() {
		return connectionPoolManager;
	}
	
	public List<IConnectionPoolManager> getConnectionPoolManagerList(){
		return connectionPoolManagerList;
	}

	public Properties getConfig() {
		return config;
	}
}
