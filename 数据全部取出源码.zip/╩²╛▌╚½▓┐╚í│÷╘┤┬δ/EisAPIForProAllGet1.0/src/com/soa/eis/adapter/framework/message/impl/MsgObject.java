package com.soa.eis.adapter.framework.message.impl;

import java.util.List;

import org.dom4j.Element;

import com.soa.eis.adapter.framework.message.IMsgObject;
import com.soa.eis.adapter.framework.message.implcom.MsgConstants;
import com.soa.eis.adapter.framework.message.implcom.MsgObjectComm;
import com.soa.eis.adapter.framework.utils.log.LogUtil;

public class MsgObject extends MsgObjectComm implements IMsgObject,Cloneable {
	
	public MsgObject() throws Exception{
		super(MOType.initSR);
	}
	
	public MsgObject(MOType mt) throws Exception{
		super(mt);
	}
	
	public MsgObject(byte[] bytesinput, MOType mt) throws Exception {
		super(bytesinput, mt);
	}
	
	@Override
	public byte[] getBytes() {
		try{
			return this.write2Bytes();
		}catch(Exception e){
			LogUtil.getInstance().error("Exception",e);
		}
		return null;
	}
	
	
	public String getServResStatus(){
		return super.getServiceResponse(MsgConstants.STATUS);
	}


	@Override
	public String getControlValue(String key) {
		return super.getCurrentControl(key);
	}


	@Override
	public List<GroupRecord> getReqGroupRecord(String key) {
		return super.getRequestGroupArray(key);
	}


	@Override
	public String getReqValue(String key) {
		return super.getRequestParameter(key);
	}


	@Override
	public List<GroupRecord> getResGroupRecord(String key) {
		return super.getResponseGroupArray(key);
	}


	@Override
	public String getResValue(String key) {
		return super.getResponseParameter(key);
	}


	@Override
	public void removeRequestElement() {
		super.removeRequestNode();
		
	}


	@Override
	public void removeResponseElement() {
		super.removeResponseNode();
	}


	@Override
	public void setControlValue(String key, String value) {
		super.setCurrentControl(key, value);
	}


	@Override
	public void setReqGroupRecord(List<GroupRecord> gr) {
		super.setRequestGroupArray(gr);
	}


	@Override
	public void setReqValue(String key, String value) {
		super.setRequestParameter(key, value);
		
	}


	@Override
	public void setResGroupRecord(List<GroupRecord> gr) {
		super.setResponseGroupArray(gr);
	}


	@Override
	public void setResValue(String key, String value) {
		super.setResponseParameter(key, value);
		
	}


	@Override
	public IMsgObject clone() {
		IMsgObject clone = null;
		try {
			clone = (IMsgObject) super.clone();
		} catch (CloneNotSupportedException e) {
			LogUtil.getInstance().error("Exception",e);
		}
		return clone;
		
	}

	@Override
	public String getServResCode() {
		return super.getServiceResponse(MsgConstants.CODE);
	}

	@Override
	public String getServResDesc() {
		return super.getServiceResponse(MsgConstants.DESC);
	}

	@Override
	public String getServResSourceSysCode() {
		return super.getServiceResponse(MsgConstants.SOURCE_SYSTEM_CODE);
	}

	@Override
	public String getServResSourceSysDesc() {
		return super.getServiceResponse(MsgConstants.SOURCE_SYSTEM_DESC);
	}

	@Override
	public void setServResCode(String value) {
		super.setServiceResponse(MsgConstants.CODE, value);
	}

	@Override
	public void setServResDesc(String value) {
		super.setServiceResponse(MsgConstants.DESC, value);
	}

	@Override
	public void setServResSourceSysCode(String value) {
		super.setServiceResponse(MsgConstants.SOURCE_SYSTEM_CODE, value);
	}

	@Override
	public void setServResSourceSysDesc(String value) {
		super.setServiceResponse(MsgConstants.SOURCE_SYSTEM_DESC, value);
	}

	@Override
	public void setServResStatus(String value) {
		super.setServiceResponse(MsgConstants.STATUS, value);
	}

	@Override
	public String getBusinessCode() {
		return super.getHeaderAttribute(MsgConstants.BUSINESS_CODE);
	}

	@Override
	public void setBusinessCode(String code) {
		super.setHeaderAttribute(MsgConstants.BUSINESS_CODE, code);
	}
	
	public String getProReplyQmgr(){
		return super.getCurrentProcessProperty(MsgConstants.REPLY_QMGR);
	}
	
	public Element getRoute(){
		return super.getRoute();
	}
}
