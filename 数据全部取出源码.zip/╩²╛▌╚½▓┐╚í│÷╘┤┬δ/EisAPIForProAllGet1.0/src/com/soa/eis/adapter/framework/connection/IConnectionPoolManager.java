
package com.soa.eis.adapter.framework.connection; 

import com.soa.eis.adapter.framework.exception.EisException;
/**
 * 连接池管理接口
 * @author wangtao
 *
 */

public interface IConnectionPoolManager extends IConnectionManager {
	/**
	 * close pool
	 */
	public void close() throws EisException;

}
