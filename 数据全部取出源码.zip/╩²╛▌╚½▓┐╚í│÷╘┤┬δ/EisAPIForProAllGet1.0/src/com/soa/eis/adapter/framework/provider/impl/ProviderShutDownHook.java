package com.soa.eis.adapter.framework.provider.impl;

import java.util.HashSet;
import java.util.Set;

import com.soa.eis.adapter.framework.common.CacheManager;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.provider.IServiceProvider;
import com.soa.eis.adapter.framework.utils.log.ILog;
import com.soa.eis.adapter.framework.utils.log.LogUtil;

public class ProviderShutDownHook extends Thread {
	private static ILog logUtil ;

	private ProviderShutDownHook() throws EisException {
		logUtil = CacheManager.getInstance().getLogUtil();
	}

	static {
		ProviderShutDownHook shutDownHook;
		try {
			shutDownHook = new ProviderShutDownHook();
			Runtime.getRuntime().addShutdownHook(shutDownHook);
		} catch (EisException e) {
			LogUtil.getInstance().error("Exception",e);
		}
	}

	protected static Set<IServiceProvider> providerSet = new HashSet<IServiceProvider>();

	protected static synchronized void register(IServiceProvider provider) {
		StringBuffer sb = new StringBuffer().append("Register provider ").append(provider).append(" to ProviderShutDownHook");
		logUtil.debug(sb);
		sb = null;
		providerSet.add(provider);
	}

	public void run() {
		logUtil.info("Providers are shutting down ...");
		Object[] providers = providerSet.toArray();
		for (int i = 0; i < providers.length; i++) {
			IServiceProvider provider = (IServiceProvider) providers[i];
			provider.closeConnection();
			provider.stop();
		}
	}
}
