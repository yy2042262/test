package com.soa.eis.adapter.framework.requester.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.soa.eis.adapter.framework.common.CacheSAPManager;
import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.connection.IConnection;
import com.soa.eis.adapter.framework.connection.IConnectionPoolManager;
import com.soa.eis.adapter.framework.connection.mqc.MQParameter;
import com.soa.eis.adapter.framework.connection.mqcm.PoolableMQConnectionManager;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.message.IMsgObject;
import com.soa.eis.adapter.framework.requester.IServiceRequester;
import com.soa.eis.adapter.framework.utils.log.ILog;

public abstract class AbstractSAPServiceRequester implements IServiceRequester {

	private IConnectionPoolManager connectionPoolManager;
	protected ILog logUtil;
	private Properties config;

	public AbstractSAPServiceRequester(String fileURL) throws EisException {

		CacheSAPManager c = new CacheSAPManager(fileURL);
		this.logUtil = c.getLogUtil();
		logUtil.info("AbstractSAPServiceRequester init Start()");
		this.config = c.getConfig();
		
		String AltConfig = config.getProperty(ConfigConstants.ALTERNATIVE_REQUESTER_CONFIG);
		if (AltConfig == null){
			AltConfig = "";
		}
		String[] AltConfigArr = AltConfig.split(ConfigConstants.ALTERNATIVE_CONFIG_SPLIT);
		
		List<MQParameter> reqList = new ArrayList<MQParameter>();
		
		MQParameter req = new MQParameter(config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_IP), 
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_PORT)),
				config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_CHANNEL),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_CCSID)),
				config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_QMANAGER),
				config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_QUEUE));
		
		reqList.add(req);
		
		for (int i = 0; i < AltConfigArr.length; i++) {
			String reqAlt = AltConfigArr[i];
			
			MQParameter req_t = new MQParameter(config.getProperty(reqAlt + ConfigConstants.MQ_REQUESTER_REQ_IP), 
					Integer.parseInt(config.getProperty(reqAlt + ConfigConstants.MQ_REQUESTER_REQ_PORT)),
					config.getProperty(reqAlt + ConfigConstants.MQ_REQUESTER_REQ_CHANNEL),
					Integer.parseInt(config.getProperty(reqAlt + ConfigConstants.MQ_REQUESTER_REQ_CCSID)),
					config.getProperty(reqAlt + ConfigConstants.MQ_REQUESTER_REQ_QMANAGER),
					config.getProperty(reqAlt + ConfigConstants.MQ_REQUESTER_REQ_QUEUE));
			
			reqList.add(req_t);
		}
		
		List<MQParameter> resList = new ArrayList<MQParameter>();
		
		MQParameter res = new MQParameter(config.getProperty(ConfigConstants.MQ_REQUESTER_RES_IP), 
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_RES_PORT)),
				config.getProperty(ConfigConstants.MQ_REQUESTER_RES_CHANNEL),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_RES_CCSID)),
				config.getProperty(ConfigConstants.MQ_REQUESTER_RES_QMANAGER),
				config.getProperty(ConfigConstants.MQ_REQUESTER_RES_QUEUE));
		
		resList.add(res);
		
		for (int i = 0; i < AltConfigArr.length; i++) {
			String resAlt = AltConfigArr[i];
			
			MQParameter res_t = new MQParameter(config.getProperty(resAlt + ConfigConstants.MQ_REQUESTER_RES_IP), 
					Integer.parseInt(config.getProperty(resAlt + ConfigConstants.MQ_REQUESTER_RES_PORT)),
					config.getProperty(resAlt + ConfigConstants.MQ_REQUESTER_RES_CHANNEL),
					Integer.parseInt(config.getProperty(resAlt + ConfigConstants.MQ_REQUESTER_RES_CCSID)),
					config.getProperty(resAlt + ConfigConstants.MQ_REQUESTER_RES_QMANAGER),
					config.getProperty(resAlt + ConfigConstants.MQ_REQUESTER_RES_QUEUE));
			
			resList.add(res_t);
		}
		
		
		connectionPoolManager = new PoolableMQConnectionManager(
				reqList,
				resList,
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_POOL_MAXNUM)),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_REQUESTER_GETCONN_TIMEOUT)));
		logUtil.info("AbstractSAPServiceRequester init End()");
	}

	public IMsgObject execute(IMsgObject reqMo) throws EisException {
		
		String sysId = reqMo.getSourceSysID();
		if (sysId == null || sysId.trim().equals("")){
			reqMo.setSourceSysID(config.getProperty(ConfigConstants.SYSID));
		}
		
		String  MQ_REQUESTER_REQ_TIMEOUT =  config.getProperty(ConfigConstants.MQ_REQUESTER_REQ_TIMEOUT);
		if (MQ_REQUESTER_REQ_TIMEOUT == null){
			return execute(reqMo, IConnection.DEFAULT_TIMEOUT);
		}else{
			return execute(reqMo, Integer.parseInt(MQ_REQUESTER_REQ_TIMEOUT));
		}
		
	}

	public abstract IMsgObject execute(IMsgObject reqMo, int timeout)throws EisException;
//	public IMsgObject execute(IMsgObject reqMo, int timeout)
//			throws EisException {
//		return execute(reqMo, timeout);
//	}

	public IConnectionPoolManager getConnectionPoolManager() {
		return connectionPoolManager;
	}
	
	public List<IConnectionPoolManager> getConnectionPoolManagerList(){
		return null;
	}

	public Properties getConfig() {
		return config;
	}

}
