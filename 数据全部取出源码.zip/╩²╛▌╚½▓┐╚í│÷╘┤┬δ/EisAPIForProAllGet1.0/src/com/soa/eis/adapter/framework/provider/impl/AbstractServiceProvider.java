package com.soa.eis.adapter.framework.provider.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.soa.eis.adapter.framework.common.CacheManager;
import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.connection.IConnectionPoolManager;
import com.soa.eis.adapter.framework.connection.mqc.MQParameter;
import com.soa.eis.adapter.framework.connection.mqcm.PoolableMQConnectionManager;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.handler.IServiceHandler;
import com.soa.eis.adapter.framework.provider.IServiceProvider;
import com.soa.eis.adapter.framework.utils.log.ILog;
import com.soa.eis.adapter.framework.utils.log.LogUtil;

public abstract class AbstractServiceProvider implements IServiceProvider {
	
	private static final int STATUS_PAUSE = 0;
	private static final int STATUS_START = 1;
	private static final int STATUS_STOP = 2;
	
	protected IServiceHandler handler = null;
	private IConnectionPoolManager connectionPoolManager;
	protected ILog logUtil;
	private int status = STATUS_PAUSE;
	protected Properties config;
	private boolean isT = true;
	protected List<MQParameter> receiveList = new ArrayList<MQParameter>();
	protected List<MQParameter> sendList = new ArrayList<MQParameter>();
	
	/**
	 * 加载主MQ配置
	 * @throws EisException
	 */
	public AbstractServiceProvider() throws EisException {
		this.logUtil = LogUtil.getInstance();
		this.config = CacheManager.getInstance().getConfig();
		
//		String AltConfig = config.getProperty(ConfigConstants.ALTERNATIVE_PROVIDER_CONFIG);
//		if (AltConfig == null){
//			AltConfig = "";
//		}
//		String[] AltConfigArr = AltConfig.split(ConfigConstants.ALTERNATIVE_CONFIG_SPLIT);
		
		
//		List<MQParameter> receiveList = new ArrayList<MQParameter>();
		
		MQParameter receive = new MQParameter(config.getProperty(ConfigConstants.MQ_PROVIDER_RECV_IP),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_RECV_PORT)),
				config.getProperty(ConfigConstants.MQ_PROVIDER_RECV_CHANNEL),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_RECV_CCSID)),
				config.getProperty(ConfigConstants.MQ_PROVIDER_RECV_QMANAGER),
				config.getProperty(ConfigConstants.MQ_PROVIDER_RECV_QUEUE));
		receiveList.add(receive);
		
//		for (int i = 0; i < AltConfigArr.length; i++) {
//			String receiveAlt = AltConfigArr[i].trim();
//			MQParameter receive_t = new MQParameter(config.getProperty(receiveAlt + ConfigConstants.MQ_PROVIDER_RECV_IP),
//					Integer.parseInt(config.getProperty(receiveAlt + ConfigConstants.MQ_PROVIDER_RECV_PORT)),
//					config.getProperty(receiveAlt + ConfigConstants.MQ_PROVIDER_RECV_CHANNEL),
//					Integer.parseInt(config.getProperty(receiveAlt + ConfigConstants.MQ_PROVIDER_RECV_CCSID)),
//					config.getProperty(receiveAlt + ConfigConstants.MQ_PROVIDER_RECV_QMANAGER),
//					config.getProperty(receiveAlt + ConfigConstants.MQ_PROVIDER_RECV_QUEUE));
//			
//			receiveList.add(receive_t);
//		}
		
		
//		List<MQParameter> sendList = new ArrayList<MQParameter>();
		
		MQParameter send = new MQParameter(config.getProperty(ConfigConstants.MQ_PROVIDER_SEND_IP),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_SEND_PORT)),
				config.getProperty(ConfigConstants.MQ_PROVIDER_SEND_CHANNEL),
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_SEND_CCSID)),
				config.getProperty(ConfigConstants.MQ_PROVIDER_SEND_QMANAGER),
				config.getProperty(ConfigConstants.MQ_PROVIDER_SEND_QUEUE));
		sendList.add(send);
		
//		for (int i = 0; i < AltConfigArr.length; i++) {
//			String sendAlt = AltConfigArr[i].trim();
//			MQParameter send_t = new MQParameter(config.getProperty(sendAlt + ConfigConstants.MQ_PROVIDER_SEND_IP),
//					Integer.parseInt(config.getProperty(sendAlt + ConfigConstants.MQ_PROVIDER_SEND_PORT)),
//					config.getProperty(sendAlt + ConfigConstants.MQ_PROVIDER_SEND_CHANNEL),
//					Integer.parseInt(config.getProperty(sendAlt + ConfigConstants.MQ_PROVIDER_SEND_CCSID)),
//					config.getProperty(sendAlt + ConfigConstants.MQ_PROVIDER_SEND_QMANAGER),
//					config.getProperty(sendAlt + ConfigConstants.MQ_PROVIDER_SEND_QUEUE));
//			sendList.add(send_t);
//		}
		
		
		connectionPoolManager = new PoolableMQConnectionManager(sendList, receiveList,
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_POOL_MAXNUM)) * 2,
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_GETCONN_TIMEOUT)));
		
		ProviderShutDownHook.register(this);
	}
	
	/**
	 * 加载备份MQ配置
	 * @throws EisException
	 */
	public AbstractServiceProvider(String alt) throws EisException {
		this.logUtil = LogUtil.getInstance();
		this.config = CacheManager.getInstance().getConfig();
		alt = alt + ".";
		
		MQParameter receive = new MQParameter(config.getProperty(alt + ConfigConstants.MQ_PROVIDER_RECV_IP),
				Integer.parseInt(config.getProperty(alt + ConfigConstants.MQ_PROVIDER_RECV_PORT)),
				config.getProperty(alt + ConfigConstants.MQ_PROVIDER_RECV_CHANNEL),
				Integer.parseInt(config.getProperty(alt + ConfigConstants.MQ_PROVIDER_RECV_CCSID)),
				config.getProperty(alt + ConfigConstants.MQ_PROVIDER_RECV_QMANAGER),
				config.getProperty(alt + ConfigConstants.MQ_PROVIDER_RECV_QUEUE));
		receiveList.add(receive);
		
		MQParameter send = new MQParameter(config.getProperty(alt + ConfigConstants.MQ_PROVIDER_SEND_IP),
				Integer.parseInt(config.getProperty(alt + ConfigConstants.MQ_PROVIDER_SEND_PORT)),
				config.getProperty(alt + ConfigConstants.MQ_PROVIDER_SEND_CHANNEL),
				Integer.parseInt(config.getProperty(alt + ConfigConstants.MQ_PROVIDER_SEND_CCSID)),
				config.getProperty(alt + ConfigConstants.MQ_PROVIDER_SEND_QMANAGER),
				config.getProperty(alt + ConfigConstants.MQ_PROVIDER_SEND_QUEUE));
		sendList.add(send);
		
		connectionPoolManager = new PoolableMQConnectionManager(sendList, receiveList,
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_POOL_MAXNUM)) * 2,
				Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_GETCONN_TIMEOUT)));
		
		ProviderShutDownHook.register(this);
	}
	
	
	
	public static int MQ_PROVIDER_RECV_TIMEOUT = 180;
	
	/**
	 * 返回获取数据超时时间
	 * @return
	 */
	public int getProviderRecvTimeOut(){
		String TimeOut ;
		try {
			TimeOut = CacheManager.getInstance().getConfig().getProperty(ConfigConstants.MQ_PROVIDER_RECV_TIMEOUT);			
		} catch (EisException e) {
			LogUtil.getInstance().error("Exception",e);
			return MQ_PROVIDER_RECV_TIMEOUT;
		}
		if (null == TimeOut)
			return MQ_PROVIDER_RECV_TIMEOUT;
		return Integer.parseInt(TimeOut);
	}
	
	@Override
	public void pause() {
		status = STATUS_PAUSE;
	}

	@Override
	public void setServiceHandler(IServiceHandler serviceHandler) {
		if (this.handler == null){
			this.handler = serviceHandler;	
		}
	}

	@Override
	public void start() throws EisException {
		initHandler();
		isT = true;
		status = STATUS_START;
	}
	
	/**
	 * 初始化Handler实例
	 * @throws EisException
	 */
	private void initHandler() throws EisException{
		String className = config.getProperty(ConfigConstants.PROVIDER_HANDLER_CLASSNAME);
		try {
			if (handler == null){
				this.handler = (IServiceHandler)Class.forName(className).newInstance();
			}
		} catch (Exception e) {
			StringBuffer sb = new StringBuffer().append("class(").append(className).append(") initialization failed!");
			LogUtil.getInstance().error(sb.toString(),e);
			sb = null;
			throw new EisException(e);
		}
	}

	@Override
	public void stop() {
		status = STATUS_STOP;
		isT = false;
	}

	@Override
	public void run() {
		while (isT) {
			label: switch (status) {
			case STATUS_PAUSE:
				try {
					Thread.sleep(1000 * 1);
				} catch (InterruptedException e) {
					logUtil.error("Error in pause status.", e);
				}
				break;
			case STATUS_START:
				try {
					process();
				} catch (EisException e) {
					logUtil.error("Error in Service Provider:\n", e);
					handler.handleException(e);
					resetConnectionPoolManager();
				}
				break;
			case STATUS_STOP:
				StringBuffer sb = new StringBuffer().append("Provider[").append(this).append("] is stopped.");
				logUtil.info(sb.toString());
				sb = null;
				break label;
			default:
				break;
			}
		}
	}
	
	/**
	 * 重置连接池
	 */
	protected void resetConnectionPoolManager(){
		try {
			connectionPoolManager.close();
//			receiveList.remove(0);
			if(receiveList.size() > 0){
				connectionPoolManager = new PoolableMQConnectionManager(sendList, receiveList,
						Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_POOL_MAXNUM)),
						Integer.parseInt(config.getProperty(ConfigConstants.MQ_PROVIDER_GETCONN_TIMEOUT)));
				logUtil.info("已重置网络连接！");
			} else {
				stop();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected abstract void process() throws EisException;
	
	public IConnectionPoolManager getConnectionPoolManager() {
		return connectionPoolManager;
	}

	public Properties getConfig() {
		return config;
	}
	
}
