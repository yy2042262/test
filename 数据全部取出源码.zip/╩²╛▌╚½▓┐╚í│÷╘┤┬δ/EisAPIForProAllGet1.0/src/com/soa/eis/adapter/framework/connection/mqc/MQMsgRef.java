
package com.soa.eis.adapter.framework.connection.mqc;


/**
 * MQ对象
 * @author wangtao
 *
 */
public class MQMsgRef implements Cloneable {
	public byte[] MQMsgId = null;
	public byte[] MQMsgBody = null;
	public String ReplyToQMgr = null;
	
	public MQMsgRef() {
	}
	
	public MQMsgRef(byte[] MQMsgId, byte[] msgBody) {
		this.MQMsgId = MQMsgId;
		this.MQMsgBody = msgBody;
	}

	public Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			/* Never reach here.*/
			return new MQMsgRef();
		}
	}
}//end of calss
