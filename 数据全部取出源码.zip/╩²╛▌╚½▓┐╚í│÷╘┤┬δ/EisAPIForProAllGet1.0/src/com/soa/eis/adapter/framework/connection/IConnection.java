
package com.soa.eis.adapter.framework.connection;

import com.soa.eis.adapter.framework.connection.mqc.MQMsgRef;
import com.soa.eis.adapter.framework.exception.EisException;


/**
 * Service connection to access remote service provider(requester).
 * 服务连接接口类
 *
 * @author 
 */
public interface IConnection {

	/** 
	 * Default timeout is 2 minutes.<br>
	 * 默认超时时间 : 2分钟.
	 **/
	public static final int DEFAULT_TIMEOUT = 2 * 60;

	/**
	 * 发送方法.
	 *
	 * @param request message object
	 * @return message id
	 * @throws EisException
	 */
	public MQMsgRef send(MQMsgRef msg) throws EisException;
	
	/**
	 *  分组发送方法(暂时不提供该实现).
	 *
	 * @param request message 
	 * @return message group id
	 * @throws EisException
	 */
	public byte[] sendBySegment(byte[] msg) throws EisException;
	
	/**
	 * 分组发送方法(暂时不提供该实现).
	 *
	 * @param request message which is read from file
	 * @return message group id
	 * @throws EisException
	 */
	public byte[] sendBySegment(String filename) throws EisException;

	/**
	 * 接收方法
	 *
	 * @return response message object
	 * @throws EisException
	 */
	public MQMsgRef receive() throws EisException;
	
	/**
	 * 接收方法(自定义超时时间参数)
	 *
	 * @param timeout time to wait for the response message (unit : second)
	 * @return response message object
	 * @throws EisException
	 */
	public MQMsgRef receive(int timeout) throws EisException;
	
	/**
	 * 接收方法
	 *
	 * @param timeout time to wait for the response message (unit : second)
	 * @param message id
	 * @return response message object
	 * @throws EisException
	 */
	public MQMsgRef receive(int timeout, MQMsgRef mqMsgRef) throws EisException;
	
	/**
	 * 分组接收方法(暂不提供)
	 *
	 * @param timeout time to wait for the response message (unit : second)
	 * @param message group id
	 * @return response message 
	 * @throws EisException
	 */
	public byte[] receiveBySegment(int timeout, byte[] grpid) throws EisException;
	
	/**
	 * 分组接收方法(暂不提供)
	 *
	 * @param timeout time to wait for the response message (unit : second)
	 * @param message group id
	 * @param file name which will be writed
	 * @return write file successfully or failed (true/false)
	 * @throws EisException
	 */
	public boolean receiveBySegment(int timeout, byte[] grpid, String filename) throws EisException;
	
	/**
	 * 分组接收方法(暂不提供)
	 *
	 * @param request message
	 * @return response message
	 * @throws EisException
	 */
	public byte[] request(byte[] msg) throws EisException;
	
	/**
	 * For service requester, send request to service provider and receive response synchronously.
	 *
	 * @param timeout time to wait for the response message (unit : second)
	 * @param request message
	 * @return response message
	 * @throws EisException
	 */
	public byte[] request(byte[] msg, int timeout) throws EisException;
	
	/**
	 * release connection.
	 *
	 * @throws EisException
	 */
	public void release() throws EisException;

}
