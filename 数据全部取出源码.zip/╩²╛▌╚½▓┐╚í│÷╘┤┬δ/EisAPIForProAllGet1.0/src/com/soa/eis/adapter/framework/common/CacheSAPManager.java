package com.soa.eis.adapter.framework.common;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLDecoder;
import java.util.Properties;

import com.soa.eis.adapter.framework.utils.log.ILog;
import com.soa.eis.adapter.framework.utils.log.LogUtil;

/**
 * 配置缓存管理类
 * @author PJ
 *
 */
public class CacheSAPManager {

//	private static CacheSAPManager cm = null;
	protected ILog logUtil = null;
	private Properties config = new Properties();
	
	public CacheSAPManager(String fileURL) {
		this.logUtil = LogUtil.getInstance();
		InputStream istream = null;
		try {
			String baseURL = URLDecoder.decode(getClass().getResource("/").getPath(), "UTF-8");
			if (fileURL != null && !fileURL.startsWith("/")){
				istream = new BufferedInputStream(new FileInputStream(baseURL + fileURL));
			}else{
				istream = new BufferedInputStream(new FileInputStream(baseURL.subSequence(0, baseURL.length()-1) + fileURL));
			}
			
			if (istream != null){
				config.load(istream);
				istream.close();
			}
		} catch (Exception e) {
			try{
				File file = new File(fileURL);
				logUtil.error(file.getAbsolutePath());
				System.out.println(file.getAbsolutePath());
			}catch(Exception ex){
				ex.printStackTrace();
			}
			
			logUtil.error("loadConfigurations fail : " + fileURL);
			logUtil.error("Exception:", e);
		} finally {
			try {
				istream.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
//	public static synchronized CacheSAPManager getInstance(String fileURL) throws EisException {
//		if (cm == null) {
//			cm = new CacheSAPManager(fileURL);
//		}
//		return cm;
//	}

	public ILog getLogUtil() {
		return logUtil;
	}

	public Properties getConfig() {
		return config;
	}
	
}
