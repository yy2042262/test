
package com.soa.eis.adapter.framework.connection.mqc;

/**
 * MQ 连接配置对象
 * 存放MQ连接所需要的连接参数
 *
 */


public class MQParameter {

	private String hostName;

	private int port = 0;

	private String channel;

	private int ccsid = 0;

	private String qManagerName;

	private String queueName;

	/**
	 * @param hostName
	 * @param port
	 * @param channel
	 * @param ccsid
	 * @param managerName
	 * @param queueName
	 */
	public MQParameter(String hostName, int port, String channel, int ccsid,
			String managerName, String queueName) {
		super();
		this.hostName = hostName;
		this.port = port;
		this.channel = channel;
		this.ccsid = ccsid;
		this.qManagerName = managerName;
		this.queueName = queueName;
	}

	/**
	 * @return the hostName
	 */
	public String getHostName() {
		return hostName;
	}

	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @return the ccsid
	 */
	public int getCcsid() {
		return ccsid;
	}

	/**
	 * @return the queueName
	 */
	public String getQueueName() {
		return queueName;
	}

	/**
	 * @return the qManagerName
	 */
	public String getQManagerName() {
		return qManagerName;
	}
	
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("MQParameter[hostname=").append(this.hostName)
		.append(",port=").append(this.port)
		.append(",ccsid=").append(this.ccsid)
		.append(",channel=").append(this.channel)
		.append(",qmanager=").append(this.qManagerName)
		.append(",queue=").append(this.queueName).append("]");
		return sb.toString();
	}

}
