package com.soa.eis.adapter.framework.requester.impl;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import com.soa.eis.adapter.framework.config.ConfigConstants;
import com.soa.eis.adapter.framework.connection.IConnection;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.message.IMsgObject;
import com.soa.eis.adapter.framework.message.impl.MsgObject;
import com.soa.eis.adapter.framework.requester.IServiceRequester;

public class BaseServiceRequester extends AbstractServiceRequester implements
		IServiceRequester {
	private static IServiceRequester requester = null;
	
	//MQ队列管理器数量
	private int connectionPoolManagerSize = 0;
	//正在连接的MQ队列管理器在List中的下标
//	private int connectionPoolManagerIndex = 0;

	public BaseServiceRequester() throws EisException {
		super();
	}

	public synchronized static IServiceRequester getInstance() throws EisException {
		if (null == requester) {
			requester = new BaseServiceRequester();
		}
		return requester;
	}

	public IMsgObject execute(IMsgObject reqMo, int timeout) throws EisException {
		IConnection connection = null;
		IMsgObject resMo = null;
		connectionPoolManagerSize = getConnectionPoolManagerList().size();
//		connectionPoolManagerIndex = 0;
		
		for(int i=0;i<connectionPoolManagerSize;i++){
			try{
				connection = getConnection(i);
//				setMAC(reqMo);
				byte[] reqMsg = reqMo.getBytes();
				byte[] resMsg = connection.request(reqMsg, timeout);
				resMo = new MsgObject(resMsg,IMsgObject.MOType.initSR);
			} catch(TimeoutException te) {
				logUtil.error("第" + (i+1) + "个MQ连接超时！", te);
				if(i < connectionPoolManagerSize - 1){
					continue;
				} else {
					throw new EisException(te);
				}
			} catch (SocketException se) {
				logUtil.error("获取客户端MAC失败！", se);
				if(i < connectionPoolManagerSize - 1){
					continue;
				} else {
					throw new EisException(se);
				}
			} catch(Exception e) {
				String errorMsg = e.getMessage();
				if (errorMsg.contains("Failed to init connection.") || errorMsg.contains("Fail to get connection.")) {
					logUtil.error("第" + (i+1) + "个MQ获取连接失败！", e);
				} else if(errorMsg.contains("MQ Msg Send Put Msg Error Exception")) {
					logUtil.error("第" + (i+1) + "个MQ发送数据失败！", e);
				} else {
					logUtil.error("Error in Base Service Requester:",e);
					throw new EisException(e);
				}
				
				if(i < connectionPoolManagerSize - 1){
					continue;
				} else {
					throw new EisException(e);
				}
			} finally {
				if (connection != null) {
					connection.release();
					getConnectionPoolManagerList().get(i).releaseConnection(connection);
					connection = null;
				}
			}
			
			if(resMo != null){
				break;
			}
		}

//		try {
//			connection = getConnection(connectionPoolManagerIndex);
//			
//			byte[] reqMsg = ((IMsgObject) reqMo).getBytes();
//			
//			byte[] resMsg = connection.request(reqMsg, timeout);
//			
//			resMo = new MsgObject(resMsg,IMsgObject.MOType.initSR);
//		} catch (EisException e) {
//			logUtil.error("Error in Base Service Requester:",e);
//			//当放入消息失败时，重置主MQ连接
//			if("EEE2200063:MQ Msg Send Put Msg Error Exception".equals(e.getMessage())){
//				resetConnectionPoolManager();
//			}
//			throw e;
//		} catch (Exception e){
//			logUtil.error("Error in Base Service Requester:",e);
//			throw new EisException(e);
//		} finally {
//			if (connection != null) {
//				connection.release();
//				getConnectionPoolManagerList().get(connectionPoolManagerIndex).releaseConnection(connection);
//				connection = null;
//			}
//		}
		
		return resMo;
	}

	@Override
	public void closeConnection() {
		try{
			this.getConnectionPoolManager().close();
			requester = null;
		}catch(Exception e){
			logUtil.error("closePool:", e);
		}
	}
	
	//获取MQ连接，若超过设定时间强行中断进程
	public IConnection getConnection(final int i) throws Exception {
		IConnection connection = null;
		
		ExecutorService executor = Executors.newFixedThreadPool(1);
		Future<IConnection> future = executor.submit(new Callable<IConnection>(){
			@Override
			public IConnection call() throws Exception {
				return BaseServiceRequester.getInstance().getConnectionPoolManagerList().get(i).getConnection();
			}
		});
		
		try {
			connection = future.get(Long.valueOf(config.getProperty(ConfigConstants.MQ_REQUESTER_LINK_TIMEOUT)), TimeUnit.MILLISECONDS);
		} catch(TimeoutException te) {
//			System.out.println("连接第" + (connectionPoolManagerIndex + 1) + "个MQ队列管理器失败！");
//			if(connectionPoolManagerIndex + 1 < connectionPoolManagerSize){
//				connectionPoolManagerIndex++;
//				System.out.println("开始连接第"+ (connectionPoolManagerIndex + 1) + "个MQ队列管理器……");
//				connection = getConnection(connectionPoolManagerIndex);
//			}
			throw(te);
		} finally {
			executor.shutdown();
		}
		
		return connection;
	}
	
	/**
	 * 在报文中设置请求方MAC
	 * @param reqMo
	 * @throws SocketException 
	 */
	public void setMAC(IMsgObject reqMo) throws SocketException{
		//由于一台电脑中可能会有多个网卡，故把所有的MAC都统计进来，避免漏掉真实在用的MAC
		StringBuffer macs = new StringBuffer();
		
		Enumeration<NetworkInterface> niEnum = NetworkInterface.getNetworkInterfaces();
		while(niEnum.hasMoreElements()){
			NetworkInterface ni = niEnum.nextElement();
			if(ni.isUp()){
				byte[] bytes = ni.getHardwareAddress();
				if (ni != null && bytes != null && bytes.length == 6) {
					StringBuffer mac = new StringBuffer();
					for (byte b : bytes) {
						//与11110000作按位与运算以便读取当前字节高4位
						mac.append(Integer.toHexString((b & 240) >> 4));
						//与00001111作按位与运算以便读取当前字节低4位
						mac.append(Integer.toHexString(b & 15));
						mac.append("-");
					}
					mac.deleteCharAt(mac.length() - 1);
					macs.append(mac.toString().toUpperCase());
					macs.append(",");
				}
			}
		}
		
		macs.deleteCharAt(macs.length() - 1);
		((MsgObject) reqMo).setHeaderAttribute("MAC", macs.toString());
	}
	
}
