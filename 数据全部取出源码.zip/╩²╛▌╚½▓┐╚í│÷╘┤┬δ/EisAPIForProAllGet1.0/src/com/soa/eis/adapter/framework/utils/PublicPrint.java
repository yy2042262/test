package com.soa.eis.adapter.framework.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.soa.eis.adapter.framework.utils.log.LogUtil;

public class PublicPrint {
	public static enum PrintType {
		DEBUG, INFO, WARN, ERROR, FATAL
	};
	public static void printSubBuffer(byte[] abBufferData, int iOffset,
			int iBufferSize, PublicPrint.PrintType pt) {
		String sAddress = null;
		String sHex = null;
		String sAscii = null;
		String sTemp = null;
		int iBytesPerRow = 16;
		int iByteInRow;
		int iByteIndex;
		int i;
		byte b;

		for (iByteIndex = 0; iByteIndex < iBufferSize; iByteIndex++) {
			iByteInRow = iByteIndex % iBytesPerRow;
			if (iByteInRow == 0) {
				sAddress = "";
				sHex = "";
				sAscii = "";

				sTemp = Integer.toHexString(iByteIndex).toUpperCase();
				while (sTemp.length() < 4)
					sTemp = "0" + sTemp;
				while (sTemp.length() > 4)
					sTemp = sTemp.substring(sTemp.length() - 4);
				sAddress = sTemp;
			}

			b = abBufferData[iByteIndex + iOffset];

			sTemp = Integer.toHexString(new Byte(b).intValue()).toUpperCase();
			while (sTemp.length() < 2)
				sTemp = "0" + sTemp;
			while (sTemp.length() > 2)
				sTemp = sTemp.substring(sTemp.length() - 2);
			sHex += sTemp + " ";

			if (b >= 32 && b <= 126)
				sAscii += (char) b;
			else
				sAscii += ".";

			if (iByteInRow == iBytesPerRow - 1 || iByteIndex == iBufferSize - 1) {
				for (i = 0; i < iBytesPerRow - 1 - iByteInRow; i++)
					sHex += "   ";

				print("        " + sAddress + ": " + sHex + " " + sAscii, pt);
			}
		}
	}



	public static void printBuffer(byte[] abBufferData, int iBufferSize, PublicPrint.PrintType pt) {
		printSubBuffer(abBufferData, 0, iBufferSize, pt);
	}

	public static void printBufferString(byte[] abBufferData, PublicPrint.PrintType pt) {
		int i;

		for (i = 0; i < abBufferData.length; i++)
			if (abBufferData[i] == 0x00)
				break;

		printBuffer(abBufferData, i, pt);
	}
	
	@SuppressWarnings("unchecked")
	public static void printHashMap(HashMap hashmap, PublicPrint.PrintType pt) {
		Iterator it = hashmap.entrySet().iterator();
		while (it.hasNext()) {
			try {
				Map.Entry pairs = (Map.Entry) it.next();
				print(pairs.getKey().toString()+":"+ pairs.getValue().toString(), pt);
			} catch (Exception ex) {
				continue;
			}
		}
	}
	
	public static void print(Object o, PublicPrint.PrintType pt) {
		switch (pt) {
		case DEBUG:	
			LogUtil.getInstance().debug(o);
			break;
		case INFO:	
			LogUtil.getInstance().info(o);
			break;
		case WARN:	
			LogUtil.getInstance().warn(o);
			break;
		case ERROR:	
			LogUtil.getInstance().error(o);
			break;
		case FATAL:	
			LogUtil.getInstance().fatal(o);
			break;
		}
	}
}
