package com.soa.eis.adapter.framework.connection.mqcm;

import org.apache.commons.pool.BasePoolableObjectFactory;

import com.soa.eis.adapter.framework.connection.mqc.MQConnection;

class MQConnectionPoolFactory extends BasePoolableObjectFactory {

	private PoolableMQConnectionManager connectionPoolManager;

	/**
	 * @param connectionManager
	 */
	public MQConnectionPoolFactory(PoolableMQConnectionManager connectionManager) {
		super();
		this.connectionPoolManager = connectionManager;
	}
	
	/**
	 * 在需要时产生新的对象
	 */
	public Object makeObject() throws Exception {
		MQConnection connection = new MQConnection(connectionPoolManager.getSendQueue(), connectionPoolManager.getReceiveQueue());
		boolean ret = connection.initMQConnection();
		if (!ret)
			throw new Exception("Failed to init connection.");
		return connection;
	}
	
	/**
	 * 销毁对象
	 */
	public void destroyObject(Object connection) throws Exception {
		((MQConnection) connection).release();
	}
	
	/**
	 * 检查对象
	 */
	public boolean validateObject(Object connection) {
		return ((MQConnection) connection).valid();
	}
	
	/**
	 * 激活对象，必要时初始化对象
	 */
	public void activateObject(Object connection) throws Exception {
		((MQConnection) connection).reset();
	}
	
	/**
	 * 挂起对象，在归还到对象池中
	 */
	public void passivateObject(Object connection) throws Exception {
		((MQConnection) connection).reset();
	}

}
