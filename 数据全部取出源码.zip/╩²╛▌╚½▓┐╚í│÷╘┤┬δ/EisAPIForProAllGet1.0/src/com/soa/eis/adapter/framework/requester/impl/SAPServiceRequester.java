package com.soa.eis.adapter.framework.requester.impl;

import com.soa.eis.adapter.framework.connection.IConnection;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.message.IMsgObject;
import com.soa.eis.adapter.framework.message.impl.MsgObject;
import com.soa.eis.adapter.framework.requester.IServiceRequester;

public class SAPServiceRequester extends AbstractSAPServiceRequester implements
		IServiceRequester {

//	private static IServiceRequester requester = null;

	public SAPServiceRequester(String fileURL) throws EisException {
		super(fileURL);
	}

//	public synchronized static IServiceRequester getInstance(String fileURL)
//			throws EisException {
//		if (null == requester) {
//			requester = new SAPServiceRequester(fileURL);
//		}
//		return requester;
//	}
//
//	public static IServiceRequester getPoolInstance(String fileURL) throws EisException {
//		if (null == requester) {
//			getInstance(fileURL);
//		}
//		return requester;
//	}
	
	public IMsgObject execute(IMsgObject reqMo, int timeout)
			throws EisException {

		IConnection connection = null;
		IMsgObject resMo = null;

		try {
			connection = getConnectionPoolManager().getConnection();
			byte[] reqMsg = ((IMsgObject) reqMo).getBytes();
			
			byte resMsg[] = connection.request(reqMsg, timeout);
			
			resMo = new MsgObject(resMsg,IMsgObject.MOType.initSR);
		}catch (EisException e) {
			logUtil.error("Error in Base Service Requester:",e);
			throw e;
		}catch (Exception e){
			logUtil.error("Error in Base Service Requester:",e);
			throw new EisException(e);
		}finally {
			if (connection != null) {
//				connection.release();
				getConnectionPoolManager().releaseConnection(connection);
				connection = null;
			}
		}
		return resMo;
	}

	@Override
	public void closeConnection() {
		try{
			this.getConnectionPoolManager().close();
//			requester = null;
		}catch(Exception e){
			logUtil.error("closePool:", e);
		}
	}

}
