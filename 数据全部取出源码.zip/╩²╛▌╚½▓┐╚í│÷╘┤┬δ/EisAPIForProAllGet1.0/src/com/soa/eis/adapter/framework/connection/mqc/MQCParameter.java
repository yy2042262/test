package com.soa.eis.adapter.framework.connection.mqc;


import java.util.Date;

import com.ibm.mq.MQException;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;


/**
 * MQ 连接实例
 * @author KAIHU
 *
 */
public class MQCParameter {
	
	/**
	 * MQ 连接配置对象
	 */
	protected MQParameter mqParameter = null;
	
	/**
	 * MQ 队列管理器
	 */
	protected MQQueueManager qManager = null;

	/**
	 * MQ Q队列
	 */
	protected MQQueue queue = null;

	public MQParameter getMqParameter() {
		return mqParameter;
	}

	public MQQueueManager getqManager() {
		return qManager;
	}

	public MQQueue getQueue() {
		return queue;
	}
	
	/**
	 * @param mqParameter
	 */
	public MQCParameter(MQParameter mqParameter) {
		super();
		this.mqParameter = mqParameter;
	}
	
	/**
	 * 断开Q队列和 队列管理的链接，并将MQ对象清空
	 * 如果发生错误，重复关闭3次
	 */
	public void release() {
		if(this.queue != null){
			for(int i=1;i<=3;i++){
				try {
					if(this.queue.isOpen()){
						this.queue.close();
					}
				} catch (MQException e) {
					System.out.println("[" + new Date() + "]" + "Close queue false:" + e.getMessage());
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					continue;
				}
				this.queue = null;
				break;
			}
		}
		
		if (this.qManager != null) {
			for(int i=1;i<=3;i++){
				try {
					if(this.qManager.isOpen()){
						this.qManager.close();
					}
				} catch (MQException e) {
					System.out.println("[" + new Date() + "]" + "Close qManager false:" + e.getMessage());
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					continue;
				}
				break;
			}
			
			for(int i=1;i<=3;i++){
				try {
					if(this.qManager.isConnected()){
						this.qManager.disconnect();
					}
				} catch (Exception e) {
					System.out.println("[" + new Date() + "]" + "Disconnect qManager false:" + e.getMessage());
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					continue;
				}
				this.qManager = null;
				break;
			}
		}
	}
} // end of class
