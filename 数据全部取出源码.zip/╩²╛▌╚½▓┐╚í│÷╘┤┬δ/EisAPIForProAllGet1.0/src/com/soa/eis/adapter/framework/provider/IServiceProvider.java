package com.soa.eis.adapter.framework.provider;

import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.handler.IServiceHandler;

public interface IServiceProvider extends Runnable {
	/**
	 * Pause processing service responses.
	 */
	public void pause();

	/**
	 * A service provider process service requests and generates service
	 * responses via service handler.
	 *
	 * @param serviceHandler
	 */
	public void setServiceHandler(IServiceHandler serviceHandler);

	/**
	 * Start processing service requests.
	 */
	public void start() throws EisException;

	/**
	 * Stop processing service responses.
	 */
	public void stop();
	
	public void closeConnection();
}
