package com.soa.eis.adapter.framework.utils.log; 

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import org.apache.commons.logging.LogFactory;
import org.apache.log4j.PropertyConfigurator;

import com.soa.eis.adapter.framework.config.ConfigConstants;


/** 
 * @author Ricky
 * @version created ：2011-6-15 下午02:31:15 
 * 
 */
public class LogUtil implements ILog{
	private static org.apache.commons.logging.Log log = null;
	private static ILog logutil = null;
	private static String LOGGER_TAG = "ESB";
	private LogUtil() {
		InputStream istream = null;
		try{
			try{
				URL in = getClass().getResource("/");
//				System.out.println(in + ConfigConstants.CONFIG_FILE);
			}catch(Exception e){
				e.printStackTrace();
			}
			
			if (ConfigConstants.LOG4J != null && !ConfigConstants.LOG4J.startsWith("/")){
				istream = getClass().getResourceAsStream("/" + ConfigConstants.LOG4J);
			}else{
				istream = getClass().getResourceAsStream(ConfigConstants.LOG4J);
			}
			
			if (istream != null){
				Properties log4jPro = new Properties();
				log4jPro.load(istream);
				PropertyConfigurator.configure(log4jPro);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if (istream == null){
			PropertyConfigurator.configure(ConfigConstants.LOG4J);
		}else{
			try {
				if (istream != null){
					istream.close();
				}
			} catch (Exception ex) {
			}
		}
		
		log = LogFactory.getLog(LOGGER_TAG);		
	}
	public static synchronized ILog getInstance(){
		if (logutil == null) {			
			logutil = new LogUtil();
		}
		return logutil;
	}
	
	public void debug(Object o) {
		log.debug(o);
	}
	
	public void info(Object o) {
		log.info(o);
	}
	
	public void warn(Object o) {
		log.warn(o);
	}
	
	public void error(Object o) {
		log.error(o);
	}
	
	public void fatal(Object o) {
		log.fatal(o);
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#isDebugEnabled(java.lang.Object)
	 */
	public boolean isDebugEnabled() {
		return log.isDebugEnabled();
		
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#isErrorEnabled(java.lang.Object)
	 */
	public boolean isErrorEnabled() {
		return log.isErrorEnabled();
		
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#isFatalEnabled(java.lang.Object)
	 */
	public boolean isFatalEnabled() {
		return log.isFatalEnabled();
		
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#isInfoEnabled(java.lang.Object)
	 */
	public boolean isInfoEnabled() {
		return log.isInfoEnabled();
		
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#isWarnEnabled(java.lang.Object)
	 */
	public boolean isWarnEnabled() {
		return log.isWarnEnabled();
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#debug(java.lang.Object, java.lang.Throwable)
	 */
	public void debug(Object o, Throwable t) {
		log.debug(o, t);
		
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#error(java.lang.Object, java.lang.Throwable)
	 */
	public void error(Object o, Throwable t) {
		log.error(o, t);
		
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#fatal(java.lang.Object, java.lang.Throwable)
	 */
	public void fatal(Object o, Throwable t) {
		log.fatal(o, t);
		
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#info(java.lang.Object, java.lang.Throwable)
	 */
	public void info(Object o, Throwable t) {
		log.info(o, t);
		
	}
	/* (non-Javadoc)
	 * @see com.ibm.esb.adapter.framework.util.log.ILog#warn(java.lang.Object, java.lang.Throwable)
	 */
	public void warn(Object o, Throwable t) {
		log.warn(o, t);
		
	}
	
	public Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
	}
	
}
