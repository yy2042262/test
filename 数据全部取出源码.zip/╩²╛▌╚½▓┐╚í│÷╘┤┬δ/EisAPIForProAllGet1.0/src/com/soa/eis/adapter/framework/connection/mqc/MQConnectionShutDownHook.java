
package com.soa.eis.adapter.framework.connection.mqc;

import java.util.HashSet;
import java.util.Set;

import com.soa.eis.adapter.framework.common.CacheManager;
import com.soa.eis.adapter.framework.connection.IConnection;
import com.soa.eis.adapter.framework.exception.EisException;
import com.soa.eis.adapter.framework.utils.log.ILog;
import com.soa.eis.adapter.framework.utils.log.LogUtil;

/**
 * 连接关闭触发类
 * @author wangtao
 *
 */
class MQConnectionShutDownHook extends Thread {

	private static ILog logUtil ;

	private MQConnectionShutDownHook() throws EisException {
		logUtil = CacheManager.getInstance().getLogUtil();
	}

	static {
		MQConnectionShutDownHook shutDownHook;
		try {
			shutDownHook = new MQConnectionShutDownHook();
			Runtime.getRuntime().addShutdownHook(shutDownHook);
		} catch (EisException e) {			
			logUtil.error("Exception:", e);
		}
		
	}


	protected static Set<IConnection> connSet = new HashSet<IConnection>();

	protected static synchronized void register(IConnection connection) {
		connSet.add(connection);
	}

    public void run() {
    	logUtil.info("MQConnections are closing ...");
        Object[] conns = connSet.toArray();
        for (int i = 0; i < conns.length; i++) {
        	IConnection conn = (IConnection) conns[i];
        	try {
        		conn.release();
			} catch (EisException e) {
				logUtil.error("Exception:", e);
			}
        }
    }
}
