package com.yueyong.springboot.producer;

import java.util.Date;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.core.RabbitTemplate.ConfirmCallback;
import org.springframework.amqp.rabbit.core.RabbitTemplate.ReturnCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.yueyong.springboot.constant.Constants;
import com.yueyong.springboot.entity.Order;
import com.yueyong.springboot.mapper.BrokerMessageLogMapper;

@Component
public class RabbitOrderSender {
	@Autowired
	private RabbitTemplate rabbitTemplate;
	@Autowired
	private BrokerMessageLogMapper brokerMessageLogMapper;
	//回调函数：confirm确认
	final ConfirmCallback confirmCallback=new RabbitTemplate.ConfirmCallback() {
		@Override
		public void confirm(CorrelationData correlationData, boolean ack, String cause) {
			// TODO Auto-generated method stub
			System.err.println("correlationData:"+correlationData);
			String messageId=correlationData.getId();
			if(ack) {
				//如果confirm返回成功，则进行更新
				brokerMessageLogMapper.changeBrokerMessageLogStatus(messageId, Constants.ORDER_SEND_SUCCESS,new Date());
			}
			else {
				//失败则进行具体的后续操作：重试 或者 补偿等手段
				System.err.println("异常处理...");
			}
		}
	};
	//回调函数：return返回
	final ReturnCallback returnCallback=new RabbitTemplate.ReturnCallback() {
		@Override
		public void returnedMessage(Message message, int replyCode, String replyText, String exchange,
				String routingKey) {
			// TODO Auto-generated method stub
			System.err.println("return exchange:"+exchange+",routingKey:"+routingKey+",replyCode:"+replyCode+",replyText:"+replyText);
		}
	};
	
	//发送消息方法调用:构建自定义对象消息
	public void sendOrder(Order order) throws Exception{
		rabbitTemplate.setConfirmCallback(confirmCallback);
		//消息唯一ID
		CorrelationData correlationData=new CorrelationData(order.getMessage_id());
		
		//交换机正确测试
		//rabbitTemplate.convertAndSend("order-exchange", "order.ABC", order, correlationData);
		
		//交换机错误测试
		rabbitTemplate.convertAndSend("order-exchange111", "order.ABC", order, correlationData);
		
	}
	
}
