package com.yueyong.springboot.constant;

public final class Constants {
	public static final String ORDER_SENDING="0";
	public static final String ORDER_SEND_SUCCESS="1";
	public static final String ORDER_SEND_FAILURE="2";
	public static final int ORDER_TIMEOUT=1;//min
}
