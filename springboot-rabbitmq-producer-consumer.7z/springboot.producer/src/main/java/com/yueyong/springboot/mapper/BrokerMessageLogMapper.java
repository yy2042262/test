package com.yueyong.springboot.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.yueyong.springboot.entity.BrokerMessageLog;

public interface BrokerMessageLogMapper {
	int insert(BrokerMessageLog record);
	int insertSelective(BrokerMessageLog record);
	int deleteByPrimaryKey(String messageId);
	int updateByPrimaryKey(BrokerMessageLog record);
	int updateByPrimaryKeySelective(BrokerMessageLog record);
	BrokerMessageLog selectByPrimaryKey(String messageId);
	//查询消息状态为0(发送中)且已经超时的消息集合
	List<BrokerMessageLog> query4StatusAndTimeoutMessage();
	//重新发送统计count发送次数+1
	void update4ReSend(@Param("messageId")String messageId,@Param("updateTime")Date updateTime);
	//更新最终消息发送结果成功or失败
	void changeBrokerMessageLogStatus(@Param("messageId")String messageId,@Param("status")String status,@Param("updateTime")Date updateTime);
}
