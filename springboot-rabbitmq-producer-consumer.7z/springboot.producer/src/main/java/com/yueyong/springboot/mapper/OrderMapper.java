package com.yueyong.springboot.mapper;

import com.yueyong.springboot.entity.Order;

public interface OrderMapper {
	int insert(Order order);
	int insertSelective(Order order);
	int deleteByPrimaryKey(String id);
	int updateByPrimaryKey(Order order);
	int updateByPrimaryKeySelective(Order order);
	Order selectByPrimaryKey(String id);
}
